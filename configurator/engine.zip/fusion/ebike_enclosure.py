# Author: Gemini CAD Generator v4, parameterized rewrite
# Description: Parametric e-bike battery enclosure (polycarbonate side plates and walls,
#   6061 aluminum base plate, standoffs, foam liner, BMS tray, cell holders, nickel strips, cells).
#
# To run in Fusion 360: Shift+S (Scripts and Add-Ins) -> '+' next to My Scripts ->
# Create a new Python script, paste this in -> Run.
#
# HOW IT WORKS
#   * Every dimension is a Fusion USER PARAMETER (Modify > Change Parameters). Edit a value
#     there and the model regenerates, including Columns and Rows (the cells are built with
#     a rectangular pattern whose counts are bound to those parameters).
#   * Re-running the script keeps any parameter values you already edited, and deletes the
#     previously generated assembly before building a new one.
#   * The tab count, tab positions, bolt positions and hook count are chosen when the script
#     runs. If you change Columns a lot, re-run the script to respace them.
#   * Orientation: X = pack length along the bike (front = +X, rear = -X), Y = height,
#     Z = cell length (the two side plates are the bike's left/right, +/-Z).
#   * Latching: the side-plate hook noses point -X. The base plate and its slots
#     stay fixed; the whole battery is slid -X by Battery_Latch_Slide so the hooks
#     sit latched in the nominal model.

import adsk.core, adsk.fusion, traceback, re, os, math, time

MM = 0.1        # 1 mm in Fusion's internal length unit (cm)
# McMaster-Carr 92137A420: black-oxide alloy steel flanged button head hex-drive screw,
# M5 x 0.8 x 16 mm. Its STEP file goes in fusion/hardware/ (any name starting with the part number).
SCREW_PART = '92137A420'
# Config enclosure.base_plate. False builds the enclosure with no aluminum base plate and no
# L-hooks on the side plates (the battery then mounts by its side plates some other way).
BASE_PLATE = True
# Set in the build-package copy of this script (pack.fusion_script) to the pack it was made for.
# A package script overwrites the design's plain-value parameters with its own values, so it
# always builds its pack; the repo copy (empty name) keeps values you edited in Fusion.
CONFIG_NAME = ''
VALS = {}       # parameter name -> value in mm (unitless for counts)
SKETCHES = []   # every sketch we create, checked for full definition at the end
ISSUES = []     # non-fatal problems (a dimension that failed, etc.)

# (name, expression, units, comment). Order matters: derived entries use earlier names.
PARAMS = [
    # ---- Pack ----
    ('Columns', '20', '', 'Cells across the pack width'),
    ('Rows', '4', '', 'Cells in each column (parallel count)'),
    ('Cell_Diameter', '21', 'mm', 'Cell diameter'),
    ('Cell_Height', '70', 'mm', 'Cell length'),
    ('Cell_Pitch', '23.35', 'mm', 'Cell-to-cell pitch of the holder (square grid)'),
    ('Holder_Height', '9.4', 'mm', 'Cell holder height (one at each cell end), face to face'),
    ('Holder_Recess', '1', 'mm', 'Cell end to holder outer face; the nickel strip lies in this recess'),
    ('Holder_Bore', '21.5', 'mm', 'Cell holder bore diameter'),
    ('Strip_Width', '32', 'mm', '2P nickel strip width (spans two columns)'),
    ('Strip_Thickness', '0.15', 'mm', 'Nickel strip thickness'),
    ('Strip_Leg', '8.9', 'mm', 'Nickel strip side leg width (the balance tab is one leg)'),
    ('Strip_Bar', '8.9', 'mm', 'Nickel strip cross bar width (between the square holes)'),
    ('Strip_End_Inset', '1', 'mm', 'Strip ends stop this far inside the edge of the end cells'),
    ('Weld_Slot_Length', '6', 'mm', 'Weld slot length (along the strip, over each cell terminal)'),
    ('Weld_Slot_Width', '1.2', 'mm', 'Weld slot width'),
    ('Strip_Bend_Radius', '0.5', 'mm', 'Inside bend radius of the folded strip (sheet metal rule)'),
    ('Strip_K_Factor', '0.44', '', 'Sheet metal K factor for the nickel strip (neutral axis / thickness)'),
    ('Foam_Thickness', '5', 'mm', 'Neoprene foam liner thickness, uncompressed'),
    ('Foam_Compression', '1', 'mm', 'How much the foam is squeezed when the pack is closed'),
    ('BMS_Height', '10', 'mm', 'ABS BMS / fuse / wiring tray height'),
    # ---- Plates / base ----
    ('Polycarbonate_Thickness', '5.6', 'mm', 'SendCutSend 0.220 in polycarbonate'),
    ('Lip_Width', '15', 'mm', 'Plate margin outside the walls; holds the bolts and standoffs'),
    ('Corner_Strap_Clearance', '1', 'mm', 'Gap between the wall-box corner and a strap pulled tight over the two corner standoffs'),
    ('Alu_Thickness', '6.35', 'mm', 'SendCutSend 0.250 in 6061 aluminum'),
    ('Base_Front_Extension', '20', 'mm', 'Base plate extension past the battery front edge (+X)'),
    ('Base_Rear_Extension', '20', 'mm', 'Base plate extension past the battery rear edge (-X)'),
    ('Side_Extension', '5', 'mm', 'Base plate extension past the outer faces of the side plates (+/-Z)'),
    # ---- Slots, tabs, router ----
    ('Min_CNC_Router_Diameter', '3.2', 'mm', 'Dogbone circle diameter'),
    ('Slot_Clearance', '0.25', 'mm', 'Slot width minus polycarbonate thickness'),
    ('Tab_Shortfall', '0.2', 'mm', 'How far short of flush the tab ends sit in the side plate'),
    # Tab rule: each side-plate edge runs bolt, tab, bolt, ..., bolt, evenly spaced between its
    # corner bolts. The count per edge is set when the script runs (re-run after resizing).
    ('Tab_Max_Spacing', '125', 'mm', 'Largest bolt / tab spacing along an edge (sets the tab count)'),
    ('Tab_Min_Spacing', '50', 'mm', 'Below this spacing an edge gets fewer tabs (long edges: tight layout)'),
    ('Tab_Length_Ratio', '0.33', '', 'Tab length as a fraction of the tab spacing'),
    ('Tab_Min_Length', '15', 'mm', 'Shortest tab (tight edges may go shorter, down to the dogbone limit)'),
    ('Tab_Max_Length', '40', 'mm', 'Longest tab'),
    ('Cut_Overshoot', '1', 'mm', 'Extra cut depth so cuts pass fully through'),
    # ---- Bolts and standoffs ----
    ('Bolt_Hole_Diameter', '5.3', 'mm', 'M5 clearance hole'),
    ('Standoff_OD', '9.525', 'mm', '3/8 in aluminum spacer OD'),
    ('Standoff_ID', '4.2', 'mm', 'Standoff bore: M5 x 0.8 female thread both ends (4.2 mm tap drill)'),
    # ---- Hooks ----
    # One hook under each bottom tab. The package script for a 2-3S pack carries the small hook
    # (config enclosure.small_hook) in these values.
    ('Hook_Neck_Width', '28', 'mm', 'L-hook neck width'),
    ('Hook_Nose', '10', 'mm', 'L-hook nose length: how far the nose latches under the base plate'),
    ('Hook_Drop_Extra', '10', 'mm', 'Hook nose height below the base plate underside (nose strength)'),
    ('Hook_Overlap', '2', 'mm', 'Hook neck overlap into the side plate'),
    ('Hook_Slot_Length', '40', 'mm', 'Base plate hook slot length'),
    ('Hook_Slot_Offset', '15', 'mm', 'Base slot extent on the +X side of the hook center (battery unslid)'),
    ('Hook_Slot_Clearance', '0.25', 'mm', 'Gap between the hook neck and the front (-X) end of its base slot when latched'),
    # ---- Fillets ----
    ('Fillet_Large', '8', 'mm', 'Outside corners of the base plate'),
    ('Fillet_Small', '2', 'mm', 'Outside corners of the hooks'),
    # ---- Derived (edit the expressions if you want different rules) ----
    ('Bolt_Edge_Offset', 'Lip_Width - Standoff_OD / 2', 'mm',
     'Bolt/standoff center to plate edge: standoffs sit tangent to the outside of the inner walls'),
    ('Side_Plate_Corner_Radius', 'Bolt_Edge_Offset', 'mm',
     'Side plate outline around each corner bolt: arc centered on the bolt, so the corner web matches the edge web'),
    ('Slot_Width', 'Polycarbonate_Thickness + Slot_Clearance', 'mm', 'Slot width for the PC wall'),
    ('Tab_Depth', 'Polycarbonate_Thickness - Tab_Shortfall', 'mm', 'Tab depth into the side plate'),
    ('Hook_Drop', 'Alu_Thickness + Hook_Drop_Extra', 'mm', 'Hook drop below the plate bottom edge'),
    ('Strip_Bend_Allowance', '1.5707963 * (Strip_Bend_Radius + Strip_K_Factor * Strip_Thickness)', 'mm',
     'Flat strip length used by one 90 degree bend (sets the flat blank lengths)'),
    ('Foam_Gap', 'Foam_Thickness - Foam_Compression', 'mm', 'Room left for the foam on every side (installed thickness)'),
    ('Core_Depth', 'Cell_Height + 2 * Holder_Recess', 'mm', 'Cells plus holders, holder face to holder face'),
    ('Cavity_Depth', 'Core_Depth + 2 * Foam_Gap', 'mm', 'Inside distance between side plates'),
    ('Cell_Core_Width', 'Columns * Cell_Pitch', 'mm', 'Cell block width'),
    ('Cell_Core_Height', 'Rows * Cell_Pitch', 'mm', 'Cell block height'),
    ('Cavity_Width', 'Cell_Core_Width + 2 * Foam_Gap', 'mm', 'Inside cavity width'),
    ('Cavity_Height', 'Cell_Core_Height + BMS_Height + 2 * Foam_Gap', 'mm', 'Inside cavity height'),
    ('Plate_Width', 'Cavity_Width + 2 * Polycarbonate_Thickness + 2 * Lip_Width', 'mm', 'Side plate width'),
    ('Plate_Height', 'Cavity_Height + 2 * Polycarbonate_Thickness + 2 * Lip_Width', 'mm', 'Side plate height'),
    ('Base_Plate_X_Length', 'Plate_Width + Base_Front_Extension + Base_Rear_Extension', 'mm', 'Base plate length (X)'),
    ('Base_Plate_Z_Width', 'Cavity_Depth + 2 * Polycarbonate_Thickness + 2 * Side_Extension', 'mm', 'Base plate width (Z)'),
    ('Battery_Latch_Slide', 'Hook_Slot_Length - Hook_Slot_Offset - Hook_Neck_Width / 2 - Hook_Slot_Clearance', 'mm',
     'How far the battery is slid in -X to latch the hooks'),
]


# ----------------------------------------------------------------------------------
# Expression helpers. Expressions are strings in terms of the user parameters. They are
# handed to Fusion as-is (so dimensions stay driven by parameters) and evaluated here
# (to place the initial geometry). "0" is special-cased so we never emit a unitless 0
# next to a length.
# ----------------------------------------------------------------------------------
def neg(a):
    return '0' if a == '0' else '-(%s)' % a

def half(a):
    return '0' if a == '0' else '(%s)/2' % a

def add(a, b):
    if a == '0':
        return b
    if b == '0':
        return a
    return '(%s) + (%s)' % (a, b)

def sub(a, b):
    if b == '0':
        return a
    if a == '0':
        return neg(b)
    return '(%s) - (%s)' % (a, b)

def ev(expr):
    """Evaluate an expression to millimeters (or a plain number)."""
    return float(eval(expr, {'__builtins__': {}}, VALS))

def vi(expr):
    return adsk.core.ValueInput.createByString(expr)

def pt(xe, ye):
    return adsk.core.Point3D.create(ev(xe) * MM, ev(ye) * MM, 0)

def last_error():
    return traceback.format_exc().strip().splitlines()[-1]


# ----------------------------------------------------------------------------------
# Parameters
# ----------------------------------------------------------------------------------
def setup_parameters(design):
    ups = design.userParameters
    for name, expr, units, comment in PARAMS:
        numeric = bool(re.match(r'^[0-9.]+$', expr))
        existing = ups.itemByName(name)
        if existing is None:
            val = vi('%s %s' % (expr, units)) if (units and numeric) else vi(expr)
            ups.add(name, val, units, comment)
        elif not numeric:
            # Derived parameter: always refresh so formula changes in this script take effect
            if existing.expression != expr:
                existing.expression = expr
        elif CONFIG_NAME or not re.match(r'^[0-9.]+( [a-z]+)?$', existing.expression):
            # Package script (builds exactly its pack), or a plain-value parameter that an older
            # version of this script made a formula
            want = '%s %s' % (expr, units) if units else expr
            if existing.expression != want:
                existing.expression = want
        # otherwise: keep the value you edited
    for name, expr, units, comment in PARAMS:
        p = ups.itemByName(name)
        VALS[name] = p.value * 10.0 if units == 'mm' else p.value


def runtime_param(design, name, expr, units, comment):
    """A parameter the script derives from the layout when it runs (tab spacing and length).
    Rewritten on every run; edit the rule parameters above instead and re-run."""
    ups = design.userParameters
    p = ups.itemByName(name)
    if p is None:
        p = ups.add(name, vi(expr), units, comment + ' (set by the script on each run)')
    elif p.expression != expr:
        p.expression = expr
    VALS[name] = p.value * 10.0 if units == 'mm' else p.value


# ----------------------------------------------------------------------------------
# Layout rules. Plain Python (no Fusion calls), kept identical to pack.geometry.edge_tabs and
# its hook check; tests/test_fusion_parity.py runs both and compares.
# ----------------------------------------------------------------------------------
def edge_layout(span, V, min_count=1):
    """Tabs along one side-plate edge whose corner bolts are span apart.
    Returns (count, pitch, tab length, offset). offset is None for the even layout (tabs midway
    between bolts, a bolt between every two tabs); for a tight edge (two tabs forced onto a very
    short edge) it is the tab center distance from the middle, and there is no middle bolt."""
    n = max(1, int(math.ceil(span / V['Tab_Max_Spacing'] - 1e-9)))
    if n < 2 and span / 2.0 >= V['Tab_Min_Spacing']:
        n = 2
    n = max(n, min_count)
    pitch = span / n
    if n == 2 and pitch < V['Tab_Min_Spacing']:
        length = max(2 * V['Min_CNC_Router_Diameter'] + 3.0, V['Tab_Length_Ratio'] * pitch)
        length = round(length * 2) / 2.0
        return n, pitch, length, (span / 2.0 + length / 2.0 - V['Bolt_Hole_Diameter'] / 2.0) / 3.0
    length = min(V['Tab_Max_Length'], max(V['Tab_Min_Length'], V['Tab_Length_Ratio'] * pitch))
    return n, pitch, round(length * 2) / 2.0, None


def edge_web(layout, V):
    """The smallest web along an edge laid out by edge_layout: from a slot to the next bolt hole
    (or, on a tight edge, to the other slot, which the tight layout makes the same)."""
    n, pitch, length, offset = layout
    if offset is None:
        return pitch / 2.0 - length / 2.0 - V['Bolt_Hole_Diameter'] / 2.0
    return 2.0 * offset - length


def corner_slide(long_span, short_span, V, base_plate=True):
    """How far the two standoffs at each side-plate corner sit back from the corner along their
    edges (same rule as pack.geometry.corner_slide). Returns (slide, is_full).

    Each corner has two standoffs, one on each edge, tangent to the outside of the walls; the plate
    outline wraps each one and joins them with a 45 degree line. At the full slide a strap pulled
    tight over the two standoffs (between the side plates) clears the wall-box corner by
    Corner_Strap_Clearance. A small pack gets the largest slide (0.5 mm steps)
    that leaves both edges a full web (2 x thickness) between every slot and bolt hole and room
    for a hook under every bottom tab, or 0: a single corner standoff and a round corner.
    With a base plate only the top corners slide; the bottom two keep one standoff and a round
    corner, so the short edges lose the slide at one end only."""
    limit = 2.0 * V['Polycarbonate_Thickness']
    root2 = math.sqrt(2.0)
    full = V['Standoff_OD'] * (1 + root2 / 2) - V['Corner_Strap_Clearance'] * root2
    least = (V['Bolt_Hole_Diameter'] + limit) / root2

    ends = 1 if base_plate else 2

    def fits(s):
        long_edge = edge_layout(long_span - 2 * s, V, 2)
        if edge_web(long_edge, V) < limit - 1e-9 or edge_web(edge_layout(short_span - ends * s, V, 1), V) < limit - 1e-9:
            return False
        if not base_plate:
            return True
        n, pitch = long_edge[0], long_edge[1]
        hooks = [(2 * i + 1 - n) * pitch / 2.0 for i in range(n)]
        return n < 2 or hooks_fit(hooks, V, straight_half(V))

    if full >= least and fits(full):
        return full, True
    s = math.floor(full * 2) / 2.0
    while s >= least:
        if fits(s):
            return s, False
        s -= 0.5
    return 0.0, False


def strip_groups(columns):
    """Nickel strips: (end, first column, end column), end +1 = rear (+Z), -1 = front (-Z). Same
    rule as pack.geometry.strip_groups: +Z joins columns (0, 1), (2, 3), ...; -Z joins (1, 2), ...;
    the pack terminals get single-column strips."""
    out = []
    for end, start in ((1, 0), (-1, 1)):
        if start:
            out.append((end, 0, 1))
        i = start
        while i < columns:
            out.append((end, i, min(i + 2, columns)))
            i += 2
    return out


def straight_half(V):
    """Half the straight part of the side plate's bottom edge where the hooks hang. Hooks only
    exist with a base plate, and then the bottom corners are round, so it runs to the corner arc."""
    return V['Plate_Width'] / 2.0 - V['Side_Plate_Corner_Radius']


def hooks_fit(xs, V, straight):
    """Neighbouring base-plate hook slots keep one plate thickness of aluminum between them, and
    every hook neck stays on the straight part of the side plate's bottom edge (straight = half
    its length)."""
    gap = min(b - a for a, b in zip(xs, xs[1:])) - V['Hook_Slot_Length']
    return gap >= V['Alu_Thickness'] and max(abs(x) for x in xs) + V['Hook_Neck_Width'] / 2.0 + V['Min_CNC_Router_Diameter'] <= straight


# ----------------------------------------------------------------------------------
# Sketch helpers: draw geometry and fully dimension it from the parameters.
# ----------------------------------------------------------------------------------
def new_sketch(comp, plane, name):
    sk = comp.sketches.add(plane)
    sk.name = name
    SKETCHES.append(sk)
    return sk

def dim_lin(sk, a, b, horizontal, expr):
    """Add a distance dimension bound to expr. If Fusion rejects it, retry with the endpoints
    swapped and with the dimension text on the other side; any rejected dimension is deleted."""
    ori = (adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation if horizontal
           else adsk.fusion.DimensionOrientations.VerticalDimensionOrientation)
    err = ''
    for (p1, p2, side) in ((a, b, -1), (b, a, -1), (a, b, 1), (b, a, 1)):
        d = None
        try:
            g1, g2 = p1.geometry, p2.geometry
            if horizontal:
                tp = adsk.core.Point3D.create((g1.x + g2.x) / 2.0, (min(g1.y, g2.y) if side < 0 else max(g1.y, g2.y)) + side * 0.6, 0)
            else:
                tp = adsk.core.Point3D.create((min(g1.x, g2.x) if side < 0 else max(g1.x, g2.x)) + side * 0.6, (g1.y + g2.y) / 2.0, 0)
            d = sk.sketchDimensions.addDistanceDimension(p1, p2, ori, tp)
            d.parameter.expression = expr
            return True
        except:
            err = last_error()
            if d is not None:
                try:
                    d.deleteMe()
                except:
                    pass
    ISSUES.append('%s: dimension "%s" failed: %s' % (sk.name, expr, err))
    return False

def place(sk, point, xe, ye):
    """Locate a sketch point relative to the origin using parameter-driven dimensions."""
    org = sk.originPoint
    for is_x, e in ((True, xe), (False, ye)):
        v = ev(e)
        if abs(v) < 1e-6:
            try:
                if is_x:
                    sk.geometricConstraints.addVerticalPoints(org, point)
                else:
                    sk.geometricConstraints.addHorizontalPoints(org, point)
            except:
                ISSUES.append('%s: alignment constraint failed: %s' % (sk.name, last_error()))
        else:
            dim_lin(sk, org, point, is_x, e if v > 0 else neg(e))

def rect(sk, x0, x1, y0, y1, w=None, h=None):
    """Draw a rectangle and fully define it: width, height, and corner position."""
    lines = sk.sketchCurves.sketchLines.addTwoPointRectangle(pt(x0, y0), pt(x1, y1))
    # The API does not always add horizontal/vertical constraints; add them explicitly
    # (skipped quietly if a line already has one).
    for i in range(lines.count):
        ln = lines.item(i)
        a, b = ln.startSketchPoint.geometry, ln.endSketchPoint.geometry
        try:
            if abs(a.y - b.y) < 1e-9:
                sk.geometricConstraints.addHorizontal(ln)
            else:
                sk.geometricConstraints.addVertical(ln)
        except:
            pass
    pts = []
    for i in range(lines.count):
        ln = lines.item(i)
        pts.append(ln.startSketchPoint)
        pts.append(ln.endSketchPoint)
    bl = min(pts, key=lambda p: p.geometry.x + p.geometry.y)
    br = max(pts, key=lambda p: p.geometry.x - p.geometry.y)
    tl = min(pts, key=lambda p: p.geometry.x - p.geometry.y)
    dim_lin(sk, bl, br, True, w or sub(x1, x0))
    dim_lin(sk, bl, tl, False, h or sub(y1, y0))
    place(sk, bl, x0, y0)
    return lines

def rect_edges(lines):
    hs, vs = [], []
    for i in range(lines.count):
        ln = lines.item(i)
        a, b = ln.startSketchPoint.geometry, ln.endSketchPoint.geometry
        if abs(a.y - b.y) < 1e-9:
            hs.append(ln)
        else:
            vs.append(ln)
    return {
        'bottom': min(hs, key=lambda l: l.startSketchPoint.geometry.y),
        'top': max(hs, key=lambda l: l.startSketchPoint.geometry.y),
        'left': min(vs, key=lambda l: l.startSketchPoint.geometry.x),
        'right': max(vs, key=lambda l: l.startSketchPoint.geometry.x),
    }

def circle(sk, cx, cy, dia, locate=True):
    r = ev(dia) * MM / 2.0
    c = sk.sketchCurves.sketchCircles.addByCenterRadius(pt(cx, cy), r)
    try:
        g = c.centerSketchPoint.geometry
        tp = adsk.core.Point3D.create(g.x + r * 1.6, g.y + r * 1.6, 0)
        d = sk.sketchDimensions.addDiameterDimension(c, tp)
        d.parameter.expression = dia
    except:
        ISSUES.append('%s: diameter dimension "%s" failed: %s' % (sk.name, dia, last_error()))
    if locate:
        place(sk, c.centerSketchPoint, cx, cy)
    return c

def slot(sk, x0, x1, y0, y1, along_x, w, h):
    """Rectangular slot with 4 dogbone circles. Each circle is centered on a long edge and
    tangent to the short end of the slot, so the end stays flat across the full slot width."""
    lines = rect(sk, x0, x1, y0, y1, w, h)
    e = rect_edges(lines)
    dia = 'Min_CNC_Router_Diameter'
    r = half(dia)
    gc = sk.geometricConstraints
    if along_x:     # long edges are top/bottom, short ends are left/right
        ends = (('left', add(x0, r)), ('right', sub(x1, r)))
        sides = (('bottom', y0), ('top', y1))
        combos = [(end, ex, side, sy) for end, ex in ends for side, sy in sides]
    else:           # long edges are left/right, short ends are bottom/top
        ends = (('bottom', add(y0, r)), ('top', sub(y1, r)))
        sides = (('left', x0), ('right', x1))
        combos = [(end, ey, side, sx) for end, ey in ends for side, sx in sides]
    for end, a, side, b in combos:
        cx, cy = (a, b) if along_x else (b, a)
        c = circle(sk, cx, cy, dia, locate=False)
        try:
            gc.addCoincident(c.centerSketchPoint, e[side])   # center sits on the long edge
            gc.addTangent(e[end], c)                         # tangent to the short end
        except:
            ISSUES.append('%s: dogbone constraint failed: %s' % (sk.name, last_error()))

def sketch_axes(sk):
    """How model X / Y / Z map onto this sketch: {axis: (sketch axis 0 or 1, sign)}; axes normal
    to the sketch plane are left out. Uses differences, so occurrence offsets cancel."""
    o = sk.modelToSketchSpace(adsk.core.Point3D.create(0, 0, 0))
    out = {}
    for name, v in (('x', (1, 0, 0)), ('y', (0, 1, 0)), ('z', (0, 0, 1))):
        p = sk.modelToSketchSpace(adsk.core.Point3D.create(*v))
        dx, dy = p.x - o.x, p.y - o.y
        if abs(dx) > 0.5:
            out[name] = (0, 1 if dx > 0 else -1)
        elif abs(dy) > 0.5:
            out[name] = (1, 1 if dy > 0 else -1)
    return out


def model_circle(sk, axes, coords, dia):
    """A dimensioned circle centered at model coordinates {axis: expression} (the two in-plane
    axes of this sketch)."""
    se = ['0', '0']
    for ax, e in coords.items():
        i, s = axes[ax]
        se[i] = e if s > 0 else neg(e)
    return circle(sk, se[0], se[1], dia)


def all_profiles(sk):
    col = adsk.core.ObjectCollection.create()
    for p in sk.profiles:
        col.add(p)
    return col

def offset_plane(comp, base_plane, expr):
    pin = comp.constructionPlanes.createInput()
    pin.setByOffset(base_plane, vi(expr))
    return comp.constructionPlanes.add(pin)


# ----------------------------------------------------------------------------------
def find_edges(body, axis, targets, tol=0.02):
    """Straight edges of body parallel to `axis` ('z' or 'y') whose position in the other
    two coordinates matches one of `targets` (a, b) in mm. Axis z: (x, y); axis y: (x, z)."""
    found = adsk.core.ObjectCollection.create()
    for e in body.edges:
        try:
            if e.geometry.curveType != adsk.core.Curve3DTypes.Line3DCurveType:
                continue
            a, b = e.startVertex.geometry, e.endVertex.geometry
            if axis == 'z':
                if abs(a.x - b.x) > 1e-6 or abs(a.y - b.y) > 1e-6:
                    continue
                pos = (a.x / MM, a.y / MM)
            else:
                if abs(a.x - b.x) > 1e-6 or abs(a.z - b.z) > 1e-6:
                    continue
                pos = (a.x / MM, a.z / MM)
            if any(abs(pos[0] - t[0]) < tol / MM and abs(pos[1] - t[1]) < tol / MM for t in targets):
                found.add(e)
        except:
            pass
    return found

def chamfer_edges(comp, edges, distance_param, what):
    """Equal-distance chamfer on edges, bound to a parameter."""
    if edges.count == 0:
        ISSUES.append('Chamfer (%s): no matching edges found' % what)
        return
    try:
        cf = comp.features.chamferFeatures
        try:
            inp = cf.createInput2()
            inp.chamferEdgeSets.addEqualDistanceChamferEdgeSet(edges, vi(distance_param), False)
        except:     # older Fusion API
            inp = cf.createInput(edges, False)
            inp.setToEqualDistance(vi(distance_param))
        cf.add(inp)
    except:
        ISSUES.append('Chamfer (%s, %s) failed: %s' % (what, distance_param, last_error()))


def fillet_edges(comp, edges, radius_param, what):
    if edges.count == 0:
        ISSUES.append('Fillet (%s): no matching edges found' % what)
        return
    try:
        fi = comp.features.filletFeatures
        inp = fi.createInput()
        inp.addConstantRadiusEdgeSet(edges, vi(radius_param), True)
        fi.add(inp)
    except:
        ISSUES.append('Fillet (%s, %s) failed: %s' % (what, radius_param, last_error()))


# ----------------------------------------------------------------------------------
# Sheet metal helpers (nickel strips)
# ----------------------------------------------------------------------------------
class SheetMetalUnavailable(Exception):
    """This Fusion has no usable sheet metal API (rules, base flange or fold): the strips are
    built as plain plates instead."""


def poly(sk, pts):
    """Closed polygon through (x, y) expression pairs, every vertex dimensioned to the origin
    (no horizontal / vertical constraints, so nothing is over-constrained)."""
    lines = sk.sketchCurves.sketchLines
    first = lines.addByTwoPoints(pt(*pts[0]), pt(*pts[1]))
    verts = [first.startSketchPoint, first.endSketchPoint]
    prev = first
    for p in pts[2:]:
        prev = lines.addByTwoPoints(prev.endSketchPoint, pt(*p))
        verts.append(prev.endSketchPoint)
    lines.addByTwoPoints(prev.endSketchPoint, first.startSketchPoint)
    for sp, (xe, ye) in zip(verts, pts):
        place(sk, sp, xe, ye)


def sketch_line(sk, p0, p1):
    """A dimensioned line between two (x, y) expression pairs."""
    ln = sk.sketchCurves.sketchLines.addByTwoPoints(pt(*p0), pt(*p1))
    place(sk, ln.startSketchPoint, *p0)
    place(sk, ln.endSketchPoint, *p1)
    return ln


def obround(sk, cx, cy, length, width):
    """A slot along sketch Y with round ends (length end to end), fully dimensioned: the bottom
    end's center from the origin, the top center straight above it, and both end radii."""
    r, d = half(width), sub(length, width)
    y0, y1 = sub(cy, half(d)), add(cy, half(d))
    arcs = sk.sketchCurves.sketchArcs
    a0 = arcs.addByCenterStartSweep(pt(cx, y0), pt(sub(cx, r), y0), math.pi)   # bottom end, through its bottom
    a1 = arcs.addByCenterStartSweep(pt(cx, y1), pt(add(cx, r), y1), math.pi)   # top end, through its top
    lines = sk.sketchCurves.sketchLines
    sides = [lines.addByTwoPoints(a0.endSketchPoint, a1.startSketchPoint),
             lines.addByTwoPoints(a1.endSketchPoint, a0.startSketchPoint)]
    gc = sk.geometricConstraints
    for ln in sides:
        for a in (a0, a1):
            try:
                gc.addTangent(a, ln)
            except:
                ISSUES.append('%s: slot tangent constraint failed: %s' % (sk.name, last_error()))
    place(sk, a0.centerSketchPoint, cx, y0)
    try:
        gc.addVerticalPoints(a0.centerSketchPoint, a1.centerSketchPoint)
    except:
        ISSUES.append('%s: slot alignment failed: %s' % (sk.name, last_error()))
    dim_lin(sk, a0.centerSketchPoint, a1.centerSketchPoint, False, d)
    for a in (a0, a1):
        try:
            g = a.centerSketchPoint.geometry
            tp = adsk.core.Point3D.create(g.x + ev(width) * MM, g.y, 0)
            sk.sketchDimensions.addRadialDimension(a, tp).parameter.expression = r
        except:
            ISSUES.append('%s: slot radius "%s" failed: %s' % (sk.name, r, last_error()))


def bbox_mm(body):
    b = body.boundingBox
    return ((b.minPoint.x / MM, b.minPoint.y / MM, b.minPoint.z / MM),
            (b.maxPoint.x / MM, b.maxPoint.y / MM, b.maxPoint.z / MM))


def strip_rule(design):
    """The design's sheet metal rule for the nickel strips: a copy of a metric library rule, set
    to the strip's thickness, bend radius and K factor. Raises SheetMetalUnavailable."""
    name = 'Nickel strip (mm)'
    try:
        rules = design.designSheetMetalRules
    except:
        raise SheetMetalUnavailable('no designSheetMetalRules: %s' % last_error())
    rule = None
    try:
        rule = rules.itemByName(name)
    except:       # a new document has no sheet metal data until a rule is added
        rule = None
    if rule is None:
        try:
            lib = design.librarySheetMetalRules
            src = None
            for i in range(lib.count):
                if '(mm)' in lib.item(i).name:
                    src = lib.item(i)
                    break
            if src is None:
                src = lib.item(0)
            rule = rules.addByCopy(src, name)
        except:
            raise SheetMetalUnavailable('could not make the sheet metal rule: %s' % last_error())
    try:
        rule.thickness.expression = '%.4f mm' % VALS['Strip_Thickness']
        rule.bendRadius.expression = '%.4f mm' % VALS['Strip_Bend_Radius']
        rule.kFactor = VALS['Strip_K_Factor']
    except:
        raise SheetMetalUnavailable('could not set the sheet metal rule values: %s' % last_error())
    return rule


def planar_faces(body, axis):
    """Planar faces of body whose normal lies along axis (0 = X, 1 = Y, 2 = Z), with their centroid
    in mm: [(face, (x, y, z), area)]."""
    out = []
    for f in body.faces:
        try:
            g = f.geometry
            if g.surfaceType != adsk.core.SurfaceTypes.PlaneSurfaceType:
                continue
            n = (g.normal.x, g.normal.y, g.normal.z)
            if abs(abs(n[axis]) - 1.0) > 1e-6:
                continue
            c = f.centroid
            out.append((f, (c.x / MM, c.y / MM, c.z / MM), f.area))
        except:
            pass
    return out


def find_hardware_file(part):
    """fusion/hardware/<part>*.step or .stp, or None."""
    folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'hardware')
    if not os.path.isdir(folder):
        return None
    for fn in sorted(os.listdir(folder)):
        base, ext = os.path.splitext(fn)
        if ext.lower() in ('.step', '.stp') and base.upper().startswith(part.upper()):
            return os.path.join(folder, fn)
    return None


def screw_frame(body):
    """Work out an imported screw's axis from its geometry (STEP files come in any orientation).
    `body` is the native body, so everything is in its own component's space (cm).
    Returns (under_head_point, unit vector head->tip, length under the head in mm)."""
    bb = body.boundingBox
    lo = [bb.minPoint.x, bb.minPoint.y, bb.minPoint.z]
    hi = [bb.maxPoint.x, bb.maxPoint.y, bb.maxPoint.z]
    ext = [hi[i] - lo[i] for i in range(3)]
    k = ext.index(max(ext))                       # the screw axis is its longest extent
    others = [i for i in range(3) if i != k]
    ctr = [(lo[i] + hi[i]) / 2.0 for i in range(3)]
    probe_r = 0.4 * min(ext[others[0]], ext[others[1]])   # outside the shank, inside the head/flange
    outside = adsk.fusion.PointContainment.PointOutsidePointContainment

    def solid_at(axial):
        for o in others:
            for sgn in (1, -1):
                p = list(ctr)
                p[k] = axial
                p[o] += sgn * probe_r
                if body.pointContainment(adsk.core.Point3D.create(p[0], p[1], p[2])) != outside:
                    return True
        return False

    n = 400
    step = ext[k] / n
    samples = [solid_at(lo[k] + (i + 0.5) * step) for i in range(n)]
    head_lo = any(samples[:n // 4])
    head_hi = any(samples[-(n // 4):])
    if head_lo == head_hi:
        raise RuntimeError('could not tell the screw head from its tip')
    if head_lo:       # head at the low end: under-head is just past the last solid sample
        last = max(i for i in range(n) if samples[i])
        under = lo[k] + (last + 1) * step
        axis_sign = 1.0
        shank = hi[k] - under
    else:
        first = min(i for i in range(n) if samples[i])
        under = lo[k] + first * step
        axis_sign = -1.0
        shank = under - lo[k]
    p = list(ctr)
    p[k] = under
    a = [0.0, 0.0, 0.0]
    a[k] = axis_sign
    return (adsk.core.Point3D.create(p[0], p[1], p[2]),
            adsk.core.Vector3D.create(a[0], a[1], a[2]), shank / MM)


def place_screws(design, target_comp, step_path, targets):
    """Import the screw STEP once and put an occurrence of it at each target.
    targets: [(x_mm, y_mm, z_mm, inward_z_sign)], the point where the underside of the head sits
    and the direction the shank points (+1 / -1 along Z).
    Returns (component, shank length in mm, number placed). Each stage raises with its own name."""
    stage = 'import'
    try:
        # Import into a component of its own inside target_comp. That occurrence stays hidden at
        # the origin; every bolt point gets a copy of it, so nothing is deleted.
        src = target_comp.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        screw_comp = src.component
        screw_comp.name = 'McMaster_%s' % SCREW_PART
        im = adsk.core.Application.get().importManager
        im.importToTarget(im.createSTEPImportOptions(step_path), screw_comp)

        stage = 'unground'   # imported occurrences can come in grounded, which blocks moving them
        for o in [src] + list(screw_comp.allOccurrences):
            try:
                o.isGroundToParent = False
            except:
                pass

        stage = 'find body'
        best = None   # (volume, body, transform from the body's component into screw_comp)
        for b in screw_comp.bRepBodies:
            if best is None or b.volume > best[0]:
                best = (b.volume, b, None)
        for o in screw_comp.allOccurrences:   # STEP assemblies come in as nested occurrences
            for b in o.component.bRepBodies:
                if best is None or b.volume > best[0]:
                    best = (b.volume, b, o.transform2)
        if best is None:
            raise RuntimeError('the STEP file has no solid bodies')
        _, body, to_screw = best
        # The screw keeps the appearance from its STEP file: no material or appearance is set on it.

        stage = 'find screw axis'
        under_pt, axis, shank_mm = screw_frame(body)
        if to_screw is not None:
            under_pt.transformBy(to_screw)
            axis.transformBy(to_screw)

        stage = 'placement matrices'
        # Any vector not parallel to the axis gives the from-frame's X
        ref = adsk.core.Vector3D.create(1, 0, 0) if abs(axis.x) < 0.9 else adsk.core.Vector3D.create(0, 1, 0)
        xf = axis.crossProduct(ref)
        xf.normalize()
        yf = axis.crossProduct(xf)
        mats = []
        for (x, y, z, inward) in targets:
            zt = adsk.core.Vector3D.create(0, 0, inward)
            xt = adsk.core.Vector3D.create(1, 0, 0)
            yt = zt.crossProduct(xt)
            m = adsk.core.Matrix3D.create()
            m.setToAlignCoordinateSystems(under_pt, xf, yf, axis,
                                          adsk.core.Point3D.create(x * MM, y * MM, z * MM), xt, yt, zt)
            mats.append(m)

        # A copy at every bolt point. Fusion will not move the nested imported occurrence itself,
        # so that one stays hidden at the origin (it holds the screw's geometry for the copies).
        stage = 'copies'
        for m in mats:
            target_comp.occurrences.addExistingComponent(screw_comp, m)
        placed = len(mats)
        src.isLightBulbOn = False
        return screw_comp, shank_mm, placed
    except Exception:
        raise RuntimeError('stage "%s": %s' % (stage, last_error()))


def apply_looks(app, design, groups):
    """Assign physical materials and appearances by searching Fusion's libraries for keywords.
    Returns one summary line per group so you can see what was (or was not) found."""
    mats, apps = [], []
    try:
        for i in range(app.materialLibraries.count):
            lib = app.materialLibraries.item(i)
            for coll, out in ((lib.materials, mats), (lib.appearances, apps)):
                try:
                    for j in range(coll.count):
                        out.append((coll.item(j).name, coll.item(j)))
                except:
                    pass
    except:
        pass

    def find(items, kwsets, exclude=()):
        """First keyword set that matches wins. Keywords match whole words (so 'abs' does not hit
        'Formlabs'), and among several matches the shortest name is used (the plain variant)."""
        for kws in kwsets:
            hits = [(n, o) for n, o in items
                    if all(re.search(r'(?<![a-z0-9])' + re.escape(k) + r'(?![a-z0-9])', n.lower()) for k in kws)
                    and not any(x in n.lower() for x in exclude)]
            if hits:
                return min(hits, key=lambda h: len(h[0]))[1]
        return None

    def tinted(lib_app, name, rgb):
        """A copy of lib_app named name, recoloured to rgb. Returns (appearance, status): status
        says whether the colour took ('tinted', 'kept', or why not)."""
        ap = design.appearances.itemByName(name)
        if ap is None:
            ap = design.appearances.addByCopy(lib_app, name)
        if not rgb:
            return ap, 'kept'
        color = adsk.core.Color.create(rgb[0], rgb[1], rgb[2], 255)
        props = [p for p in ap.appearanceProperties if isinstance(p, adsk.core.ColorProperty)]
        # The main colour first ('Color' in most appearances), then any other plain colour property
        props.sort(key=lambda p: 0 if p.name.lower() in ('color', 'generic color', 'base color') else 1)
        done = 0
        for p in props:
            try:
                if getattr(p, 'connectedTexture', None) is not None:
                    continue          # an image drives this colour; setting the value would not show
                p.value = color
                done += 1
                if p.name.lower() in ('color', 'generic color', 'base color'):
                    break
            except:
                pass
        if not done:
            return ap, 'tint not applied (no plain colour property)'
        v = props[0].value if props else None
        ok = v is not None and (v.red, v.green, v.blue) == tuple(rgb)
        return ap, 'tinted' if ok else 'tint may not have taken'

    # Appearance names containing any of these are skipped (colored / see-through finishes), so a
    # tint that does not take leaves a neutral part rather than a red or white one
    COLORED = ('blue', 'red', 'green', 'gold', 'yellow', 'orange', 'purple', 'pink', 'black', 'white',
               'anodized', 'bronze', 'brown', 'beige', 'cyan', 'magenta')
    SEE_THROUGH = ('clear', 'translucent', 'transparent', 'glass', 'smoke', 'tint')
    NEUTRAL = COLORED + SEE_THROUGH

    #  key, label, material keywords, appearance keywords, tint color, appearance name, excluded words
    spec = [
        ('PC', 'Polycarbonate', [('polycarbonate',)],
         [('plastic', 'matte'), ('plastic', 'opaque'), ('plastic',)], (58, 60, 64),
         'Dark_Grey_Polycarbonate', NEUTRAL),
        ('BASE', 'Base plate', [('aluminum', '6061'), ('aluminum',)],
         [('aluminum', 'brushed'), ('aluminum', 'satin'), ('aluminum',)], None, 'Brushed_Aluminum', COLORED),
        ('STANDOFF', 'Standoffs', [('aluminum',)],
         [('aluminum', 'satin'), ('aluminum', 'brushed'), ('aluminum',)], (192, 194, 198),
         'Standoff_Aluminum', COLORED),
        ('TRAY', 'BMS tray (ABS)', [('abs',)],
         [('abs',), ('plastic', 'matte'), ('plastic',)], (35, 35, 38), 'ABS_Tray', NEUTRAL),
        ('NICKEL', 'Nickel strips', [('nickel',)],
         [('nickel',), ('steel', 'polished'), ('chrome',)], (200, 199, 190), 'Nickel_Strip', COLORED),
        ('HOLDER', 'Cell holders', [('abs',)],
         [('plastic', 'matte'), ('abs',), ('plastic',)], (20, 21, 23), 'Cell_Holder_Black', NEUTRAL),
        ('FOAM', 'Foam', [],
         [('foam',), ('rubber', 'matte'), ('fabric',), ('rubber',)], (40, 40, 44), 'Neoprene_Foam', NEUTRAL),
        ('CELL', 'Cells', [],
         [('plastic', 'glossy'), ('paint', 'glossy'), ('plastic',)], (25, 95, 200), 'Cell_Wrap_Blue', NEUTRAL),
    ]
    out = []
    for key, label, mat_kws, app_kws, rgb, ap_name, exclude in spec:
        bodies = groups.get(key, [])
        if not bodies:
            continue
        got_m, got_a = '-', 'not found'
        try:
            m = find(mats, mat_kws) if mat_kws else None
            if m is not None:
                for b in bodies:
                    b.material = m
                got_m = m.name
        except:
            got_m = 'failed'
        try:
            a = find(apps, app_kws, exclude)
            if a is not None:
                ap, status = tinted(a, ap_name, rgb)
                for b in bodies:
                    b.appearance = ap
                got_a = '%s (from %s, %s)' % (ap.name, a.name, status)
        except:
            got_a = 'failed: ' + last_error()
        out.append('%s: appearance=%s, material=%s' % (label, got_a, got_m))
    return out


class Cancelled(Exception):
    pass


def run(context):
    ui = None
    prog = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        design = app.activeProduct
        if not isinstance(design, adsk.fusion.Design):
            ui.messageBox('Please switch to the Design workspace in Fusion 360 before running this script.')
            return
        try:
            design.designType = adsk.fusion.DesignTypes.ParametricDesignType
        except:
            pass
        rootComp = design.rootComponent
        design.fusionUnitsManager.distanceDisplayUnits = adsk.fusion.DistanceUnits.MillimeterDistanceUnits

        # Progress dialog: shows the current stage, has a Cancel button, and each stage
        # is also written to the Text Commands panel.
        prog = ui.createProgressDialog()
        prog.isCancelButtonShown = True
        prog.show('Generating enclosure', 'Starting...', 0, 6, 0)   # last arg: delay in s before it appears

        def say(msg):
            prog.message = msg
            adsk.doEvents()              # lets Fusion repaint the dialog
            app.log(msg)
            if prog.wasCancelled:
                raise Cancelled()

        timings = []   # (stage, seconds), shown in the result dialog
        t_start = [time.time()]

        def step(msg):
            now = time.time()
            if timings or prog.progressValue:
                timings[-1] = (timings[-1][0], now - t_start[0])
            t_start[0] = now
            timings.append((msg.split('  ', 1)[-1].rstrip('.'), 0.0))
            prog.progressValue += 1
            say(msg)

        step('1/6  Setting up parameters...')
        setup_parameters(design)
        cols = int(round(VALS['Columns']))
        rows = int(round(VALS['Rows']))
        fallback_pattern = False

        # Remove a previously generated assembly
        for o in list(rootComp.occurrences):
            if o.component.name.startswith(('EBike_Battery_Enclosure', '_screw_import')):   # + leftovers from an older screw import
                o.deleteMe()

        occ = rootComp.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        assy = occ.component
        assy.name = 'EBike_Battery_Enclosure_%dS%dP' % (cols, rows)

        part_occs = {}

        def new_part(name, slide=True):
            m = adsk.core.Matrix3D.create()
            if slide and BASE_PLATE:   # battery parts are slid -X relative to the base plate
                m.translation = adsk.core.Vector3D.create(-VALS['Battery_Latch_Slide'] * MM, 0, 0)
            po = assy.occurrences.addNewComponent(m)
            po.component.name = name
            part_occs[name] = po
            return po.component

        # ---- Layout decided at run time (structural; re-run to respace) ----
        # Every side-plate edge runs bolt, tab, bolt, ..., bolt, evenly spaced between its end
        # bolts (same rule as pack.geometry.edge_tabs). Counts are fixed when the script runs; the
        # spacing and lengths are parameters.
        PW2, PH2 = half('Plate_Width'), half('Plate_Height')
        CW2, CH2 = half('Cavity_Width'), half('Cavity_Height')
        bxe = sub(PW2, 'Bolt_Edge_Offset')
        bye = sub(PH2, 'Bolt_Edge_Offset')

        def edge(prefix, span_expr, min_count):
            n, pitch, length, offset = edge_layout(ev(span_expr), VALS, min_count)
            pname = prefix + '_Tab_Pitch'
            runtime_param(design, pname, '(%s) / %d' % (span_expr, n), 'mm',
                          'Bolt and tab spacing along the %s edges' % prefix.lower())
            runtime_param(design, prefix + '_Tab_Length', '%g mm' % length, 'mm',
                          'Tab (and slot) length on the %s walls' % prefix.lower())
            even = ['(2 * %d + 1 - %d) * %s / 2' % (i, n, pname) for i in range(n)]
            inner_bolts = ['(2 * %d - %d) * %s / 2' % (i, n, pname) for i in range(1, n)]
            if offset is None:
                return even, even, inner_bolts
            oname = prefix + '_Tab_Offset'
            runtime_param(design, oname, '%.4f mm' % offset, 'mm',
                          'Tight edge: tab center distance from the middle (no bolt between the tabs)')
            return [neg(oname), oname], even, []

        # Two standoffs per corner, each slid back along its edge, and a 45 degree plate corner
        # around them (pack.geometry.corner_slide). Small packs slide less, or keep one corner bolt.
        # With a base plate only the top corners: the bottom two sit on the base plate and keep one
        # standoff and a round corner each.
        slide, slide_full = corner_slide(ev('Plate_Width - 2 * Bolt_Edge_Offset'),
                                         ev('Plate_Height - 2 * Bolt_Edge_Offset'), VALS, BASE_PLATE)
        runtime_param(design, 'Corner_Bolt_Slide',
                      'Standoff_OD * 1.70710678 - Corner_Strap_Clearance * 1.41421356' if slide_full else '%.4f mm' % slide,
                      'mm', 'How far each corner standoff sits back along its edge (0: one standoff at the corner)')
        runtime_param(design, 'Corner_Chamfer',
                      'Corner_Bolt_Slide + Bolt_Edge_Offset * 0.58578644' if slide > 0 else '0 mm',
                      'mm', 'Length the 45 degree corner cuts off each side plate edge')

        # Both long walls share one tab layout, spaced between the top edge's end bolts
        tab_xs, hook_slots, long_inner = edge('Long', 'Plate_Width - 2 * Bolt_Edge_Offset - 2 * Corner_Bolt_Slide', 2)
        if BASE_PLATE:   # short edges run from the bottom corner bolt to the slid top bolt
            tab_ys, _even_ys, short_inner = edge('Short', 'Plate_Height - 2 * Bolt_Edge_Offset - Corner_Bolt_Slide', 1)
            tab_ys = [sub(y, half('Corner_Bolt_Slide')) for y in tab_ys]
            short_inner = [sub(y, half('Corner_Bolt_Slide')) for y in short_inner]
        else:
            tab_ys, _even_ys, short_inner = edge('Short', 'Plate_Height - 2 * Bolt_Edge_Offset - 2 * Corner_Bolt_Slide', 1)

        # One hook per bottom tab at the even pitch (on a tight edge the tabs are pulled in but the
        # hooks stay spread out); a single centered hook if two would crowd the base plate.
        if not BASE_PLATE:
            hook_xs = []    # no base plate, so nothing for hooks to latch into
        else:
            hook_xs = hook_slots
            if len(hook_xs) > 1 and not hooks_fit([ev(x) for x in hook_xs], VALS, straight_half(VALS)):
                hook_xs = ['0']

        # Bolts at the ends of every edge and midway between tabs (the standoffs hug the walls).
        # A slid corner gives each edge its own end bolt; a round corner has one corner bolt, kept
        # in the top / bottom row.
        bxs, bys = sub(bxe, 'Corner_Bolt_Slide'), sub(bye, 'Corner_Bolt_Slide')
        row_xs = [neg(bxs)] + long_inner + [bxs]
        bottom_xs = ([neg(bxe)] + long_inner + [bxe]) if BASE_PLATE else row_xs
        col_ys = list(short_inner)
        if slide > 0:
            col_ys.append(bys)
            if not BASE_PLATE:
                col_ys.insert(0, neg(bys))
        bolt_pts = ([(x, bye) for x in row_xs] + [(x, neg(bye)) for x in bottom_xs]
                    + [(neg(bxe), y) for y in col_ys] + [(bxe, y) for y in col_ys])

        # ==============================================================================
        # 1. SIDE PLATES (polycarbonate) with slots, dogbones, bolt holes and L-hooks
        # ==============================================================================
        step('2/6  Building side plates (slowest step)...')
        sideComp = new_part('PC_Side_Plates')
        left_plane = offset_plane(sideComp, sideComp.xYConstructionPlane,
                                  '-(Cavity_Depth/2 + Polycarbonate_Thickness)')

        def build_side_plate(plane, name):
            say('2/6  Side plate: ' + name + '...')
            sk = new_sketch(sideComp, plane, name + '_Outline')
            rect(sk, neg(PW2), PW2, neg(PH2), PH2, 'Plate_Width', 'Plate_Height')
            for hx in hook_xs:
                nx0 = sub(hx, half('Hook_Neck_Width'))
                nx1 = add(hx, half('Hook_Neck_Width'))
                y_low = neg(add(PH2, 'Hook_Drop'))
                rect(sk, nx0, nx1, y_low, sub('Hook_Overlap', PH2), 'Hook_Neck_Width', None)
                rect(sk, sub(nx0, 'Hook_Nose'), hx, y_low, neg(add(PH2, 'Alu_Thickness')), None, None)   # nose points -X
            ext_in = sideComp.features.extrudeFeatures.createInput(
                all_profiles(sk), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            ext_in.setDistanceExtent(False, vi('Polycarbonate_Thickness'))
            feat = sideComp.features.extrudeFeatures.add(ext_in)
            bodies = []
            for i in range(feat.bodies.count):
                b = feat.bodies.item(i)
                b.name = name if i == 0 else '%s_%d' % (name, i)
                bodies.append(b)

            # Plate corners: cut off at 45 degrees (when the corner bolts are slid back), then every
            # outline corner rounded about its bolt. Small fillets on the hooks' outside corners.
            # With a base plate only the top corners are cut; the bottom two stay round.
            pw2, ph2 = VALS['Plate_Width'] / 2.0, VALS['Plate_Height'] / 2.0
            cut_ys = (1,) if BASE_PLATE else (-1, 1)
            big = [(sx * pw2, sy * ph2) for sx in (-1, 1) for sy in (-1, 1)]
            if slide > 0:
                cut = [(sx * pw2, sy * ph2) for sx in (-1, 1) for sy in cut_ys]
                chamfer_edges(sideComp, find_edges(bodies[0], 'z', cut), 'Corner_Chamfer', 'side plate corners')
                kc = VALS['Corner_Chamfer']
                big = ([(sx * pw2, sy * ph2) for sx in (-1, 1) for sy in (-1, 1) if sy not in cut_ys]
                       + [(sx * (pw2 - kc), sy * ph2) for sx in (-1, 1) for sy in cut_ys]
                       + [(sx * pw2, sy * (ph2 - kc)) for sx in (-1, 1) for sy in cut_ys])
            fillet_edges(sideComp, find_edges(bodies[0], 'z', big), 'Side_Plate_Corner_Radius', 'side plate corners')
            small = []
            for hxs in hook_xs:
                hxv = ev(hxs)
                yl = -(ph2 + VALS['Hook_Drop'])
                small += [(hxv - VALS['Hook_Neck_Width'] / 2.0 - VALS['Hook_Nose'], yl),
                          (hxv - VALS['Hook_Neck_Width'] / 2.0 - VALS['Hook_Nose'], -(ph2 + VALS['Alu_Thickness'])),
                          (hxv + VALS['Hook_Neck_Width'] / 2.0, yl)]
            if small:
                fillet_edges(sideComp, find_edges(bodies[0], 'z', small), 'Fillet_Small', 'hook corners')

            # Slots (with dogbones) and bolt holes
            skc = new_sketch(sideComp, plane, name + '_Slots_Holes')
            slot_y = add(CH2, half('Polycarbonate_Thickness'))
            for tx in tab_xs:
                for sy in (slot_y, neg(slot_y)):
                    slot(skc, sub(tx, half('Long_Tab_Length')), add(tx, half('Long_Tab_Length')),
                         sub(sy, half('Slot_Width')), add(sy, half('Slot_Width')),
                         True, 'Long_Tab_Length', 'Slot_Width')
            slot_x = add(CW2, half('Polycarbonate_Thickness'))
            for sx in (slot_x, neg(slot_x)):
                for ty in tab_ys:
                    slot(skc, sub(sx, half('Slot_Width')), add(sx, half('Slot_Width')),
                         sub(ty, half('Short_Tab_Length')), add(ty, half('Short_Tab_Length')),
                         False, 'Slot_Width', 'Short_Tab_Length')
            for (bx, by) in bolt_pts:
                circle(skc, bx, by, 'Bolt_Hole_Diameter')
            # Hook root reliefs, sized like the slot dogbones: a router-diameter circle centered
            # on the neck's inside edge and tangent to the nose top, so it cuts only upward into
            # the neck. The nose top stays flat for the base plate to seat on and the nose keeps
            # its full height. (A fillet here would hit the base plate when latched.)
            for hx in hook_xs:
                circle(skc, sub(hx, half('Hook_Neck_Width')),
                       neg(sub(add(PH2, 'Alu_Thickness'), half('Min_CNC_Router_Diameter'))),
                       'Min_CNC_Router_Diameter')
            # Neck-to-plate reliefs: where each neck meets the plate's bottom edge, a router circle
            # centered on the edge and tangent to the neck side, so the router leaves no radius in
            # the corner and the plate seats flat on the base plate.
            for hx in hook_xs:
                for xe in (sub(sub(hx, half('Hook_Neck_Width')), half('Min_CNC_Router_Diameter')),
                           add(add(hx, half('Hook_Neck_Width')), half('Min_CNC_Router_Diameter'))):
                    circle(skc, xe, neg(PH2), 'Min_CNC_Router_Diameter')

            cut_in = sideComp.features.extrudeFeatures.createInput(
                all_profiles(skc), adsk.fusion.FeatureOperations.CutFeatureOperation)
            cut_in.setDistanceExtent(False, vi('Polycarbonate_Thickness + Cut_Overshoot'))
            cut_in.participantBodies = bodies
            sideComp.features.extrudeFeatures.add(cut_in)
            return bodies

        front_bodies = build_side_plate(left_plane, 'Front_PC_Side_Plate')     # -Z

        # The rear plate is a mirror of the front plate about the mid-plane (Z = 0), so the two
        # stay identical and follow Cavity_Depth automatically.
        say('2/6  Mirroring the rear side plate...')
        try:
            mcol = adsk.core.ObjectCollection.create()
            for b in front_bodies:
                mcol.add(b)
            mf = sideComp.features.mirrorFeatures
            mir = mf.add(mf.createInput(mcol, sideComp.xYConstructionPlane))
            for i in range(mir.bodies.count):
                mir.bodies.item(i).name = 'Rear_PC_Side_Plate' if i == 0 else 'Rear_PC_Side_Plate_%d' % i
        except:
            ISSUES.append('Mirror of the rear side plate failed: %s' % last_error())

        if VALS['Lip_Width'] < VALS['Standoff_OD']:
            ISSUES.append('Warning: Lip_Width is smaller than Standoff_OD: the standoffs overhang the plate edge')

        # Fillet size sanity checks (a fillet that is too big makes the rebuild fail)
        if hook_xs and 2.0 * VALS['Fillet_Small'] > VALS['Hook_Drop_Extra']:
            ISSUES.append('Warning: Fillet_Small is large for the hook nose height (%.2f mm)' % VALS['Hook_Drop_Extra'])
        if hook_xs and VALS['Hook_Slot_Length'] < VALS['Hook_Neck_Width'] + VALS['Hook_Nose']:
            ISSUES.append('Warning: Hook_Slot_Length is shorter than neck + nose: the hooks will not drop through')

        # ==============================================================================
        # 2. INNER WALLS: four separate flat pieces, each with tabs (top/bottom full length, sides between)
        # ==============================================================================
        step('3/6  Building inner walls and tabs...')
        wallComp = new_part('PC_Inner_Walls')
        PCT = 'Polycarbonate_Thickness'

        def make_wall(name, x0, x1, y0, y1, w_expr, h_expr, tabs):
            """One flat wall piece as its own body. tabs = [(x0, x1, y0, y1, w_expr, h_expr)]."""
            skp = new_sketch(wallComp, wallComp.xYConstructionPlane, name + '_Profile')
            rect(skp, x0, x1, y0, y1, w_expr, h_expr)
            wi = wallComp.features.extrudeFeatures.createInput(
                skp.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            wi.setSymmetricExtent(vi('Cavity_Depth/2'), False)
            body = wallComp.features.extrudeFeatures.add(wi).bodies.item(0)
            body.name = name
            skt = new_sketch(wallComp, wallComp.xYConstructionPlane, name + '_Tabs')
            for (tx0, tx1, ty0, ty1, tw, th) in tabs:
                rect(skt, tx0, tx1, ty0, ty1, tw, th)
            ti = wallComp.features.extrudeFeatures.createInput(
                all_profiles(skt), adsk.fusion.FeatureOperations.JoinFeatureOperation)
            ti.setSymmetricExtent(vi('Cavity_Depth/2 + Tab_Depth'), False)
            try:
                ti.participantBodies = [body]
            except:
                pass
            wallComp.features.extrudeFeatures.add(ti)

        top_tabs, bot_tabs = [], []
        for tx in tab_xs:
            tx0, tx1 = sub(tx, half('Long_Tab_Length')), add(tx, half('Long_Tab_Length'))
            top_tabs.append((tx0, tx1, CH2, add(CH2, PCT), 'Long_Tab_Length', PCT))
            bot_tabs.append((tx0, tx1, neg(add(CH2, PCT)), neg(CH2), 'Long_Tab_Length', PCT))

        def short_tabs(xa, xb):
            return [(xa, xb, sub(ty, half('Short_Tab_Length')), add(ty, half('Short_Tab_Length')),
                     PCT, 'Short_Tab_Length') for ty in tab_ys]

        # Top and bottom walls run the full outside width; the left and right walls fit
        # between them (height = cavity height).
        FW = 'Cavity_Width + 2 * ' + PCT
        make_wall('Top_Wall', neg(add(CW2, PCT)), add(CW2, PCT), CH2, add(CH2, PCT), FW, PCT, top_tabs)
        make_wall('Bottom_Wall', neg(add(CW2, PCT)), add(CW2, PCT), neg(add(CH2, PCT)), neg(CH2), FW, PCT, bot_tabs)
        make_wall('Left_Wall', neg(add(CW2, PCT)), neg(CW2), neg(CH2), CH2,
                  PCT, 'Cavity_Height', short_tabs(neg(add(CW2, PCT)), neg(CW2)))
        make_wall('Right_Wall', CW2, add(CW2, PCT), neg(CH2), CH2,
                  PCT, 'Cavity_Height', short_tabs(CW2, add(CW2, PCT)))

        # Tab-root reliefs: both inside corners of every tab get a router circle centered on the
        # wall's end edge and tangent to the tab side, cut into the wall body. The tab keeps its
        # full size and the router leaves no radius where the side plate seats.
        say('3/6  Cutting tab reliefs...')
        walls = dict((b.name, b) for b in wallComp.bRepBodies)
        RD2 = half('Min_CNC_Router_Diameter')
        ZE = half('Cavity_Depth')

        def tab_reliefs(plane, name, along, centers, length_name, bodies):
            skr = new_sketch(wallComp, plane, name)
            axes = sketch_axes(skr)
            for t in centers:
                for pe in (sub(sub(t, half(length_name)), RD2), add(add(t, half(length_name)), RD2)):
                    for ze in (ZE, neg(ZE)):
                        model_circle(skr, axes, {along: pe, 'z': ze}, 'Min_CNC_Router_Diameter')
            ri = wallComp.features.extrudeFeatures.createInput(
                all_profiles(skr), adsk.fusion.FeatureOperations.CutFeatureOperation)
            ri.setAllExtent(adsk.fusion.ExtentDirections.SymmetricExtentDirection)
            ri.participantBodies = [b for b in bodies if b is not None]
            wallComp.features.extrudeFeatures.add(ri)

        try:
            tab_reliefs(wallComp.xZConstructionPlane, 'Long_Wall_Tab_Reliefs', 'x', tab_xs, 'Long_Tab_Length',
                        [walls.get('Top_Wall'), walls.get('Bottom_Wall')])
            tab_reliefs(wallComp.yZConstructionPlane, 'Short_Wall_Tab_Reliefs', 'y', tab_ys, 'Short_Tab_Length',
                        [walls.get('Left_Wall'), walls.get('Right_Wall')])
        except Cancelled:
            raise
        except:
            ISSUES.insert(0, 'Tab reliefs failed: %s' % last_error())

        # ==============================================================================
        # 3. INTERNAL CORE: BMS tray, cells (patterned), cell holders, nickel strips, foam liner
        # ==============================================================================
        step('4/6  Building cells, holders, strips, tray and foam...')
        intComp = new_part('Internal_Core_ABS_Foam_Cells')
        # Cells sit on the bottom foam; the BMS tray goes on top of them, under the top foam
        # (opposite the base plate)
        CCW2 = half('Cell_Core_Width')
        y_cells = add(neg(CH2), 'Foam_Gap')
        y_tray_bot = add(y_cells, 'Cell_Core_Height')
        y_tray_top = add(y_tray_bot, 'BMS_Height')

        # ABS tray
        sk_abs = new_sketch(intComp, intComp.xYConstructionPlane, 'BMS_Tray')
        rect(sk_abs, neg(CCW2), CCW2, y_tray_bot, y_tray_top, 'Cell_Core_Width', 'BMS_Height')
        abs_in = intComp.features.extrudeFeatures.createInput(
            sk_abs.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        abs_in.setSymmetricExtent(vi('Core_Depth/2'), False)
        intComp.features.extrudeFeatures.add(abs_in).bodies.item(0).name = 'ABS_BMS_Fuse_Wire_Tray'

        # One cell, then a rectangular pattern bound to Columns / Rows / Cell_Pitch
        sk_cell = new_sketch(intComp, intComp.xYConstructionPlane, 'Cell_Layout')
        circle(sk_cell, add(neg(CCW2), half('Cell_Pitch')), add(y_cells, half('Cell_Pitch')), 'Cell_Diameter')
        cell_in = intComp.features.extrudeFeatures.createInput(
            sk_cell.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        cell_in.setSymmetricExtent(vi('Cell_Height/2'), False)
        cell_body = intComp.features.extrudeFeatures.add(cell_in).bodies.item(0)
        cell_body.name = 'Cell'

        def make_pattern(q1, q2):
            bodies = adsk.core.ObjectCollection.create()
            bodies.add(cell_body)
            pat = intComp.features.rectangularPatternFeatures
            pin = pat.createInput(bodies, intComp.xConstructionAxis, q1, vi('Cell_Pitch'),
                                  adsk.fusion.PatternDistanceType.SpacingPatternDistanceType)
            pin.setDirectionTwo(intComp.yConstructionAxis, q2, vi('Cell_Pitch'))
            return pat.add(pin)

        try:
            make_pattern(vi('Columns'), vi('Rows'))
        except:
            fallback_pattern = True
            make_pattern(adsk.core.ValueInput.createByReal(cols), adsk.core.ValueInput.createByReal(rows))

        # Cell holders: a slab at each cell end up to the cell-end level (the outer face's channels,
        # Holder_Recess deep, cut the webs down so the strip lies flat on the cells), with one bore
        # cut and patterned over the grid (tab islands standing up to the face, interlocks left out)
        def make_holder(plane_expr, name):
            pl = offset_plane(intComp, intComp.xYConstructionPlane, plane_expr)
            sk = new_sketch(intComp, pl, name + '_Sketch')
            rect(sk, neg(CCW2), CCW2, y_cells, y_tray_bot, 'Cell_Core_Width', 'Cell_Core_Height')
            hi = intComp.features.extrudeFeatures.createInput(
                sk.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            hi.setDistanceExtent(False, vi('Holder_Height - Holder_Recess'))
            body = intComp.features.extrudeFeatures.add(hi).bodies.item(0)
            body.name = name
            try:
                skb = new_sketch(intComp, pl, name + '_Bore')
                circle(skb, add(neg(CCW2), half('Cell_Pitch')), add(y_cells, half('Cell_Pitch')), 'Holder_Bore')
                ci = intComp.features.extrudeFeatures.createInput(
                    skb.profiles.item(0), adsk.fusion.FeatureOperations.CutFeatureOperation)
                ci.setDistanceExtent(False, vi('Holder_Height - Holder_Recess'))
                ci.participantBodies = [body]
                cut = intComp.features.extrudeFeatures.add(ci)
                feats = adsk.core.ObjectCollection.create()
                feats.add(cut)
                pat = intComp.features.rectangularPatternFeatures
                pin = pat.createInput(feats, intComp.xConstructionAxis, vi('Columns'), vi('Cell_Pitch'),
                                      adsk.fusion.PatternDistanceType.SpacingPatternDistanceType)
                pin.setDirectionTwo(intComp.yConstructionAxis, vi('Rows'), vi('Cell_Pitch'))
                pat.add(pin)
            except Cancelled:
                raise
            except:
                ISSUES.append('%s: bores failed (solid holder left): %s' % (name, last_error()))

        make_holder('-(Cell_Height/2)', 'Holder_Front')
        make_holder('Cell_Height/2 + Holder_Recess - Holder_Height', 'Holder_Rear')

        # Fallback nickel strips, used only when this Fusion cannot make sheet metal (see
        # build_sheet_strips below): plain plates without holes or weld slots. Two columns per strip,
        # alternating ends; the pack terminals get a full 2P strip, half on the end column and half
        # folded around the end of the cell block. Each strip's tab leg carries on over the top of the
        # cell block and folds over the holder's top edge (the BMS balance tab).
        def extrude_all(sk, length_expr, name):
            si = intComp.features.extrudeFeatures.createInput(
                all_profiles(sk), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            si.setDistanceExtent(False, vi(length_expr))
            feat = intComp.features.extrudeFeatures.add(si)
            for i in range(feat.bodies.count):
                feat.bodies.item(i).name = '%s_%d' % (name, i + 1)

        def make_strips(end, name):
            plane_expr = 'Cell_Height/2' if end > 0 else '-(Cell_Height/2 + Strip_Thickness)'
            pl = offset_plane(intComp, intComp.xYConstructionPlane, plane_expr)
            sk = new_sketch(intComp, pl, name + '_Sketch')
            tabs, folds = [], []          # (x0, x1) of each balance tab leg; x of each fold (+1 / -1)
            for e, c0, c1 in strip_groups(cols):
                if e != end:
                    continue
                if c1 - c0 == 2:          # tab on the -X leg
                    xb = add(neg(CCW2), '%d * Cell_Pitch' % (c0 + 1))
                    x0, x1, w = sub(xb, half('Strip_Width')), add(xb, half('Strip_Width')), 'Strip_Width'
                    tabs.append((x0, add(x0, 'Strip_Leg')))
                elif c0 == 0:             # terminal: the half on the end column, its leg on the cell side
                    x0, x1, w = neg(CCW2), add(neg(CCW2), half('Strip_Width')), 'Strip_Width / 2'
                    tabs.append((sub(x1, 'Strip_Leg'), x1))
                    folds.append(-1)
                else:
                    x0, x1, w = sub(CCW2, half('Strip_Width')), CCW2, 'Strip_Width / 2'
                    tabs.append((x0, add(x0, 'Strip_Leg')))
                    folds.append(1)
                rect(sk, x0, x1, y_cells, y_tray_bot, w, 'Cell_Core_Height')
            extrude_all(sk, 'Strip_Thickness', name)

            # Balance tabs: one leg over the top of the cell block, folded back over the holder's
            # top edge to its inner face (a plate Strip_Thickness thick on the top of the block)
            try:
                tab_len = 'Strip_Thickness + Holder_Height - Holder_Recess'
                tab_plane = ('Cell_Height/2 + Holder_Recess - Holder_Height' if end > 0
                             else '-(Cell_Height/2 + Strip_Thickness)')
                skt = new_sketch(intComp, offset_plane(intComp, intComp.xYConstructionPlane, tab_plane),
                                 name + '_Balance_Tabs')
                for t0, t1 in tabs:
                    rect(skt, t0, t1, y_tray_bot, add(y_tray_bot, 'Strip_Thickness'), 'Strip_Leg', 'Strip_Thickness')
                extrude_all(skt, tab_len, name.replace('Strip', 'Tab'))
            except Cancelled:
                raise
            except:
                ISSUES.append('%s: balance tabs failed: %s' % (name, last_error()))

            # Terminal folds: the second half of the terminal strip, bent 90 degrees around the end
            # of the cell block (a plate standing just outside the block end, half a strip wide)
            if folds:
                try:
                    fold_plane = ('Cell_Height/2 + Strip_Thickness - Strip_Width/2' if end > 0
                                  else '-(Cell_Height/2 + Strip_Thickness)')
                    skf = new_sketch(intComp, offset_plane(intComp, intComp.xYConstructionPlane, fold_plane),
                                     name + '_Terminal_Folds')
                    for side in folds:
                        xe = CCW2 if side > 0 else neg(CCW2)
                        fx0, fx1 = (xe, add(xe, 'Strip_Thickness')) if side > 0 else (sub(xe, 'Strip_Thickness'), xe)
                        rect(skf, fx0, fx1, y_cells, y_tray_bot, 'Strip_Thickness', 'Cell_Core_Height')
                    extrude_all(skf, 'Strip_Width / 2', name.replace('Strip', 'Terminal_Fold'))
                except Cancelled:
                    raise
                except:
                    ISSUES.append('%s: terminal folds failed: %s' % (name, last_error()))

        # ---- Nickel strips as sheet metal parts ----
        # Each strip is one sheet metal body in its own component (rule 'Nickel strip (mm)':
        # Strip_Thickness, Strip_Bend_Radius, Strip_K_Factor), made the way it is made by hand:
        # the flat blank (a 2P ladder: two legs, a bar over every cell row, square holes between
        # the bars) is a base flange lying on the cell ends, then it is folded:
        #   * balance tab: the tab leg runs on past the top of the cell block and folds 90 degrees
        #     over the holder's top edge, its underside on the block top;
        #   * pack terminals: a full 2P strip centered on the block edge, half on the end column
        #     and half folded 90 degrees around the end of the block.
        # Weld slots (Weld_Slot_Length x Weld_Slot_Width, round ends) are cut over every cell
        # terminal: one slot, patterned Columns x Rows.
        # Fold direction and stationary side are not documented in the API, so each fold is
        # checked against where the flange must end up and retried the other way if it is wrong
        # (the working combination is reused for the rest).
        def build_sheet_strips():
            if not hasattr(design, 'designSheetMetalRules'):
                raise SheetMetalUnavailable('this Fusion has no sheet metal rule API')
            comp = new_part('Nickel_Strips')
            try:
                comp.activeSheetMetalRule = strip_rule(design)
            except SheetMetalUnavailable:
                raise
            except:
                raise SheetMetalUnavailable('could not set the active sheet metal rule: %s' % last_error())
            feats = comp.features
            if not hasattr(feats, 'flangeFeatures') or not hasattr(feats.flangeFeatures, 'createBaseFlangeInput'):
                raise SheetMetalUnavailable('this Fusion cannot create flanges from the API')
            CENTER = getattr(getattr(adsk.fusion, 'FoldBendLinePositionTypes', None),
                             'CenterFoldBendLinePositionType', None)
            folds_ok = hasattr(feats, 'foldFeatures') and CENTER is not None
            if not folds_ok:
                ISSUES.insert(0, 'Nickel strips: this Fusion has no fold API, so the strips stay flat')

            V = lambda e: ev(e)   # noqa: E731
            XL, L = neg(CCW2), 'Cell_Core_Height'
            W, LEG, R, BA = 'Strip_Width', 'Strip_Leg', 'Strip_Bend_Radius', 'Strip_Bend_Allowance'
            lo = '(Cell_Pitch/2 - Cell_Diameter/2 + Strip_End_Inset)'    # strip ends inside the end cells
            gap = '(Cell_Pitch - Strip_Bar)/2'                           # half a square hole
            # Tab leg past the block top, flat: (radius short of the top) + bend + straight flange
            # over the holder (Holder_Height - Holder_Recess - radius long)
            ext = '(%s + Holder_Height - Holder_Recess - 2 * %s)' % (BA, R)
            h2, t, r = V('Cell_Height') / 2.0, VALS['Strip_Thickness'], VALS['Strip_Bend_Radius']
            ba = VALS['Strip_Bend_Allowance']
            y_top = V(y_tray_bot)                       # top of the cell block
            tab_reach = h2 + VALS['Holder_Recess'] - VALS['Holder_Height']   # |z| where the tab flange ends
            term_reach = h2 - VALS['Strip_Width'] / 2.0 + ba - 2 * r         # |z| of a terminal fold's edge

            planes = {}

            def plane(expr):
                if expr not in planes:
                    planes[expr] = offset_plane(comp, comp.xYConstructionPlane, expr)
                return planes[expr]

            def blank_points(x0, tab_left):
                X = lambda a: add(x0, a)          # noqa: E731
                Y = lambda b: add(y_cells, b)     # noqa: E731
                tab_top, hi = add(L, ext), sub(L, lo)
                lt, rt = (tab_top, hi) if tab_left else (hi, tab_top)
                WL = sub(W, LEG)
                return [(X('0'), Y(lo)), (X(LEG), Y(lo)), (X(LEG), Y(gap)), (X(WL), Y(gap)), (X(WL), Y(lo)),
                        (X(W), Y(lo)), (X(W), Y(rt)), (X(WL), Y(rt)), (X(WL), Y(sub(L, gap))),
                        (X(LEG), Y(sub(L, gap))), (X(LEG), Y(lt)), (X('0'), Y(lt))]

            # Which side of the sketch plane the base flange thickens to is found on the first
            # strip of each end: the strip must lie on the cell ends, outward (|z| from h2 to h2 + t)
            base_plane = {}

            def make_blank(name, end, x0, tab_left):
                choices = [base_plane[end]] if end in base_plane else (
                    ['Cell_Height/2', 'Cell_Height/2 + Strip_Thickness'] if end > 0
                    else ['-(Cell_Height/2)', '-(Cell_Height/2 + Strip_Thickness)'])
                for pexpr in choices:
                    sk = new_sketch(comp, plane(pexpr), name + '_Blank')
                    poly(sk, blank_points(x0, tab_left))
                    for j in range(1, rows):
                        yc = add(y_cells, '%d * Cell_Pitch' % j)
                        rect(sk, add(x0, LEG), add(x0, sub(W, LEG)), sub(yc, gap), add(yc, gap),
                             'Strip_Width - 2 * Strip_Leg', 'Cell_Pitch - Strip_Bar')
                    prof = max(sk.profiles, key=lambda p: p.areaProperties().area)
                    try:
                        try:
                            fin = feats.flangeFeatures.createBaseFlangeInput(prof)
                        except:
                            col = adsk.core.ObjectCollection.create()
                            col.add(prof)
                            fin = feats.flangeFeatures.createBaseFlangeInput(col)
                        feat = feats.flangeFeatures.add(fin)
                    except:
                        raise SheetMetalUnavailable('base flange failed: %s' % last_error())
                    body = feat.bodies.item(0)
                    body.name = name
                    (_, _, z0), (_, _, z1) = bbox_mm(body)
                    want = (h2, h2 + t) if end > 0 else (-h2 - t, -h2)
                    if abs(z0 - want[0]) < 0.01 and abs(z1 - want[1]) < 0.01:
                        base_plane[end] = pexpr
                        return body, pexpr
                    feat.deleteMe()
                    sk.deleteMe()
                    SKETCHES.remove(sk)
                raise SheetMetalUnavailable('the base flange does not land on the cell ends (z %.2f to %.2f)' % (z0, z1))

            fold_cache = {}

            def fold(name, key, pexpr, segments, stationary, check):
                """Fold body `name` along the sketch lines `segments` (pairs of (x, y) expressions),
                keeping its `stationary` side put. Tries both bend directions and three choices of
                stationary face until check(bbox) passes; returns True, or leaves it flat."""
                if not folds_ok:
                    return False
                sk = new_sketch(comp, plane(pexpr), name + '_Bend_' + key[0])
                lines = [sketch_line(sk, a, b) for a, b in segments]
                combos = [(s, f) for f in ('side', 'near', 'far') for s in (1, -1)]
                if key in fold_cache:
                    combos.remove(fold_cache[key])
                    combos.insert(0, fold_cache[key])
                errs = []
                for sign, fkind in combos:
                    body = comp.bRepBodies.itemByName(name)
                    face = stationary(body, fkind)
                    if face is None:
                        continue
                    try:
                        fi = feats.foldFeatures.createInput(face)
                        for ln in lines:
                            fi.bendLines.add(ln, vi('%d deg' % (90 * sign)), CENTER, False)
                        feat = feats.foldFeatures.add(fi)
                    except:
                        errs.append('%+d/%s: %s' % (sign, fkind, last_error()))
                        continue
                    bad = check(bbox_mm(comp.bRepBodies.itemByName(name)))
                    if bad is None:
                        fold_cache[key] = (sign, fkind)
                        return True
                    errs.append('%+d/%s: %s' % (sign, fkind, bad))
                    try:
                        feat.deleteMe()
                    except:
                        errs.append('could not undo: %s' % last_error())
                        break
                ISSUES.append('%s: %s fold failed, left flat (%s)' % (name, key[0], '; '.join(errs[:4])))
                return False

            def big_face(body, which):
                """'near' / 'far': the strip's large face nearer to / farther from the cell ends."""
                faces = sorted(planar_faces(body, 2), key=lambda f: -f[2])[:2]
                if len(faces) < 2:
                    return None
                faces.sort(key=lambda f: abs(f[1][2]))
                return faces[0 if which == 'near' else 1][0]

            def end_face(body, axis, pick):
                """A small face on the side that must stay put: the end of a leg (axis 1, lowest)
                or the strip's outer side (axis 0, lowest or highest x)."""
                faces = planar_faces(body, axis)
                if not faces:
                    return None
                return (min if pick < 0 else max)(faces, key=lambda f: f[1][axis])[0]

            def near(a, b, tol):
                return abs(a - b) < tol

            bodies = {1: [], -1: []}
            for end, c0, c1 in strip_groups(cols):
                label = 'Rear' if end > 0 else 'Front'
                name = 'Nickel_Strip_%s_%d' % (label, len([g for g in strip_groups(cols) if g[0] == end
                                                         and g[1] <= c0]))
                say('4/6  Nickel strip %s...' % name)
                if c1 - c0 == 2:
                    x0, tab_left, term = add(XL, '(%d * Cell_Pitch - Strip_Width/2)' % (c0 + 1)), True, 0
                elif c0 == 0:
                    x0, tab_left, term = sub(XL, half(W)), False, -1
                else:
                    x0, tab_left, term = add(XL, sub('Cell_Core_Width', half(W))), True, 1
                body, pexpr = make_blank(name, end, x0, tab_left)
                bodies[end].append(name)
                (bx0, by0, bz0), (bx1, by1, bz1) = bbox_mm(body)
                z_face = end * (h2 + t)          # outer face of the strip, must not move

                # Balance tab: bend line across the tab leg, centered in the bend zone, which starts
                # one bend radius below the block top
                tx0 = x0 if tab_left else add(x0, sub(W, LEG))
                yl = add(y_tray_bot, '%s/2 - %s' % (BA, R))

                def tab_check(bb, by0=by0):
                    (_, y0, z0), (_, y1, z1) = bb
                    zin, zout = (z0, z1) if end > 0 else (-z1, -z0)
                    if not near(y0, by0, 0.05) or not near(zout, abs(z_face), 0.02):
                        return 'the strip itself moved'
                    if not near(y1, y_top + t, 0.05):
                        return 'tab top at %.2f, want %.2f' % (y1, y_top + t)
                    if not near(zin, tab_reach, 0.25):
                        return 'tab reaches |z| %.2f, want %.2f' % (zin, tab_reach)
                    return None

                tab_done = fold(name, ('tab', end), pexpr, [((tx0, yl), (add(tx0, LEG), yl))],
                                lambda b, k: end_face(b, 1, -1) if k == 'side' else big_face(b, k), tab_check)

                # Pack terminal: fold the outer half around the end of the block. Bend line along Y
                # through the bars (one segment per bar, so it never crosses a hole), centered in
                # the bend zone, which starts one bend radius in from the block edge.
                if term:
                    xe = XL if term < 0 else CCW2
                    xl = (add(xe, '%s - %s/2' % (R, BA)) if term < 0 else sub(xe, '%s - %s/2' % (R, BA)))
                    segs = []
                    for j in range(rows):
                        yb = add(y_cells, '%d * Cell_Pitch' % j)
                        segs.append(((xl, add(yb, gap)), (xl, add(yb, sub('Cell_Pitch', gap)))))
                    x_edge = V(xe) + term * t     # outer face of the folded half
                    x_keep = bx1 if term < 0 else bx0
                    reach = min(term_reach, tab_reach if tab_done else h2)   # deepest |z| after the fold

                    def term_check(bb):
                        (x0_, _, z0), (x1_, _, z1) = bb
                        zin, zout = (z0, z1) if end > 0 else (-z1, -z0)
                        if not near(x1_ if term < 0 else x0_, x_keep, 0.05) or not near(zout, abs(z_face), 0.02):
                            return 'the strip itself moved'
                        if not near(x0_ if term < 0 else x1_, x_edge, 0.05):
                            return 'fold face at x %.2f, want %.2f' % (x0_ if term < 0 else x1_, x_edge)
                        if not near(zin, reach, 0.25):
                            return 'fold reaches |z| %.2f, want %.2f' % (zin, reach)
                        return None

                    fold(name, ('terminal', end, term), pexpr, segs,
                         lambda b, k: end_face(b, 0, -term) if k == 'side' else big_face(b, k), term_check)

            # Weld slots over every cell terminal: one slot through the strip, patterned over the grid
            for end in (1, -1):
                if not bodies[end]:
                    continue
                label = 'Rear' if end > 0 else 'Front'
                try:
                    say('4/6  Weld slots, %s...' % label.lower())
                    mid = 'Cell_Height/2 + Strip_Thickness/2'
                    sk = new_sketch(comp, plane(mid if end > 0 else neg(mid)), 'Weld_Slots_' + label)
                    cx, cy = add(XL, half('Cell_Pitch')), add(y_cells, half('Cell_Pitch'))
                    try:
                        obround(sk, cx, cy, 'Weld_Slot_Length', 'Weld_Slot_Width')
                    except Cancelled:
                        raise
                    except:
                        ISSUES.append('Weld slot %s: round-ended slot failed, rectangle used: %s' % (label, last_error()))
                        rect(sk, sub(cx, half('Weld_Slot_Width')), add(cx, half('Weld_Slot_Width')),
                             sub(cy, half('Weld_Slot_Length')), add(cy, half('Weld_Slot_Length')),
                             'Weld_Slot_Width', 'Weld_Slot_Length')
                    ci = feats.extrudeFeatures.createInput(sk.profiles.item(0),
                                                           adsk.fusion.FeatureOperations.CutFeatureOperation)
                    ci.setSymmetricExtent(vi('Strip_Thickness'), False)
                    ci.participantBodies = [comp.bRepBodies.itemByName(n) for n in bodies[end]]
                    cut = feats.extrudeFeatures.add(ci)
                    fc = adsk.core.ObjectCollection.create()
                    fc.add(cut)
                    pin = feats.rectangularPatternFeatures.createInput(
                        fc, comp.xConstructionAxis, vi('Columns'), vi('Cell_Pitch'),
                        adsk.fusion.PatternDistanceType.SpacingPatternDistanceType)
                    pin.setDirectionTwo(comp.yConstructionAxis, vi('Rows'), vi('Cell_Pitch'))
                    try:     # each copy lands on a different strip: recompute every instance
                        pin.patternComputeOption = adsk.fusion.PatternComputeOptions.AdjustPatternCompute
                    except:
                        pass
                    feats.rectangularPatternFeatures.add(pin)
                except Cancelled:
                    raise
                except:
                    ISSUES.append('Weld slots %s failed: %s' % (label, last_error()))
            return comp

        stripComp = None
        try:
            stripComp = build_sheet_strips()
        except Cancelled:
            raise
        except SheetMetalUnavailable as exc:
            ISSUES.insert(0, 'Nickel strips built as plates (no sheet metal): %s' % exc)
            if 'Nickel_Strips' in part_occs:
                try:
                    SKETCHES[:] = [s for s in SKETCHES if s.parentComponent.name != 'Nickel_Strips']
                    part_occs.pop('Nickel_Strips').deleteMe()
                except:
                    ISSUES.append('Could not remove the half-built sheet metal strips: %s' % last_error())
            try:
                make_strips(-1, 'Nickel_Strip_Front')
                make_strips(1, 'Nickel_Strip_Rear')
            except Cancelled:
                raise
            except:
                ISSUES.append('Nickel strips failed: %s' % last_error())
        except:
            ISSUES.insert(0, 'Nickel strips (sheet metal) failed: %s' % last_error())

        # Foam liner (perimeter ring), drawn at its full uncompressed thickness: it overlaps the
        # cell block and holders by Foam_Compression (the squeeze)
        sk_foam = new_sketch(intComp, intComp.xYConstructionPlane, 'Foam_Liner')
        rect(sk_foam, neg(CW2), CW2, neg(CH2), CH2, 'Cavity_Width', 'Cavity_Height')
        fi_x = sub(CW2, 'Foam_Thickness')
        fi_y = sub(CH2, 'Foam_Thickness')
        rect(sk_foam, neg(fi_x), fi_x, neg(fi_y), fi_y,
             'Cavity_Width - 2 * Foam_Thickness', 'Cavity_Height - 2 * Foam_Thickness')
        for p in sk_foam.profiles:
            if p.profileLoops.count == 2:
                fe = intComp.features.extrudeFeatures.createInput(
                    p, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
                fe.setSymmetricExtent(vi('Core_Depth/2'), False)
                intComp.features.extrudeFeatures.add(fe).bodies.item(0).name = 'Neoprene_Foam_Perimeter'
                break

        # Foam pads on the inside faces of the side plates (between the holders and the plates)
        def make_foam_pad(plane_expr, name):
            pl = offset_plane(intComp, intComp.xYConstructionPlane, plane_expr)
            sk = new_sketch(intComp, pl, name + '_Sketch')
            rect(sk, neg(CW2), CW2, neg(CH2), CH2, 'Cavity_Width', 'Cavity_Height')
            fi = intComp.features.extrudeFeatures.createInput(
                sk.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            fi.setDistanceExtent(False, vi('Foam_Thickness'))
            intComp.features.extrudeFeatures.add(fi).bodies.item(0).name = name

        try:   # full thickness from the side plate inward (overlapping the holder faces by the squeeze)
            make_foam_pad('-(Cavity_Depth/2)', 'Neoprene_Foam_Side_Front')
            make_foam_pad('Cavity_Depth/2 - Foam_Thickness', 'Neoprene_Foam_Side_Rear')
        except Cancelled:
            raise
        except:
            ISSUES.append('Side foam pads failed: %s' % last_error())

        # ==============================================================================
        # 4. ALUMINUM BASE PLATE
        # ==============================================================================
        baseComp = None
        if not BASE_PLATE:
            step('5/6  No base plate (BASE_PLATE = False)')
        else:
            step('5/6  Building aluminum base plate...')
            baseComp = new_part('Alu_6061_Base_Plate', slide=False)
            base_plane = offset_plane(baseComp, baseComp.xYConstructionPlane,
                                      '-(Cavity_Depth/2 + Polycarbonate_Thickness + Side_Extension)')
            sk_base = new_sketch(baseComp, base_plane, 'Base_Profile')
            # Extensions are measured from the battery's slid (latched) position
            bx0 = neg(add(add(PW2, 'Base_Rear_Extension'), 'Battery_Latch_Slide'))
            bx1 = sub(add(PW2, 'Base_Front_Extension'), 'Battery_Latch_Slide')
            rect(sk_base, bx0, bx1, neg(add(PH2, 'Alu_Thickness')), neg(PH2), 'Base_Plate_X_Length', 'Alu_Thickness')
            b_in = baseComp.features.extrudeFeatures.createInput(
                sk_base.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            b_in.setDistanceExtent(False, vi('Base_Plate_Z_Width'))
            base_body = baseComp.features.extrudeFeatures.add(b_in).bodies.item(0)
            bx0v = -(VALS['Plate_Width'] / 2.0 + VALS['Base_Rear_Extension'] + VALS['Battery_Latch_Slide'])
            bx1v = VALS['Plate_Width'] / 2.0 + VALS['Base_Front_Extension'] - VALS['Battery_Latch_Slide']
            bz = VALS['Base_Plate_Z_Width'] / 2.0
            fillet_edges(baseComp, find_edges(base_body, 'y', [(x, z) for x in (bx0v, bx1v) for z in (-bz, bz)]),
                         'Fillet_Large', 'base plate corners')
            base_body.name = 'Aluminum_6061_Base_Plate'

            # Hook slots: sketched on the XZ plane. Find how sketch axes map to model X / Z.
            sk_bcut = new_sketch(baseComp, baseComp.xZConstructionPlane, 'Base_Hook_Slots')
            m = sk_bcut.modelToSketchSpace(adsk.core.Point3D.create(1, 0, 1))
            fx = 1 if m.x > 0 else -1
            fy = 1 if m.y > 0 else -1

            def to_sketch(f, a, b):
                return (a, b) if f > 0 else (neg(b), neg(a))

            z_ctr = add(half('Cavity_Depth'), half('Polycarbonate_Thickness'))
            for hx in hook_xs:
                # Slots stay fixed in the base plate's own frame (nominal hook positions). The
                # battery is slid -X by Battery_Latch_Slide, which puts each hook neck
                # against the front (-X) end of its slot with the nose under solid plate.
                xa = sub(hx, sub('Hook_Slot_Length', 'Hook_Slot_Offset'))
                xb = add(hx, 'Hook_Slot_Offset')
                for zc in (z_ctr, neg(z_ctr)):
                    za, zb = sub(zc, half('Slot_Width')), add(zc, half('Slot_Width'))
                    sx0, sx1 = to_sketch(fx, xa, xb)
                    sy0, sy1 = to_sketch(fy, za, zb)
                    rect(sk_bcut, sx0, sx1, sy0, sy1, 'Hook_Slot_Length', 'Slot_Width')
            bc_in = baseComp.features.extrudeFeatures.createInput(
                all_profiles(sk_bcut), adsk.fusion.FeatureOperations.CutFeatureOperation)
            bc_in.setAllExtent(adsk.fusion.ExtentDirections.SymmetricExtentDirection)
            bc_in.participantBodies = [base_body]
            baseComp.features.extrudeFeatures.add(bc_in)

        # ==============================================================================
        # 5. HARDWARE: standoff sleeves
        # ==============================================================================
        step('6/6  Building standoffs...')
        hwComp = new_part('Hardware_Standoffs')
        sk_hw = new_sketch(hwComp, hwComp.xYConstructionPlane, 'Standoffs')
        for (px, py) in bolt_pts:
            outer = circle(sk_hw, px, py, 'Standoff_OD')
            inner = circle(sk_hw, px, py, 'Standoff_ID', locate=False)
            try:
                sk_hw.geometricConstraints.addCoincident(inner.centerSketchPoint, outer.centerSketchPoint)
            except:
                ISSUES.append('Standoffs: concentric constraint failed: %s' % last_error())
        s_profs = adsk.core.ObjectCollection.create()
        for p in sk_hw.profiles:
            if p.profileLoops.count == 2:
                s_profs.add(p)
        s_in = hwComp.features.extrudeFeatures.createInput(
            s_profs, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        s_in.setSymmetricExtent(vi('Cavity_Depth/2'), False)
        hwComp.features.extrudeFeatures.add(s_in)

        # Screws: one McMaster screw at every bolt point on both side plates, head on the plate's
        # outer face, threading into the standoff. Positions are fixed when the script runs (like
        # the tab and bolt counts): re-run after changing the pack size.
        say('6/6  Placing screws...')
        step_path = find_hardware_file(SCREW_PART)
        if step_path is None:
            ISSUES.insert(0, 'Screws skipped: put the McMaster %s STEP file in fusion/hardware/' % SCREW_PART)
        else:
            try:
                scComp = new_part('Hardware_Screws_%s' % SCREW_PART)
                z_face = VALS['Cavity_Depth'] / 2.0 + VALS['Polycarbonate_Thickness']
                targets = [(ev(px), ev(py), side * z_face, -side) for (px, py) in bolt_pts for side in (-1, 1)]
                screw_comp, shank, placed = place_screws(design, scComp, step_path, targets)
                if placed != len(targets):
                    ISSUES.insert(0, 'Screws: placed %d of %d' % (placed, len(targets)))
                engage = shank - VALS['Polycarbonate_Thickness']
                if engage < 1.5 * 5.0:
                    ISSUES.append('Warning: screws engage only %.1f mm of thread in the standoffs (want >= 7.5)' % engage)
                if engage > VALS['Cavity_Depth'] / 2.0:
                    ISSUES.append('Warning: screws are too long: the two screws in each standoff collide')
            except:
                ISSUES.insert(0, 'Screws failed: %s' % last_error())

        # ==============================================================================
        # 6. GROUND THE BASE PLATE (OR THE SIDE PLATES), THEN MATERIALS AND APPEARANCES
        # ==============================================================================
        say('Grounding and applying materials...')
        anchor = 'Alu_6061_Base_Plate' if BASE_PLATE else 'PC_Side_Plates'
        try:
            part_occs[anchor].isGroundToParent = True
            for nm, po in part_occs.items():
                if nm != anchor:
                    po.isGroundToParent = False
        except:
            ISSUES.append('Grounding %s failed: %s' % (anchor, last_error()))
        look_lines = apply_looks(app, design, {
            'PC': [b for c in (sideComp, wallComp) for b in c.bRepBodies],
            'BASE': list(baseComp.bRepBodies) if baseComp else [],
            'STANDOFF': list(hwComp.bRepBodies),
            'TRAY': [b for b in intComp.bRepBodies if b.name.startswith('ABS')],
            'NICKEL': ([b for b in intComp.bRepBodies if b.name.startswith('Nickel')]
                       + (list(stripComp.bRepBodies) if stripComp else [])),
            'HOLDER': [b for b in intComp.bRepBodies if b.name.startswith('Holder')],
            'FOAM': [b for b in intComp.bRepBodies if b.name.startswith('Neoprene')],
            'CELL': [b for b in intComp.bRepBodies
                     if not b.name.startswith(('ABS', 'Nickel', 'Holder', 'Neoprene'))],
        })

        # Remember where the generated timeline ends, so export_design.py can tell features
        # added by hand afterwards from the ones this script made.
        try:
            design.attributes.add('ebike_enclosure', 'generated_timeline_end', str(design.timeline.count))
        except:
            ISSUES.append('Could not record the timeline marker: %s' % last_error())

        app.activeViewport.fit()
        prog.hide()
        prog = None

        # ---- Report ----
        under = []
        for s in SKETCHES:
            if not s.isFullyConstrained:
                n_loose = sum(1 for i in range(s.sketchCurves.count)
                              if not s.sketchCurves.item(i).isFullyConstrained)
                under.append('%s (%d of %d curves loose; %d dims, %d constraints)' % (
                    s.name, n_loose, s.sketchCurves.count, s.sketchDimensions.count, s.geometricConstraints.count))
        for issue in ISSUES:
            app.log(issue)
        if timings:
            timings[-1] = (timings[-1][0], time.time() - t_start[0])
        msg = '%dS%dP enclosure generated%s.\n' % (cols, rows, '' if BASE_PLATE else ' (no base plate)')
        try:
            here = os.path.abspath(__file__)
        except NameError:
            here = '?'
        msg += 'Script: %s\n' % here
        msg += ('Package script for %s (parameters set to that pack).\n' % CONFIG_NAME if CONFIG_NAME
                else 'Repo script: parameters already in this design were kept.\n')
        msg += 'Time: %.0f s (%s)\n\n' % (sum(t for _, t in timings),
                                          ', '.join('%s %.0f s' % (n, t) for n, t in timings))
        msg += 'Fully defined sketches: %d of %d.\n' % (len(SKETCHES) - len(under), len(SKETCHES))
        if under:
            msg += 'Not fully defined:\n  ' + '\n  '.join(under[:8]) + ('\n  ...' if len(under) > 8 else '') + '\n'
        if ISSUES:
            msg += '\n%d dimension/constraint problems, first few:\n' % len(ISSUES)
            msg += '\n'.join(ISSUES[:5]) + '\n'
        if fallback_pattern:
            msg += '\nNote: the cell pattern could not be bound to Columns/Rows, so it uses fixed counts. '
            msg += 'Re-run the script after changing Columns or Rows.\n'
        if look_lines:
            msg += '\nMaterials:\n  ' + '\n  '.join(look_lines) + '\n'
        msg += '\nEdit values in Modify > Change Parameters.'
        ui.messageBox(msg)

    except Cancelled:
        if prog:
            prog.hide()
        if ui:
            ui.messageBox('Cancelled. The assembly is only partly built; re-run the script to rebuild it.')
    except:
        if prog:
            prog.hide()
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))
