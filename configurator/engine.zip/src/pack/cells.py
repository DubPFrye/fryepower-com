"""Cell catalog (data/cells.csv), per-format holder / strip / ring data (data/cell_formats.csv)
and the electrical specs of a pack built from it."""
from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path

from .config import ConfigError

DEFAULT_CELLS = Path(__file__).resolve().parents[2] / "data" / "cells.csv"
DEFAULT_FORMATS = Path(__file__).resolve().parents[2] / "data" / "cell_formats.csv"


@dataclass(frozen=True)
class Cell:
    key: str
    name: str
    format: str
    diameter_mm: float
    height_mm: float
    capacity_ah: float
    max_continuous_a: float
    grams: float
    nominal_v: float
    max_v: float


def load_cells(path: str | Path = DEFAULT_CELLS) -> dict[str, Cell]:
    """Read the cell catalog into {key: Cell}, failing with a clear message on a bad row."""
    cells: dict[str, Cell] = {}
    with open(path, newline="", encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            key = row["key"].strip()
            try:
                cells[key] = Cell(
                    key=key, name=row["name"].strip(), format=row["format"].strip(),
                    **{f: float(row[f]) for f in ("diameter_mm", "height_mm", "capacity_ah",
                                                    "max_continuous_a", "grams", "nominal_v", "max_v")})
            except (KeyError, ValueError) as exc:
                raise ConfigError(f"{path}: bad row for cell {key!r}: {exc}") from None
    if not cells:
        raise ConfigError(f"{path} has no cells")
    return cells


def apply_cell(cfg: dict, cell: Cell) -> None:
    """Put the cell's geometry into a config (in place)."""
    cfg["cell"] = {"key": cell.key, "name": cell.name, "format": cell.format,
                   "diameter_mm": cell.diameter_mm, "height_mm": cell.height_mm}


def pack_specs(cell: Cell, series: int, parallel: int) -> dict[str, float]:
    """Nominal electrical specs (cells only: no BMS, nickel, enclosure or wiring)."""
    v_nom = series * cell.nominal_v
    ah = parallel * cell.capacity_ah
    return {
        "nominal_v": round(v_nom, 1),
        "max_v": round(series * cell.max_v, 1),
        "capacity_ah": round(ah, 1),
        "energy_wh": round(v_nom * ah),
        "max_continuous_a": round(parallel * cell.max_continuous_a),
        "cells": series * parallel,
        "cell_weight_kg": round(series * parallel * cell.grams / 1000, 2),
    }


@dataclass(frozen=True)
class CellFormat:
    """The hardware that goes with a cell format (18650 / 21700): holder, 2P nickel strip and
    + end insulator ring. One holder spacing per format: not a customer choice."""
    format: str
    holder_pitch_mm: float
    holder_height_mm: float
    holder_recess_mm: float
    holder_bore_mm: float
    holder_tab_gap_mm: float
    strip_width_mm: float
    strip_leg_mm: float              # the side legs (rails) along the strip edges
    strip_bar_mm: float              # the cross bars between the square holes
    strip_thickness_mm: float
    strip_slot_length_mm: float      # oval weld slot on a leg over each cell
    strip_slot_width_mm: float
    insulator_id_mm: float
    insulator_thickness_mm: float
    source: str


def load_formats(path: str | Path = DEFAULT_FORMATS) -> dict[str, CellFormat]:
    """Read data/cell_formats.csv into {format: CellFormat}."""
    out: dict[str, CellFormat] = {}
    numbers = [f for f in CellFormat.__dataclass_fields__ if f not in ("format", "source")]
    with open(path, newline="", encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            fmt = row["format"].strip()
            try:
                out[fmt] = CellFormat(format=fmt, source=row.get("source", "").strip(),
                                      **{f: float(row[f]) for f in numbers})
            except (KeyError, ValueError) as exc:
                raise ConfigError(f"{path}: bad row for format {fmt!r}: {exc}") from None
    if not out:
        raise ConfigError(f"{path} has no cell formats")
    return out


def apply_format(cfg: dict, fmt: CellFormat) -> None:
    """Put a format's holder spacing, holder, nickel strip and insulator ring into a config (in place)."""
    cfg["pack"]["cell_pitch_mm"] = fmt.holder_pitch_mm
    cfg["holder"] = {"height_mm": fmt.holder_height_mm, "recess_mm": fmt.holder_recess_mm,
                     "bore_mm": fmt.holder_bore_mm, "tab_gap_mm": fmt.holder_tab_gap_mm}
    # update, not replace: the config's own strip setting (end inset) stays
    cfg.setdefault("nickel", {}).update({"width_mm": fmt.strip_width_mm, "leg_mm": fmt.strip_leg_mm,
                                         "bar_mm": fmt.strip_bar_mm, "thickness_mm": fmt.strip_thickness_mm,
                                         "weld_slot_length_mm": fmt.strip_slot_length_mm,
                                         "weld_slot_width_mm": fmt.strip_slot_width_mm})
    cfg["insulator"] = {"id_mm": fmt.insulator_id_mm, "thickness_mm": fmt.insulator_thickness_mm}
