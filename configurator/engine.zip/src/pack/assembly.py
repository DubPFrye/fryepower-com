"""The assembled pack in 3D: where every part sits, in plain Python (for the web 3D view).

``build_parts`` gives each cut part as a flat outline. This module puts those outlines, the cells,
cell holders, insulator rings, nickel strips, BMS tray, foam liner, standoffs and screw heads into
the model frame, the same way the Fusion script places them:

    X = pack length along the bike (front = +X), Y = height, Z = cell axis.
    Side plates lie in XY at -Z (front plate) and +Z (rear plate, the mirror of the front one).
    Long walls (top / bottom) lie in XZ, short walls (left / right) in YZ.
    With a base plate, everything but the base plate is slid -X by the battery latch slide, so the
    hooks sit latched in their base-plate slots (as in the Fusion model).

Solids are plain dicts, ready for JSON:

    extrusion  outline + holes in the part's flat (u, v) coordinates, extruded ``thickness`` along w.
               Round holes may come as ``circle_holes`` = {radius, centers} instead (the holder
               bores: hundreds of them), and oval slots along v as ``slot_holes`` = {length, width,
               centers} (the nickel strips' weld slots).
               frame = {origin, u, v, w}: flat point (a, b), height c -> origin + a*u + b*v + c*w.
    cylinders  one or more cylinders (optionally tubes) along an axis, given by their centers.
               The cells also carry ``lathe``: the detailed cell as surfaces of revolution about the
               cylinder axis, each {material, profile: [[r, z], ...]} with z from -length/2 (negative
               end) to +length/2 (positive button), and ``flip`` (one bool per center: True = the
               cell is turned end for end, positive toward -Z).
    boxes      axis-aligned boxes, each [[xmin, ymin, zmin], [xmax, ymax, zmax]].

Exploded view: every solid also has ``explode`` (one [dx, dy, dz] for the whole solid) and, for a
solid made of separate pieces (foam strips, screws, rings), ``explode_each`` (one per box or
center). That is the full offset in mm; the viewer moves each piece by ``t * offset``, t in 0..1.
``bbox_exploded`` is the bounding box at t = 1.
"""
from __future__ import annotations

import math
from typing import Any

from .contours import Circle, Polyline, Shape
from .geometry import Part, build_parts, derive_dimensions, derive_layout, strip_groups

Vec = tuple[float, float, float]
FLATTEN_TOL_MM = 0.1     # arcs are flattened to straight segments within this distance
CIRCLE_SEGMENTS = 24     # bolt holes


def _r(v: float) -> float:
    return round(v, 2)


def _pts(shape: Shape) -> list[list[float]]:
    if isinstance(shape, Circle):
        n = CIRCLE_SEGMENTS
        return [[_r(shape.cx + shape.r * math.cos(2 * math.pi * i / n)),
                 _r(shape.cy + shape.r * math.sin(2 * math.pi * i / n))] for i in range(n)]
    return [[_r(x), _r(y)] for x, y in shape.points(tol=FLATTEN_TOL_MM)]


def _extrusion(name: str, part: Part, material: str, origin: Vec, u: Vec, v: Vec, w: Vec) -> dict[str, Any]:
    """A flat part placed in the model. ``origin`` is where the part's flat (0, 0), bottom face, goes."""
    return {
        "type": "extrusion", "name": name, "part": part.key, "material": material,
        "outline": _pts(part.outline), "holes": [_pts(c) for c in part.cutouts],
        "thickness": part.thickness_mm,
        "frame": {"origin": [_r(c) for c in origin], "u": list(u), "v": list(v), "w": list(w)},
    }


def _flat(name: str, material: str, outline: list[tuple[float, float]], holes: list[list[list[float]]],
          thickness: float, origin: Vec, u: Vec, v: Vec, w: Vec) -> dict[str, Any]:
    """An extrusion from an outline given directly (not a cut part)."""
    return {
        "type": "extrusion", "name": name, "part": "", "material": material,
        "outline": [[_r(a), _r(b)] for a, b in outline], "holes": holes, "thickness": thickness,
        "frame": {"origin": [_r(c) for c in origin], "u": list(u), "v": list(v), "w": list(w)},
    }


def _strip_outline(width: float, length: float, pitch: float, leg: float, bar: float, rows: int, rails: str,
                   trim: float, tab: bool = True) -> tuple[list[tuple[float, float]], list[list[tuple[float, float]]]]:
    """A cut piece of 2P nickel strip in its own flat coordinates (x across, y along the column,
    0 = the bottom edge of the cell block, length = its top edge).

    The strip is a ladder: two legs (rails, ``leg`` wide) along the edges joined by a bar (``bar``
    wide, along the strip) over every cell, with a square hole between bars that drops over the
    holder's tab island. rails = "both" (a two-column
    strip), "left" or "right" (a single-column strip: the 2P strip cut lengthwise, ``width`` wide,
    its bar stubs pointing away from the rail). Both ends are trimmed ``trim`` short of the block
    edge, except the tab leg (the left one, or the only one), which runs on to the top edge and
    folds over as the balance tab (tab=False: no tab leg, both ends trimmed).
    """
    gap = (pitch - bar) / 2          # half a hole, along the strip
    bars = [(j * pitch + gap, j * pitch + gap + bar) for j in range(rows)]
    lo, hi = trim, length - trim
    if rails == "both":
        x0, x1 = leg, width - leg
        outline = [(0, lo), (x0, lo), (x0, gap), (x1, gap), (x1, lo), (width, lo), (width, hi),
                   (x1, hi), (x1, length - gap), (x0, length - gap), (x0, length), (0, length)]
        holes = [[(x0, j * pitch - gap), (x1, j * pitch - gap), (x1, j * pitch + gap), (x0, j * pitch + gap)]
                 for j in range(1, rows)]
        return outline, holes
    pts = [(0.0, lo), (leg, lo)]                    # rail on the left, bar stubs to the right
    for b0, b1 in bars:
        pts += [(leg, b0), (width, b0), (width, b1), (leg, b1)]
    top = length if tab else hi
    pts += [(leg, top), (0.0, top)]
    if rails == "right":                            # mirror; reverse to stay counter-clockwise
        pts = [(width - x, y) for x, y in reversed(pts)]
    return pts, []


def _folded_terminal(d: Any, nickel: dict[str, Any], first: bool, end: int, x_left: float, width: float,
                     y_cells: float, height: float, trim: float) -> dict[str, Any]:
    """The second pitch of a pack-terminal strip, folded 90 degrees around the end of the cell block
    (over the holder's end face), so the main lead attaches at the end of the pack. In its flat
    coordinates u runs from the fold inward along the cells, v up; the bar stubs are at the fold and
    the far leg at u = width / 2. Both of its ends are trimmed (the balance tab is on the other leg)."""
    t, w2 = d.strip_thickness, d.strip_width / 2
    outline, _ = _strip_outline(w2, height, d.cell_pitch, nickel["leg_mm"], nickel["bar_mm"], d.rows,
                                "right", trim, tab=False)
    x_fold = x_left if first else x_left + width
    z_fold = end * (d.cell_height / 2 + t)                    # outer face of the strip
    u = (0.0, 0.0, -float(end))                              # inward, along the cells
    w = (-1.0, 0.0, 0.0) if first else (1.0, 0.0, 0.0)       # thickness: out past the block end
    sol = _flat(f"{'Rear' if end > 0 else 'Front'} nickel strip", "nickel", outline, [], t,
                (x_fold, y_cells, z_fold), u, (0.0, 1.0, 0.0), w)
    sol["terminal"] = "pack -" if first else "pack +"
    sol["explode_gaps"] = (0, 0, end * EXPLODE_STRIP_GAPS)
    return sol


def _cell_stack(d: Any, cfg: dict[str, Any], s: float, y_cells: float) -> list[dict[str, Any]]:
    """Holders, holder tab islands, insulator rings, nickel strips and balance tabs at both cell ends.

    Each cell end sits holder_recess below its holder's outer face. The + end gets an insulator
    ring around the button; the nickel strip lies on the cell ends inside the recess, its square
    holes over the raised tab islands (where four cells meet). One leg of each strip carries on past
    the top of the cell block and folds over the holder's top edge: the BMS balance tab.
    """
    X, Y, Z = (1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)
    p, cols, rows = d.cell_pitch, d.columns, d.rows
    ccw2, h2 = d.cell_core_width / 2, d.cell_height / 2
    face = h2 + d.holder_recess                     # holder outer face, |z|
    width, height = cols * p, rows * p
    x_left = -ccw2 - s
    y_top = y_cells + height
    out: list[dict[str, Any]] = []

    # Holders: one slab per end, a bore per cell (interlocks and mounting ears left out). The outer
    # face has channels in both directions, holder_recess deep, so the top of every web between
    # bores is cut down to the cell ends and the strip lies flat on them: the slab stops at the
    # cell-end level and only the tab islands stand up to the face.
    bores = {"radius": _r(d.holder_bore / 2),
             "centers": [[_r((i + 0.5) * p), _r((j + 0.5) * p)] for i in range(cols) for j in range(rows)]}
    block = [(0, 0), (width, 0), (width, height), (0, height)]
    for end, label in ((-1, "Front"), (1, "Rear")):
        slab = d.holder_height - d.holder_recess
        z0 = -h2 if end < 0 else face - d.holder_height
        sol = _flat(f"{label} cell holder", "holder", block, [], slab, (x_left, y_cells, z0), X, Y, Z)
        sol["circle_holes"] = bores
        sol["explode_gaps"] = (0, 0, end * EXPLODE_HOLDER_GAPS)
        out.append(sol)
        # Tab islands: the four tabs where four cells meet stand up from the cell ends to the
        # face, as a square (pitch - tab gap) across; clipped at the edges of the block
        a = (p - cfg["holder"]["tab_gap_mm"]) / 2
        zs = sorted((end * h2, end * face))
        boxes = []
        for i in range(cols + 1):
            for j in range(rows + 1):
                bx0, bx1 = max(i * p - a, 0.0), min(i * p + a, width)
                by0, by1 = max(j * p - a, 0.0), min(j * p + a, height)
                boxes.append([[_r(x_left + bx0), _r(y_cells + by0), _r(zs[0])],
                              [_r(x_left + bx1), _r(y_cells + by1), _r(zs[1])]])
        out.append({"type": "boxes", "name": f"{label} holder tabs", "material": "holder", "boxes": boxes,
                    "explode_gaps": (0, 0, end * EXPLODE_HOLDER_GAPS)})

    # Insulator rings on every + end (column 0 has its + end at +Z; columns alternate), drawn
    # with the bore's diameter (the paper squeezes around the cell), sitting on the shoulder
    t_ring = cfg["insulator"]["thickness_mm"]
    z_ring = h2 - CELL_BUTTON_HEIGHT_MM + t_ring / 2
    ring_centers = [[_r(x_left + (i + 0.5) * p), _r(y_cells + (j + 0.5) * p), _r((1 if i % 2 == 0 else -1) * z_ring)]
                    for i in range(cols) for j in range(rows)]
    out.append({"type": "cylinders", "name": "Insulator rings", "material": "insulator", "axis": "z",
                "radius": d.holder_bore / 2, "inner_radius": cfg["insulator"]["id_mm"] / 2, "length": t_ring,
                "centers": ring_centers})

    # Nickel strips on the cell ends, and one balance tab per strip folded over the holder's top edge
    nickel = cfg["nickel"]
    leg, t = nickel["leg_mm"], d.strip_thickness
    w2 = d.strip_width / 2
    # Strip ends stop end_inset inside the edge of the cells
    reach = d.cell_diameter / 2 - nickel["end_inset_mm"]       # from a cell center
    trim = p / 2 - reach                                       # short of the block edge, each end
    slot = {"length": nickel["weld_slot_length_mm"], "width": nickel["weld_slot_width_mm"]}
    for end in (1, -1):
        label = "Rear" if end > 0 else "Front"
        z0 = h2 if end > 0 else -h2 - t
        tabs = []
        for _, c0, c1 in (g for g in strip_groups(cols) if g[0] == end):
            if c1 - c0 == 2:            # over two columns, centered on the line between them
                xa, wid, rails = (c0 + 1) * p - w2, d.strip_width, "both"
            elif c0 == 0:               # pack terminal, first column: a full 2P strip centered on the
                xa, wid, rails = 0.0, w2, "right"     # block edge; this half lies on the column,
            else:                                     # the other folds around the end (below)
                xa, wid, rails = width - w2, w2, "left"
            outline, holes = _strip_outline(wid, height, p, leg, nickel["bar_mm"], rows, rails, trim)
            sol = _flat(f"{label} nickel strip", "nickel", outline, [[[_r(x), _r(y)] for x, y in h] for h in holes],
                        t, (x_left + xa, y_cells, z0), X, Y, Z)
            # A weld slot on each leg over every cell, on the cell center (within the leg)
            legs = ([wid / 2 - p / 2, wid / 2 + p / 2] if rails == "both"
                    else [p / 2 if c0 == 0 else wid - p / 2])     # terminal: on its column's centers
            sol["slot_holes"] = dict(slot, centers=[[_r(x), _r((j + 0.5) * p)] for x in legs for j in range(rows)])
            sol["explode_gaps"] = (0, 0, end * EXPLODE_STRIP_GAPS)
            out.append(sol)
            if c1 - c0 == 1:
                out.append(_folded_terminal(d, nickel, c0 == 0, end, x_left, width, y_cells, height, trim))
            tx = xa if rails != "right" else xa + wid - leg       # the leg that becomes the tab
            zt = sorted((end * (face - d.holder_height), end * (h2 + t)))
            tabs.append([[_r(x_left + tx), _r(y_top), _r(zt[0])], [_r(x_left + tx + leg), _r(y_top + t), _r(zt[1])]])
        out.append({"type": "boxes", "name": f"{label} balance tabs", "material": "nickel", "boxes": tabs,
                    "explode_gaps": (0, 0, end * EXPLODE_STRIP_GAPS)})
    return out


def to_model(solid: dict[str, Any], a: float, b: float, c: float = 0.0) -> Vec:
    """Model coordinates of a point given in an extrusion's flat (a, b) and height (c) coordinates."""
    f = solid["frame"]
    return tuple(f["origin"][i] + a * f["u"][i] + b * f["v"][i] + c * f["w"][i] for i in range(3))  # type: ignore[return-value]


def build_assembly(cfg: dict[str, Any]) -> dict[str, Any]:
    """Every solid of the assembled pack, plus its overall bounding box. Units are mm."""
    d = derive_dimensions(cfg)
    lay = derive_layout(d)
    parts = {p.key: p for p in build_parts(cfg)}
    pct, cd = d.polycarbonate_thickness, d.cavity_depth
    cw2, ch2, ph2 = d.cavity_width / 2, d.cavity_height / 2, d.plate_height / 2
    s = d.battery_latch_slide if d.base_plate else 0.0     # battery parts slide -X to latch
    X, Y, Z = (1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)
    solids: list[dict[str, Any]] = []

    # Side plates: flat (u, v) is model (X, Y); front at -Z, rear at +Z
    sp = parts["side_plate"]
    ox, oy = sp.origin
    solids.append(_extrusion("Front side plate", sp, "polycarbonate", (ox - s, oy, -(cd / 2 + pct)), X, Y, Z))
    solids.append(_extrusion("Rear side plate", sp, "polycarbonate", (ox - s, oy, cd / 2), X, Y, Z))

    # Long walls (top / bottom): flat (u, v) is model (X, Z), thickness along Y
    lw = parts["long_wall"]
    ox, oz = lw.origin
    solids.append(_extrusion("Top wall", lw, "polycarbonate", (ox - s, ch2, oz), X, Z, Y))
    solids.append(_extrusion("Bottom wall", lw, "polycarbonate", (ox - s, -ch2 - pct, oz), X, Z, Y))

    # Short walls (left = rear end, right = front end): flat (u, v) is model (Y, Z), thickness along X
    sw = parts["short_wall"]
    oy, oz = sw.origin
    solids.append(_extrusion("Rear end wall", sw, "polycarbonate", (-cw2 - pct - s, oy, oz), Y, Z, X))
    solids.append(_extrusion("Front end wall", sw, "polycarbonate", (cw2 - s, oy, oz), Y, Z, X))

    # Base plate: flat (u, v) is model (X, Z), under the side plates; it does not slide
    if "base_plate" in parts:
        bp = parts["base_plate"]
        ox, oz = bp.origin
        solids.append(_extrusion("Base plate", bp, "aluminum", (ox, -ph2 - d.alu_thickness, oz), X, Z, Y))

    # Internal core (same layout as the Fusion script): cells on the bottom foam, BMS tray on top
    # of them, under the top foam (opposite the base plate)
    ccw2 = d.cell_core_width / 2
    y_cells = -ch2 + d.foam_gap                 # bottom of the cell block
    y_tray_bot = y_cells + d.cell_core_height
    y_tray_top = y_tray_bot + d.bms_height
    solids.append({"type": "boxes", "name": "BMS tray", "material": "abs",
                   "boxes": [[[_r(-ccw2 - s), _r(y_tray_bot), _r(-d.core_depth / 2)],
                              [_r(ccw2 - s), _r(y_tray_top), _r(d.core_depth / 2)]]]})
    cells = [[_r(-ccw2 + d.cell_pitch * (i + 0.5) - s), _r(y_cells + d.cell_pitch * (j + 0.5)), 0.0]
             for i in range(d.columns) for j in range(d.rows)]
    # Each column is one parallel group; neighbouring groups face opposite ways (series connection)
    solids.append({"type": "cylinders", "name": "Cells", "material": "cell", "axis": "z",
                   "radius": d.cell_diameter / 2, "inner_radius": 0.0, "length": d.cell_height,
                   "centers": cells, "lathe": cell_lathe(d.cell_diameter, d.cell_height),
                   "flip": [i % 2 == 1 for i in range(d.columns) for _ in range(d.rows)]})
    solids += _cell_stack(d, cfg, s, y_cells)
    if d.foam_thickness > 0:
        # Drawn at its full uncompressed thickness, from the walls inward: it overlaps the cell
        # block and holders by foam_compression (the squeeze), which a viewer reads as foam
        f, z2, cz2 = d.foam_thickness, d.core_depth / 2, cd / 2
        ring = [((-cw2, -ch2), (cw2, -ch2 + f)), ((-cw2, ch2 - f), (cw2, ch2)),
                ((-cw2, -ch2 + f), (-cw2 + f, ch2 - f)), ((cw2 - f, -ch2 + f), (cw2, ch2 - f))]
        boxes = [[[_r(x0 - s), _r(y0), _r(-z2)], [_r(x1 - s), _r(y1), _r(z2)]] for (x0, y0), (x1, y1) in ring]
        # Pads on the inside faces of the side plates, over the holder faces (front = -Z, then rear)
        boxes += [[[_r(-cw2 - s), _r(-ch2), _r(z0)], [_r(cw2 - s), _r(ch2), _r(z0 + f)]] for z0 in (-cz2, cz2 - f)]
        solids.append({"type": "boxes", "name": "Foam liner", "material": "foam", "boxes": boxes})

    # Standoffs between the side plates at every bolt point, and a screw head on each outer face
    bolts = [[_r(bx - s), _r(by), 0.0] for bx, by in lay.bolt_points]
    solids.append({"type": "cylinders", "name": "Standoffs", "material": "aluminum", "axis": "z",
                   "radius": d.standoff_od / 2, "inner_radius": d.standoff_id / 2, "length": cd,
                   "centers": bolts})
    screw = cfg["enclosure"].get("screw")
    if isinstance(screw, dict) and screw.get("head_diameter_mm") and screw.get("head_height_mm"):
        hh = float(screw["head_height_mm"])
        shank = float(screw.get("length_mm", 0))         # under the head (M5 x 16: 16)
        face = cd / 2 + pct                              # outer face of the side plate
        zc = face + (hh - shank) / 2                     # middle of head top .. shank tip
        sol = {"type": "cylinders", "name": "Screws", "material": "steel", "axis": "z",
               "radius": float(screw["head_diameter_mm"]) / 2, "inner_radius": 0.0, "length": hh + shank,
               "centers": [[x, y, _r(side * zc)] for x, y, _ in bolts for side in (-1, 1)],
               # head out, shank in: the front (-Z) screws are turned end for end
               "flip": [side < 0 for _ in bolts for side in (-1, 1)]}
        if shank and screw.get("thread_diameter_mm"):
            sol["lathe"] = screw_lathe(float(screw["head_diameter_mm"]), hh, float(screw["thread_diameter_mm"]), shank)
        solids.append(sol)

    _add_explode(solids, d)
    return {"solids": solids, "bbox": [list(v) for v in _bbox(solids)],
            "bbox_exploded": [list(v) for v in _bbox([_exploded(sol) for sol in solids])],
            "slide_mm": _r(s)}


# Cylindrical cell detail (display only), as fractions of the cell radius or in mm
CELL_BUTTON_RADIUS = 0.42       # positive button
CELL_FOLD_RADIUS = 0.80         # the shrink wrap rolls over each end down to this radius
CELL_BUTTON_HEIGHT_MM = 0.5     # button above the wrapped shoulder
CELL_EDGE_MM = 0.7              # rounded can edge
CELL_GROOVE_FROM_TOP_MM = 4.0   # crimp groove below the positive end
CELL_GROOVE_DEPTH_MM = 0.4
CELL_GROOVE_HALF_WIDTH_MM = 1.0
CELL_SKIN_MM = 0.1              # end faces sit this far under the wrap fold


def screw_lathe(head_diameter: float, head_height: float, thread_diameter: float,
                length: float) -> list[dict[str, Any]]:
    """A flanged button head screw as a surface of revolution, head toward +z: z from -(head +
    length)/2 (shank tip) to +(head + length)/2 (top of the head). Threads and the hex socket are
    left out."""
    h = (head_height + length) / 2
    under = h - head_height                       # underside of the head (the side plate face)
    R, rs = head_diameter / 2, thread_diameter / 2
    flange = min(0.8, head_height / 3)
    pts = [(0, -h), (rs - 0.4, -h), (rs, -h + 0.4), (rs, under), (R, under), (R, under + flange),
           (0.62 * R, h), (0, h)]
    return [{"material": "steel", "profile": [[_r(r), _r(z)] for r, z in pts]}]


def cell_lathe(diameter: float, length: float) -> list[dict[str, Any]]:
    """A cylindrical cell as surfaces of revolution: [[r, z], ...] profiles, z along the cell axis.

    Negative end (bare can bottom) at z = -length/2, positive button top at z = +length/2.
    """
    R, h = diameter / 2, length / 2
    e, k = CELL_EDGE_MM, CELL_SKIN_MM
    top = h - CELL_BUTTON_HEIGHT_MM                 # wrapped shoulder at the positive end
    zg, gw = top - CELL_GROOVE_FROM_TOP_MM, CELL_GROOVE_HALF_WIDTH_MM
    rb, rf = CELL_BUTTON_RADIUS * R, CELL_FOLD_RADIUS * R
    pts = lambda *p: [[_r(r), _r(z)] for r, z in p]  # noqa: E731
    return [
        {"material": "cell", "profile": pts(       # shrink wrap, rolled over both ends
            (rf, -h), (R - e, -h), (R - 0.3 * e, -h + 0.3 * e), (R, -h + e),
            (R, zg - gw), (R - CELL_GROOVE_DEPTH_MM, zg), (R, zg + gw),
            (R, top - e), (R - 0.3 * e, top - 0.3 * e), (R - e, top), (rf, top))},
        {"material": "cell_can", "profile": pts((0, -h + k), (rf + 0.5, -h + k))},          # can bottom
        {"material": "cell_insulator", "profile": pts((rb, top - k), (rf + 0.5, top - k))},  # top washer
        {"material": "cell_can", "profile": pts(   # positive button
            (0, h), (rb - 0.4, h), (rb, h - 0.4), (rb, top - k))},
    ]


# Exploded view: how far each part moves out, in gaps (see _add_explode)
EXPLODE_GAP_MIN_MM = 40.0
EXPLODE_GAP_FRACTION = 0.6     # one gap = this fraction of the larger of cavity height / depth
EXPLODE_STEPS = {               # whole solids: direction x number of gaps
    "Front side plate": (0, 0, -2.0), "Rear side plate": (0, 0, 2.0),
    "Top wall": (0, 1.5, 0), "Bottom wall": (0, -1.5, 0),
    "Rear end wall": (-1.5, 0, 0), "Front end wall": (1.5, 0, 0),
    "Base plate": (0, -2.6, 0), "BMS tray": (0, 0.35, 0),
}
EXPLODE_FOAM_GAPS = 0.75        # foam strips move out from the core, each its own way
EXPLODE_FOAM_PAD_GAPS = 1.3     # side-plate foam pads: between the strips and the side plates
EXPLODE_RING_GAPS = 0.2         # insulator rings lift off the + ends
EXPLODE_HOLDER_GAPS = 0.45      # holders slide off the cell ends
EXPLODE_STRIP_GAPS = 0.8        # nickel strips (and their balance tabs) beyond the holders
EXPLODE_SCREW_GAPS = 2.8        # screws back out past the side plates
EXPLODE_STANDOFF_GAPS = 2.0     # standoffs move straight out past their wall (walls go 1.5)


def _add_explode(solids: list[dict[str, Any]], d: Any) -> None:
    """Give every solid its exploded-view offset. The cells stay put."""
    g = max(EXPLODE_GAP_MIN_MM, EXPLODE_GAP_FRACTION * max(d.cavity_height, d.cavity_depth))
    vec = lambda gx, gy, gz: [_r(gx * g), _r(gy * g), _r(gz * g)]  # noqa: E731
    for sol in solids:
        name = sol["name"]
        sol["explode"] = vec(*(sol.pop("explode_gaps", None) or EXPLODE_STEPS.get(name, (0, 0, 0))))
        if name == "Insulator rings":
            sol["explode_each"] = [vec(0, 0, EXPLODE_RING_GAPS * (1 if z > 0 else -1)) for _, _, z in sol["centers"]]
        elif name == "Foam liner":     # bottom, top, rear end, front end strips, then the two side pads
            p = EXPLODE_FOAM_PAD_GAPS / EXPLODE_FOAM_GAPS
            sol["explode_each"] = [vec(*(EXPLODE_FOAM_GAPS * k for k in way))
                                   for way in ((0, -1, 0), (0, 1, 0), (-1, 0, 0), (1, 0, 0), (0, 0, -p), (0, 0, p))]
        elif name == "Screws":
            sol["explode_each"] = [vec(0, 0, EXPLODE_SCREW_GAPS * (1 if z > 0 else -1))
                                   for _, _, z in sol["centers"]]
        elif name == "Standoffs":    # above / below the long walls: up / down; beside the short walls: out
            k = EXPLODE_STANDOFF_GAPS
            sol["explode_each"] = [vec(0, k if y > 0 else -k, 0) if abs(y) > d.cavity_height / 2
                                   else vec(k if x > 0 else -k, 0, 0) for x, y, _ in sol["centers"]]


def _offsets(sol: dict[str, Any]) -> list[list[float]]:
    """The exploded-view offset of each piece of a solid (one for an extrusion)."""
    n = 1 if sol["type"] == "extrusion" else len(sol["boxes"] if sol["type"] == "boxes" else sol["centers"])
    return sol.get("explode_each") or [sol.get("explode", [0.0, 0.0, 0.0])] * n


def _exploded(sol: dict[str, Any]) -> dict[str, Any]:
    """A copy of a solid moved to its fully exploded position."""
    out = dict(sol)
    offs = _offsets(sol)
    add = lambda p, o: [p[i] + o[i] for i in range(3)]  # noqa: E731
    if sol["type"] == "extrusion":
        out["frame"] = dict(sol["frame"], origin=add(sol["frame"]["origin"], offs[0]))
    elif sol["type"] == "boxes":
        out["boxes"] = [[add(b0, o), add(b1, o)] for (b0, b1), o in zip(sol["boxes"], offs)]
    else:
        out["centers"] = [add(c, o) for c, o in zip(sol["centers"], offs)]
    return out


def _bbox(solids: list[dict[str, Any]]) -> tuple[Vec, Vec]:
    lo, hi = [math.inf] * 3, [-math.inf] * 3

    def grow(p: Vec | list[float]) -> None:
        for i in range(3):
            lo[i], hi[i] = min(lo[i], p[i]), max(hi[i], p[i])

    for sol in solids:
        if sol["type"] == "extrusion":
            for a, b in sol["outline"]:
                grow(to_model(sol, a, b))
                grow(to_model(sol, a, b, sol["thickness"]))
        elif sol["type"] == "boxes":
            for b0, b1 in sol["boxes"]:
                grow(b0)
                grow(b1)
        else:   # cylinders along Z
            r, h = sol["radius"], sol["length"] / 2
            for x, y, z in sol["centers"]:
                grow((x - r, y - r, z - h))
                grow((x + r, y + r, z + h))
    return (tuple(_r(v) for v in lo), tuple(_r(v) for v in hi))  # type: ignore[return-value]
