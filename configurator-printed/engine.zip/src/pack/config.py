"""Load and validate pack configuration files (config/*.json).

The config is the single source of truth for every dimension. Validation here catches
nonsense input (missing keys, non-positive sizes, series/parallel not matching the
layout, features that cannot be drawn). Manufacturing advice (minimum web widths and
so on) is reported separately by ``pack.geometry.check_design`` as warnings.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class ConfigError(ValueError):
    """The config is invalid. The message lists every problem found."""


# Fusion 360 user-parameter name -> path into the config. The Fusion script, the geometry
# module and the parity test all use this one table.
FUSION_PARAM_MAP: dict[str, tuple[str, ...]] = {
    "Columns": ("pack", "columns"),
    "Rows": ("pack", "rows"),
    "Cell_Diameter": ("cell", "diameter_mm"),
    "Cell_Height": ("cell", "height_mm"),
    "Cell_Pitch": ("pack", "cell_pitch_mm"),
    "Holder_Height": ("holder", "height_mm"),
    "Holder_Recess": ("holder", "recess_mm"),
    "Holder_Bore": ("holder", "bore_mm"),
    "Strip_Width": ("nickel", "width_mm"),
    "Holder_Tab_Gap": ("holder", "tab_gap_mm"),
    "Insulator_ID": ("insulator", "id_mm"),
    "Insulator_Thickness": ("insulator", "thickness_mm"),
    "Strip_Thickness": ("nickel", "thickness_mm"),
    "Strip_Leg": ("nickel", "leg_mm"),
    "Strip_Bar": ("nickel", "bar_mm"),
    "Strip_End_Inset": ("nickel", "end_inset_mm"),
    "Weld_Slot_Length": ("nickel", "weld_slot_length_mm"),
    "Weld_Slot_Width": ("nickel", "weld_slot_width_mm"),
    "Strip_Bend_Radius": ("nickel", "bend_radius_mm"),
    "Strip_K_Factor": ("nickel", "k_factor"),
    "Foam_Thickness": ("pack", "foam_thickness_mm"),
    "Foam_Compression": ("pack", "foam_compression_mm"),
    "Extra_Height": ("pack", "extra_height_mm"),
    "Extra_Length": ("pack", "extra_length_mm"),
    "Polycarbonate_Thickness": ("enclosure", "polycarbonate_thickness_mm"),
    "Side_Plate_Overhang": ("enclosure", "side_plate_overhang_mm"),
    "Plate_Corner_Radius": ("enclosure", "plate_corner_radius_mm"),
    "Alu_Thickness": ("enclosure", "alu_thickness_mm"),
    "Base_Front_Extension": ("enclosure", "base_front_extension_mm"),
    "Base_Rear_Extension": ("enclosure", "base_rear_extension_mm"),
    "Side_Extension": ("enclosure", "side_extension_mm"),
    "Min_CNC_Router_Diameter": ("enclosure", "min_router_diameter_mm"),
    "Slot_Clearance": ("enclosure", "slot_clearance_mm"),
    "Cut_Overshoot": ("fusion", "cut_overshoot_mm"),
    "Bolt_Hole_Diameter": ("enclosure", "bolt_hole_diameter_mm"),
    "Wall_Web": ("enclosure", "printed_walls", "wall_web_mm"),
    "Corner_Inner_Fillet": ("enclosure", "printed_walls", "corner_inner_fillet_mm"),
    "Corner_Outer_Fillet": ("enclosure", "printed_walls", "corner_outer_fillet_mm"),
    "Max_Section": ("enclosure", "printed_walls", "max_section_mm"),
    "Min_Section": ("enclosure", "printed_walls", "min_section_mm"),
    "Screw_End_Margin": ("enclosure", "printed_walls", "screw_end_margin_mm"),
    "Corner_Screw_Setback": ("enclosure", "printed_walls", "corner_screw_setback_mm"),
    "Max_Screw_Spacing": ("enclosure", "printed_walls", "max_screw_spacing_mm"),
    "Joint_End_Trim": ("enclosure", "printed_walls", "joint_end_trim_mm"),
    "Screw_Length": ("enclosure", "fasteners", "screw", "length_mm"),
    "Thread_Diameter": ("enclosure", "fasteners", "screw", "thread_diameter_mm"),
    "Coupling_Nut_AF": ("enclosure", "fasteners", "coupling_nut", "across_flats_mm"),
    "Coupling_Nut_Length": ("enclosure", "fasteners", "coupling_nut", "length_mm"),
    "Pocket_Clearance": ("enclosure", "fasteners", "pocket_clearance_mm"),
    "Far_Nut_Recess": ("enclosure", "fasteners", "far_nut_recess_mm"),
    "Allthread_Near_Gap": ("enclosure", "fasteners", "allthread_near_gap_mm"),
    "Allthread_Far_Gap": ("enclosure", "fasteners", "allthread_far_gap_mm"),
    "Hook_Max_Spacing": ("enclosure", "hook_max_spacing_mm"),
    "Hook_Neck_Width": ("enclosure", "hook", "neck_width_mm"),
    "Hook_Nose": ("enclosure", "hook", "nose_mm"),
    "Hook_Drop_Extra": ("enclosure", "hook", "drop_extra_mm"),
    "Hook_Overlap": ("enclosure", "hook", "overlap_mm"),
    "Hook_Slot_Length": ("enclosure", "hook", "slot_length_mm"),
    "Hook_Slot_Offset": ("enclosure", "hook", "slot_offset_mm"),
    "Hook_Slot_Clearance": ("enclosure", "hook", "slot_clearance_mm"),
    "Fillet_Large": ("enclosure", "fillet_large_mm"),
    "Fillet_Small": ("enclosure", "fillet_small_mm"),
}

# Values that may legitimately be zero (everything else numeric must be > 0).
_MAY_BE_ZERO = {
    "Base_Front_Extension", "Base_Rear_Extension", "Side_Extension", "Slot_Clearance",
    "Hook_Overlap", "Hook_Slot_Offset", "Hook_Slot_Clearance",
    "Fillet_Large", "Fillet_Small", "Cut_Overshoot", "Foam_Thickness",
    "Foam_Compression", "Side_Plate_Overhang", "Plate_Corner_Radius", "Extra_Height", "Extra_Length",
    "Joint_End_Trim", "Corner_Inner_Fillet", "Corner_Outer_Fillet", "Pocket_Clearance", "Far_Nut_Recess", "Allthread_Near_Gap", "Allthread_Far_Gap",
}


def get_path(cfg: dict[str, Any], path: tuple[str, ...]) -> Any:
    """Read cfg[path[0]][path[1]]...; raises KeyError naming the dotted path if missing."""
    node: Any = cfg
    for i, key in enumerate(path):
        if not isinstance(node, dict) or key not in node:
            raise KeyError(".".join(path[: i + 1]))
        node = node[key]
    return node


# Numbers the engine needs that the Fusion script does not use (must be > 0)
EXTRA_NUMBERS: tuple[tuple[str, ...], ...] = (
    ("enclosure", "printed_walls", "density_g_cm3"),
    ("enclosure", "fasteners", "screw", "head_diameter_mm"),
    ("enclosure", "fasteners", "screw", "head_height_mm"),
    ("enclosure", "fasteners", "min_thread_engagement_mm"),
)

# Wall material each side of the coupling nut pocket (enclosure.printed_walls.wall_web_mm)
WALL_WEB_RANGE_MM = (2.0, 8.0)

# A holder bore may be this much smaller than the cell: a slight press fit (Frye's 18650 holders
# measure 18.2 mm for 18.4 mm cells)
BORE_PRESS_FIT_MM = 0.3

SMALL_HOOK_KEYS = ("max_series", "neck_width_mm", "nose_mm", "drop_extra_mm", "slot_length_mm", "slot_offset_mm")


def hook_profile(cfg: dict[str, Any]) -> dict[str, Any]:
    """The hook this pack uses: enclosure.hook, with enclosure.small_hook's values laid over it
    for packs of up to small_hook.max_series cells in series (short side plates)."""
    enc = cfg["enclosure"]
    hook = dict(enc["hook"])
    small = enc.get("small_hook")
    if isinstance(small, dict) and cfg["pack"]["series"] <= small.get("max_series", 0):
        hook.update({k: v for k, v in small.items() if k != "max_series"})
    return hook


def has_base_plate(cfg: dict[str, Any]) -> bool:
    """enclosure.base_plate: with a base plate the side plates get L-hooks that latch into it.
    Without one there are no hooks and no base plate part. Missing means True."""
    return bool(cfg.get("enclosure", {}).get("base_plate", True))


def validate_config(cfg: dict[str, Any]) -> None:
    """Raise ConfigError listing every problem; return None if the config is usable."""
    errors: list[str] = []

    for name, path in FUSION_PARAM_MAP.items():
        dotted = ".".join(path)
        try:
            value = get_path(cfg, path)
        except KeyError:
            errors.append(f"missing {dotted}")
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            errors.append(f"{dotted} must be a number, got {value!r}")
        elif value < 0 or (value == 0 and name not in _MAY_BE_ZERO):
            errors.append(f"{dotted} must be {'>= 0' if name in _MAY_BE_ZERO else '> 0'}, got {value}")

    for path in EXTRA_NUMBERS:
        try:
            value = get_path(cfg, path)
        except KeyError:
            errors.append(f"missing {'.'.join(path)}")
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)) or value <= 0:
            errors.append(f"{'.'.join(path)} must be a number > 0, got {value!r}")

    for path in (("pack", "series"), ("pack", "parallel"),
                 ("enclosure", "plate_material"), ("enclosure", "base_material"),
                 ("enclosure", "printed_walls", "material")):
        try:
            get_path(cfg, path)
        except KeyError:
            errors.append(f"missing {'.'.join(path)}")

    small = cfg.get("enclosure", {}).get("small_hook")
    if small is not None:
        if not isinstance(small, dict):
            errors.append("enclosure.small_hook must be an object")
        else:
            for key in SMALL_HOOK_KEYS:
                value = small.get(key)
                if key not in small:
                    errors.append(f"missing enclosure.small_hook.{key}")
                elif isinstance(value, bool) or not isinstance(value, (int, float)) or value <= 0:
                    errors.append(f"enclosure.small_hook.{key} must be a number > 0, got {value!r}")

    if not isinstance(cfg.get("enclosure", {}).get("base_plate", True), bool):
        errors.append("enclosure.base_plate must be true or false")

    if errors:  # the cross-checks below need the numbers to exist
        raise ConfigError("invalid config:\n  - " + "\n  - ".join(errors))

    g = lambda *p: get_path(cfg, p)  # noqa: E731
    if g("pack", "series") != g("pack", "columns"):
        errors.append(f"pack.series ({g('pack', 'series')}) must equal pack.columns "
                      f"({g('pack', 'columns')}): each column is one series group")
    if g("pack", "parallel") != g("pack", "rows"):
        errors.append(f"pack.parallel ({g('pack', 'parallel')}) must equal pack.rows "
                      f"({g('pack', 'rows')}): each row is one parallel cell")
    for key in ("series", "parallel", "columns", "rows"):
        if g("pack", key) != int(g("pack", key)):
            errors.append(f"pack.{key} must be a whole number")
    if g("pack", "cell_pitch_mm") < g("cell", "diameter_mm"):
        errors.append(f"pack.cell_pitch_mm ({g('pack', 'cell_pitch_mm')}) is smaller than the cell "
                      f"diameter ({g('cell', 'diameter_mm')})")

    hold, strip, ring = g("holder"), g("nickel"), g("insulator")
    pitch, dia = g("pack", "cell_pitch_mm"), g("cell", "diameter_mm")
    if hold["recess_mm"] >= hold["height_mm"]:
        errors.append("holder.recess_mm must be smaller than holder.height_mm")
    if strip["thickness_mm"] > hold["recess_mm"]:
        errors.append(f"nickel.thickness_mm ({strip['thickness_mm']}) must fit in holder.recess_mm "
                      f"({hold['recess_mm']}): the strip lies on the cell ends below the holder face")
    if hold["bore_mm"] < dia - BORE_PRESS_FIT_MM:
        errors.append(f"holder.bore_mm ({hold['bore_mm']}) is more than {BORE_PRESS_FIT_MM} mm smaller than "
                      f"the cell diameter ({dia}): too tight even for a press fit")
    if hold["bore_mm"] > pitch:
        errors.append(f"holder.bore_mm ({hold['bore_mm']}) is larger than the cell pitch ({pitch})")
    if hold["tab_gap_mm"] >= pitch:
        errors.append("holder.tab_gap_mm must be smaller than the cell pitch")
    if 2 * strip["leg_mm"] >= strip["width_mm"]:
        errors.append("nickel.leg_mm must be less than half of nickel.width_mm (the strip needs its holes)")
    if strip["bar_mm"] >= pitch:
        errors.append("nickel.bar_mm must be smaller than the cell pitch (the strip needs its holes)")
    if strip["width_mm"] >= 2 * pitch:
        errors.append(f"nickel.width_mm ({strip['width_mm']}) must be less than two cell pitches, or "
                      "neighbouring strips at the same end would touch")
    if ring["id_mm"] >= hold["bore_mm"]:
        errors.append("insulator.id_mm must be smaller than holder.bore_mm")
    if strip["weld_slot_length_mm"] >= pitch - 2 or strip["weld_slot_width_mm"] >= strip["leg_mm"] / 2:
        errors.append("nickel weld slots must fit on a strip leg over one cell (width < half the leg)")
    if not strip["k_factor"] < 1:
        errors.append(f"nickel.k_factor ({strip['k_factor']}) must be between 0 and 1 (Fusion sheet metal rule)")
    if strip["bend_radius_mm"] >= hold["height_mm"] - hold["recess_mm"]:
        errors.append("nickel.bend_radius_mm must be smaller than the holder height above the cell end: "
                      "the balance tab folds over the holder's top edge")
    if strip["end_inset_mm"] >= dia / 2 - strip["leg_mm"] / 2:
        errors.append("nickel.end_inset_mm leaves no strip past the leg: it must be well under the cell radius")

    foam, squeeze = g("pack", "foam_thickness_mm"), g("pack", "foam_compression_mm")
    if squeeze > 0 and squeeze >= foam:
        errors.append(f"pack.foam_compression_mm ({squeeze}) must be smaller than pack.foam_thickness_mm "
                      f"({foam}): the foam cannot be squeezed to nothing")

    enc = g("enclosure")
    router = enc["min_router_diameter_mm"]
    slot_width = enc["polycarbonate_thickness_mm"] + enc["slot_clearance_mm"]
    if has_base_plate(cfg) and slot_width <= router:
        errors.append(f"base plate hook slot width ({slot_width:.2f} mm = thickness + clearance) must be "
                      f"larger than min_router_diameter_mm ({router})")
    walls = enc["printed_walls"]
    hole, web = enc["bolt_hole_diameter_mm"], walls["wall_web_mm"]
    # Each screw location holds a coupling nut in a hex pocket, flats parallel to the wall faces;
    # the wall is that pocket plus wall_web_mm each side
    fz = enc["fasteners"]
    nut, screw = fz["coupling_nut"], fz["screw"]
    pocket = nut["across_flats_mm"] + 2 * fz["pocket_clearance_mm"]
    t = pocket + 2 * web
    lo, hi = WALL_WEB_RANGE_MM
    if not lo <= web <= hi:
        errors.append(f"enclosure.printed_walls.wall_web_mm ({web}) must be between {lo:g} and {hi:g} mm "
                      f"(wall material each side of the coupling nut pocket)")
    if pocket <= hole:
        errors.append(f"the coupling nut's hex pocket ({pocket:g} mm across flats) must be larger than "
                      f"bolt_hole_diameter_mm ({hole})")
    # How far the pocket reaches toward a 45 degree joint face: half across flats / cos 15 degrees
    reach = max(hole / 2, pocket / 2 / 0.9659258)
    pct = enc["polycarbonate_thickness_mm"]
    near = screw["length_mm"] - pct                    # screw thread in the seated nut
    far = near - fz["far_nut_recess_mm"]               # ... in the recessed nut
    least = fz["min_thread_engagement_mm"]
    if far < least:
        errors.append(f"the screw ({screw['length_mm']} mm) reaches only {far:.1f} mm into the recessed coupling "
                      f"nut (screw - polycarbonate_thickness_mm - far_nut_recess_mm); want min_thread_"
                      f"engagement_mm ({least})")
    if nut["length_mm"] - near - fz["allthread_near_gap_mm"] < least:
        errors.append(f"the coupling nut ({nut['length_mm']} mm) is too short: the screw takes {near:.1f} mm of it, "
                      f"leaving less than min_thread_engagement_mm ({least}) for the allthread")
    try:
        cavity = (g("cell", "height_mm") + 2 * g("holder", "recess_mm")
                  + 2 * (g("pack", "foam_thickness_mm") - g("pack", "foam_compression_mm")))
        if 2 * nut["length_mm"] + fz["far_nut_recess_mm"] > cavity:
            errors.append(f"two coupling nuts ({nut['length_mm']} mm) and far_nut_recess_mm do not fit between "
                          f"the side plates ({cavity:.1f} mm)")
    except (KeyError, TypeError):
        pass
    trim = walls["joint_end_trim_mm"]
    # The screws keep at least the web to a 45 degree joint face and the corner screws at least a
    # wall thickness from the corner: the layout raises the configured values to that if needed
    margin = max(walls["screw_end_margin_mm"], 2 ** 0.5 * (reach + web) + trim)
    if trim >= t / 2:
        errors.append(f"enclosure.printed_walls.joint_end_trim_mm ({trim}) must be less than half the wall "
                      f"thickness ({t / 2:g})")
    if walls["min_section_mm"] < 2 * margin:
        errors.append(f"enclosure.printed_walls.min_section_mm must be at least 2 x the screw end margin "
                      f"({margin:.1f} mm): a screw near each end")
    if walls["max_section_mm"] < walls["min_section_mm"] + t:
        errors.append("enclosure.printed_walls.max_section_mm is too small for min_section_mm")
    if walls["max_screw_spacing_mm"] < 2 * margin:
        errors.append(f"enclosure.printed_walls.max_screw_spacing_mm must be at least 2 x the screw end margin "
                      f"({margin:.1f} mm)")
    for key in ("corner_inner_fillet_mm", "corner_outer_fillet_mm"):
        if walls[key] > t / 2:
            errors.append(f"enclosure.printed_walls.{key} ({walls[key]}) must be at most half the wall "
                          f"thickness ({t / 2:g})")
    if enc["plate_corner_radius_mm"] > enc["side_plate_overhang_mm"] + t / 2:
        errors.append("enclosure.plate_corner_radius_mm must not reach the corner screws' wall centerline")
    hook = hook_profile(cfg)
    hooks = has_base_plate(cfg)   # the hook checks only matter when there are hooks
    slide = hook["slot_length_mm"] - hook["slot_offset_mm"] - hook["neck_width_mm"] / 2 - hook["slot_clearance_mm"]
    if hooks and slide < 0:
        errors.append("hook slot is too short: the hook neck does not fit "  # (this pack's hook profile)
                      f"(hook.slot_length_mm - slot_offset_mm - neck_width_mm/2 - slot_clearance_mm = {slide:.2f})")
    if hooks and hook["slot_length_mm"] < hook["neck_width_mm"] + hook["nose_mm"]:
        errors.append(f"hook.slot_length_mm ({hook['slot_length_mm']}) must be at least neck_width_mm + "
                      f"nose_mm ({hook['neck_width_mm'] + hook['nose_mm']}) so the hook drops through the base plate")
    if hooks and (router / 2 >= hook["drop_extra_mm"] or router + enc["fillet_small_mm"] > hook["nose_mm"]):
        errors.append(f"min_router_diameter_mm ({router}) is too big for the hook root relief: it is cut into the "
                      f"nose, which needs router + fillet_small_mm <= nose_mm ({hook['nose_mm']}) and "
                      f"router / 2 < drop_extra_mm ({hook['drop_extra_mm']})")
    if hooks and enc["fillet_small_mm"] * 2 > hook["drop_extra_mm"]:
        errors.append("enclosure.fillet_small_mm is too large for the hook nose "
                      f"(needs 2 x fillet <= hook.drop_extra_mm = {hook['drop_extra_mm']})")

    if errors:
        raise ConfigError("invalid config:\n  - " + "\n  - ".join(errors))


def load_config(path: str | Path) -> dict[str, Any]:
    """Read a config JSON file and validate it."""
    try:
        with open(path, encoding="utf-8") as fh:
            cfg = json.load(fh)
    except json.JSONDecodeError as exc:
        raise ConfigError(f"{path} is not valid JSON: {exc}") from exc
    validate_config(cfg)
    return cfg
