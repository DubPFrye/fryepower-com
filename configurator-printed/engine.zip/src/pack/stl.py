"""STL meshes for the printed parts, in plain Python (no dependencies). Millimeters.

A printed part (``Part`` with process '3d_print') is its cross-section extruded ``thickness_mm``:
the outline and its round holes are triangulated (ear clipping, each hole bridged to the outline
first) for the two end caps, and every boundary edge becomes a side wall. The mesh is closed and
every facet faces outward.
"""
from __future__ import annotations

import math
import struct
from pathlib import Path
from typing import Sequence

from .contours import Circle, Point

Vec3 = tuple[float, float, float]
Triangle = tuple[Vec3, Vec3, Vec3]
HOLE_SEGMENTS = 32         # round holes become 32-sided polygons
ARC_TOL_MM = 0.05          # arcs in an outline are flattened within this distance


def _area(poly: Sequence[Point]) -> float:
    return sum(poly[i][0] * poly[(i + 1) % len(poly)][1] - poly[(i + 1) % len(poly)][0] * poly[i][1]
               for i in range(len(poly))) / 2


def _cross(o: Point, a: Point, b: Point) -> float:
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def _segments_cross(p1: Point, p2: Point, q1: Point, q2: Point) -> bool:
    """True if the open segments p1-p2 and q1-q2 properly intersect (touching ends do not count)."""
    d1, d2 = _cross(q1, q2, p1), _cross(q1, q2, p2)
    d3, d4 = _cross(p1, p2, q1), _cross(p1, p2, q2)
    return ((d1 > 1e-12 and d2 < -1e-12) or (d1 < -1e-12 and d2 > 1e-12)) and \
           ((d3 > 1e-12 and d4 < -1e-12) or (d3 < -1e-12 and d4 > 1e-12))


def _bridge(outer: list[Point], hole: list[Point], others: list[list[Point]]) -> list[Point]:
    """Join a (clockwise) hole into the (counter-clockwise) outline with a two-way cut from the
    hole's rightmost vertex to the nearest outline vertex it can see."""
    mi = max(range(len(hole)), key=lambda i: (hole[i][0], -hole[i][1]))
    m = hole[mi]
    edges = [(poly[i], poly[(i + 1) % len(poly)]) for poly in [outer, hole] + others for i in range(len(poly))]

    verts = [v for poly in [outer, hole] + others for v in poly]

    def on_segment(v: Point, p: Point) -> bool:
        """v lies strictly inside the segment m-p (collinear vertices, as on a wall's centerline,
        where the hex pockets' corners line up with the V tips)."""
        if v in (m, p) or abs(_cross(m, p, v)) > 1e-9:
            return False
        t = ((v[0] - m[0]) * (p[0] - m[0]) + (v[1] - m[1]) * (p[1] - m[1])) / (math.dist(m, p) ** 2 or 1.0)
        return 1e-9 < t < 1 - 1e-9

    def visible(p: Point) -> bool:
        return (not any(_segments_cross(m, p, a, b) for a, b in edges)
                and not any(on_segment(v, p) for v in verts))

    candidates = sorted(range(len(outer)), key=lambda i: math.dist(outer[i], m))
    # prefer an outline vertex no earlier bridge already ends at (a vertex used three times trips
    # the ear clipping)
    fresh = [i for i in candidates if outer.count(outer[i]) == 1]
    oi = next((i for i in fresh if visible(outer[i])), None)
    if oi is None:
        oi = next(i for i in candidates if visible(outer[i]))
    ring = hole[mi:] + hole[:mi + 1]          # around the hole, back to m
    return outer[:oi + 1] + ring + outer[oi:]


def _in_triangle(p: Point, a: Point, b: Point, c: Point) -> bool:
    """Inside or on the edge of triangle abc (points on an edge block an ear too: with collinear
    vertices, as on a wall's centerline, a strict test lets ears cut across holes)."""
    return _cross(a, b, p) >= -1e-9 and _cross(b, c, p) >= -1e-9 and _cross(c, a, p) >= -1e-9


def triangulate(outline: Sequence[Point], holes: Sequence[Sequence[Point]] = ()) -> list[tuple[Point, Point, Point]]:
    """Counter-clockwise triangles covering the outline minus the holes."""
    outer = list(outline) if _area(outline) > 0 else list(reversed(outline))
    hs = [list(h) if _area(h) < 0 else list(reversed(h)) for h in holes]
    hs.sort(key=lambda h: -max(x for x, _ in h))
    for i, h in enumerate(hs):
        outer = _bridge(outer, h, hs[i + 1:])
    poly = outer
    tris: list[tuple[Point, Point, Point]] = []
    guard = 0
    while len(poly) > 3:
        n = len(poly)
        for i in range(n):
            a, b, c = poly[i - 1], poly[i], poly[(i + 1) % n]
            if _cross(a, b, c) <= 1e-9:
                continue                     # reflex or flat: not an ear
            if any(_in_triangle(p, a, b, c) for p in poly if p not in (a, b, c)):
                continue
            tris.append((a, b, c))
            del poly[i]
            break
        else:
            # Only degenerate (zero-area) corners left, e.g. at a bridge: drop one and go on
            for i in range(n):
                if abs(_cross(poly[i - 1], poly[i], poly[(i + 1) % n])) <= 1e-9:
                    del poly[i]
                    break
            else:
                raise ValueError("triangulation failed: polygon is self-intersecting")
        guard += 1
        if guard > 100000:
            raise ValueError("triangulation did not finish")
    if len(poly) == 3 and _cross(*poly) > 1e-9:
        tris.append((poly[0], poly[1], poly[2]))
    return tris


def extrude(outline: Sequence[Point], holes: Sequence[Sequence[Point]], height: float) -> list[Triangle]:
    """A closed mesh: the outline minus the holes, from z = 0 to z = height."""
    outer = list(outline) if _area(outline) > 0 else list(reversed(outline))
    hs = [list(h) if _area(h) < 0 else list(reversed(h)) for h in holes]
    tris: list[Triangle] = []
    for a, b, c in triangulate(outer, hs):
        tris.append(((a[0], a[1], height), (b[0], b[1], height), (c[0], c[1], height)))   # top, +z
        tris.append(((a[0], a[1], 0.0), (c[0], c[1], 0.0), (b[0], b[1], 0.0)))            # bottom, -z
    for loop in [outer] + hs:            # outer counter-clockwise, holes clockwise: the walls face out
        for i in range(len(loop)):
            (ax, ay), (bx, by) = loop[i], loop[(i + 1) % len(loop)]
            a0, b0, a1, b1 = (ax, ay, 0.0), (bx, by, 0.0), (ax, ay, height), (bx, by, height)
            tris += [(a0, b0, b1), (a0, b1, a1)]
    return tris


def part_mesh(part) -> list[Triangle]:   # part: pack.geometry.Part (printed)
    """The mesh of a printed part, in its own frame (cross-section in XY, extruded along +Z)."""
    outline = part.outline.points(tol=ARC_TOL_MM)
    holes = []
    for c in part.cutouts:
        if isinstance(c, Circle):
            # half a step around, so no hole vertex lies on the wall centerline with the V tips
            step = 2 * math.pi / HOLE_SEGMENTS
            holes.append([(c.cx + c.r * math.cos(step * (i + 0.5)), c.cy + c.r * math.sin(step * (i + 0.5)))
                          for i in range(HOLE_SEGMENTS)])
        else:
            holes.append(c.points(tol=ARC_TOL_MM))
    # Snap to a micron grid, so points meant to be collinear (the V tips and the hex pockets'
    # corners on a wall's centerline) are, and the triangulation does not trip on round-off
    snap = lambda pts: [(round(x, 6), round(y, 6)) for x, y in pts]  # noqa: E731
    return extrude(snap(outline), [snap(h) for h in holes], part.thickness_mm)


def _normal(t: Triangle) -> Vec3:
    (ax, ay, az), (bx, by, bz), (cx, cy, cz) = t
    ux, uy, uz, vx, vy, vz = bx - ax, by - ay, bz - az, cx - ax, cy - ay, cz - az
    n = (uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx)
    length = math.sqrt(sum(c * c for c in n)) or 1.0
    return (n[0] / length, n[1] / length, n[2] / length)


def stl_bytes(triangles: Sequence[Triangle], name: str = "part") -> bytes:
    """Binary STL."""
    header = name.encode("ascii", "replace")[:80].ljust(80, b" ")
    out = [header, struct.pack("<I", len(triangles))]
    for t in triangles:
        out.append(struct.pack("<12fH", *_normal(t), *t[0], *t[1], *t[2], 0))
    return b"".join(out)


def write_stl(path: str | Path, triangles: Sequence[Triangle], name: str = "part") -> None:
    Path(path).write_bytes(stl_bytes(triangles, name))


def read_stl(data: bytes) -> list[Triangle]:
    """Parse a binary STL (for tests)."""
    (n,) = struct.unpack_from("<I", data, 80)
    tris = []
    for i in range(n):
        v = struct.unpack_from("<12f", data, 84 + 50 * i)
        tris.append(((v[3], v[4], v[5]), (v[6], v[7], v[8]), (v[9], v[10], v[11])))
    return tris


def mesh_volume(triangles: Sequence[Triangle]) -> float:
    """Signed volume (positive for an outward-facing closed mesh)."""
    total = 0.0
    for (ax, ay, az), (bx, by, bz), (cx, cy, cz) in triangles:
        total += (ax * (by * cz - bz * cy) - ay * (bx * cz - bz * cx) + az * (bx * cy - by * cx)) / 6
    return total
