"""Pack and enclosure geometry in plain Python: dimensions, layout and part outlines.

Nothing here depends on Fusion 360. The Fusion script, the DXF and STL generators and the BOM
all read the same numbers from here, and everything is computed from one config dict
(see ``pack.config``). Units are millimeters.

Model frame (matches the Fusion script): X = pack length along the bike (front = +X,
rear = -X), Y = height, Z = cell length. Side plates lie in the XY plane at +/-Z.

Enclosure (printed-wall design, docs/DESIGN_PRINTED_WALLS.md): two polycarbonate side plates with
square corners, plain M5 holes and the base-plate hooks; between them a ring of 3D-printed ABS
wall pieces (an L piece at each corner, straight sections between) joined with 45 degree V ends.
The screws run through the plates into the wall ring on its centerline. The sectioning rule is
``wall_layout`` (docs/WALL_SECTIONING.md).
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from .config import ConfigError, FUSION_PARAM_MAP, get_path, has_base_plate, hook_profile, validate_config
from .contours import (
    Circle, Point, Polyline, Shape, bbox_gap, fillet_polygon, min_gap, rectangle, rounded_rectangle,
    slot_with_dogbones,
)

SCS_MIN_ROUTED_FEATURE_MM = 3.175   # 0.125 in: smallest cutout SendCutSend routes
SCS_MIN_WEB_FACTOR = 2.0            # minimum web (bridge) between features, x material thickness


@dataclass(frozen=True)
class Dimensions:
    """Every parameter, named as the lower-case form of its Fusion user parameter."""
    # --- inputs ---
    columns: int
    rows: int
    cell_diameter: float
    cell_height: float
    cell_pitch: float
    holder_height: float
    holder_recess: float
    holder_bore: float
    holder_tab_gap: float
    insulator_id: float
    insulator_thickness: float
    strip_width: float
    strip_thickness: float
    strip_leg: float
    strip_bar: float
    strip_end_inset: float
    weld_slot_length: float
    weld_slot_width: float
    strip_bend_radius: float
    strip_k_factor: float
    foam_thickness: float
    foam_compression: float
    extra_height: float
    extra_length: float
    polycarbonate_thickness: float
    side_plate_overhang: float
    plate_corner_radius: float
    alu_thickness: float
    base_front_extension: float
    base_rear_extension: float
    side_extension: float
    min_cnc_router_diameter: float
    slot_clearance: float
    cut_overshoot: float
    bolt_hole_diameter: float
    wall_web: float
    corner_inner_fillet: float
    corner_outer_fillet: float
    max_section: float
    min_section: float
    screw_end_margin: float
    corner_screw_setback: float
    max_screw_spacing: float
    joint_end_trim: float
    screw_length: float
    thread_diameter: float
    coupling_nut_af: float
    coupling_nut_length: float
    pocket_clearance: float
    far_nut_recess: float
    allthread_near_gap: float
    allthread_far_gap: float
    hook_max_spacing: float
    hook_neck_width: float
    hook_nose: float
    hook_drop_extra: float
    hook_overlap: float
    hook_slot_length: float
    hook_slot_offset: float
    hook_slot_clearance: float
    fillet_large: float
    fillet_small: float
    # --- derived ---
    strip_bend_allowance: float
    bolt_edge_offset: float
    slot_width: float
    hook_drop: float
    foam_gap: float
    core_depth: float
    cavity_depth: float
    cell_core_width: float
    cell_core_height: float
    cavity_width: float
    cavity_height: float
    plate_width: float
    plate_height: float
    base_plate_x_length: float
    base_plate_z_width: float
    battery_latch_slide: float
    pocket_af: float                # hex pocket across flats (coupling nut + clearance)
    wall_thickness: float           # the pocket + wall_web each side
    allthread_length: float         # between the two screws' tips, less a gap at each
    base_plate: bool = True        # False: no base plate and no hooks


def strip_bend_allowance(bend_radius: float, k_factor: float, thickness: float) -> float:
    """Flat length used up by one 90 degree bend in the nickel strip: the arc through the neutral
    axis, which sits k_factor x thickness from the inside face (the Fusion sheet metal rule's
    K factor). The Fusion script's Strip_Bend_Allowance parameter is the same formula."""
    return math.pi / 2 * (bend_radius + k_factor * thickness)


def derive_dimensions(cfg: dict[str, Any]) -> Dimensions:
    """Validate the config and compute every dimension (same formulas as the Fusion script)."""
    validate_config(cfg)
    v: dict[str, Any] = {name.lower(): get_path(cfg, path) for name, path in FUSION_PARAM_MAP.items()}
    v["columns"], v["rows"] = int(v["columns"]), int(v["rows"])
    # Short packs use the small hook profile (enclosure.small_hook) in place of enclosure.hook
    for key, value in hook_profile(cfg).items():
        v["hook_" + key.removesuffix("_mm")] = value
    f = lambda k: float(v[k])  # noqa: E731

    # The wall is the coupling nut's hex pocket plus wall_web of material each side
    v["pocket_af"] = f("coupling_nut_af") + 2 * f("pocket_clearance")
    v["wall_thickness"] = v["pocket_af"] + 2 * f("wall_web")
    # The screws sit on the wall ring's centerline; the side plate stops side_plate_overhang
    # outside the ring's outer face
    v["bolt_edge_offset"] = f("side_plate_overhang") + f("wall_thickness") / 2
    v["slot_width"] = f("polycarbonate_thickness") + f("slot_clearance")   # base-plate hook slots
    v["hook_drop"] = f("alu_thickness") + f("hook_drop_extra")
    v["strip_bend_allowance"] = strip_bend_allowance(f("strip_bend_radius"), f("strip_k_factor"),
                                                     f("strip_thickness"))
    # The foam is squeezed when the pack is closed: the room left for it is thinner than the foam
    v["foam_gap"] = f("foam_thickness") - f("foam_compression")
    # Cells plus a holder at each end: the cell end sits holder_recess below the holder face, and
    # the nickel strip and insulator ring fit in that recess, so the holder faces are the outside
    v["core_depth"] = f("cell_height") + 2 * f("holder_recess")
    v["cavity_depth"] = v["core_depth"] + 2 * v["foam_gap"]
    v["cell_core_width"] = v["columns"] * f("cell_pitch")
    v["cell_core_height"] = v["rows"] * f("cell_pitch")
    # Room for the BMS, fuses and wiring, which vary from build to build: extra_height above the
    # cells, extra_length along the pack (half beyond each end of the cell block)
    v["cavity_width"] = v["cell_core_width"] + f("extra_length") + 2 * v["foam_gap"]
    v["cavity_height"] = v["cell_core_height"] + f("extra_height") + 2 * v["foam_gap"]
    rim = f("wall_thickness") + f("side_plate_overhang")
    v["plate_width"] = v["cavity_width"] + 2 * rim
    v["plate_height"] = v["cavity_height"] + 2 * rim
    v["base_plate_x_length"] = v["plate_width"] + f("base_front_extension") + f("base_rear_extension")
    v["base_plate_z_width"] = v["cavity_depth"] + 2 * f("polycarbonate_thickness") + 2 * f("side_extension")
    v["battery_latch_slide"] = (f("hook_slot_length") - f("hook_slot_offset")
                                - f("hook_neck_width") / 2 - f("hook_slot_clearance"))
    # Fasteners at every screw location: a coupling nut in a hex pocket at each end of the wall,
    # joined by allthread; a screw through each side plate into its nut
    v["allthread_length"] = (v["cavity_depth"] - 2 * (f("screw_length") - f("polycarbonate_thickness"))
                             - f("allthread_near_gap") - f("allthread_far_gap"))
    v["base_plate"] = has_base_plate(cfg)
    return Dimensions(**v)


# ---------------------------------------------------------------------------------------
# Printed wall ring: sectioning (docs/WALL_SECTIONING.md)
# ---------------------------------------------------------------------------------------
# The ring's centerline is walked counter-clockwise in model XY, edge by edge:
# 0 = bottom (+X), 1 = front end (+Y), 2 = top (-X), 3 = rear end (-Y).
EDGE_DIRS: tuple[Point, ...] = ((1.0, 0.0), (0.0, 1.0), (-1.0, 0.0), (0.0, -1.0))
EDGE_NAMES = ("bottom", "front end", "top", "rear end")


def min_corner_setback(d: Dimensions) -> float:
    """Closest a corner screw may sit to the corner: the two corner screws (one on each edge) keep
    SendCutSend's 2 x thickness web between their holes in the side plate."""
    return (d.bolt_hole_diameter + SCS_MIN_WEB_FACTOR * d.polycarbonate_thickness) / math.sqrt(2.0)


@dataclass(frozen=True)
class WallEdge:
    """One edge of the wall ring, positions measured along its centerline from its start corner."""
    index: int                      # 0 bottom, 1 front end, 2 top, 3 rear end
    length: float                   # corner to corner, on the centerline
    joints: tuple[float, ...]       # where the V joints' tips sit
    screws: tuple[float, ...]       # screw positions (corner screws included)
    setback: float                  # corner screws' distance from each corner


def screw_rules(d: Dimensions) -> tuple[float, float]:
    """(corner setback, end margin) the layout uses: the configured values, raised if needed so a
    corner screw sits at least a wall thickness from the corner, and every pocket keeps wall_web of
    material to the 45 degree face of a joint (the hex reaches half across flats / cos 15 degrees
    toward it), after the joint's end trim."""
    reach = max(d.bolt_hole_diameter / 2, d.pocket_af / 2 / math.cos(math.radians(15)))
    margin = max(d.screw_end_margin, math.sqrt(2.0) * (reach + d.wall_web) + d.joint_end_trim)
    return max(d.corner_screw_setback, d.wall_thickness), margin


def edge_plan(length: float, d: Dimensions) -> tuple[tuple[float, ...], tuple[float, ...], float]:
    """(joints, screws, corner setback) along one edge of the given centerline length.

    Corner legs are setback + margin long. If what is left between them is at least min_section,
    it is split into the fewest equal straight sections that keep every piece within max_section
    (a piece reaches wall_thickness / 2 past its female joint), each with a screw margin from both
    ends and more between them, at most max_screw_spacing apart. Otherwise the two corner pieces
    meet in the middle of the edge and their screws move in to stay a margin from that joint."""
    s, e = screw_rules(d)
    leg = s + e
    middle = length - 2 * leg
    if middle >= d.min_section - 1e-9:
        n = max(1, math.ceil(middle / (d.max_section - d.wall_thickness / 2) - 1e-9))
        sec = middle / n
        joints = tuple(leg + i * sec for i in range(n + 1))
        screws = [s]
        k = max(1, math.ceil((sec - 2 * e) / d.max_screw_spacing - 1e-9))
        for j0 in joints[:-1]:
            screws += [j0 + e + i * (sec - 2 * e) / k for i in range(k + 1)]
        screws.append(length - s)
        return joints, tuple(screws), s
    setback = min(s, length / 2 - e)
    if setback < min_corner_setback(d) - 1e-9:
        raise ConfigError(
            f"invalid config:\n  - a {length:.1f} mm wall edge is too short for two corner screws "
            f"{e:g} mm from the joint and {min_corner_setback(d):.1f} mm from the corner")
    return (length / 2,), (setback, length - setback), setback


@dataclass(frozen=True)
class WallPiece:
    """One printed wall piece, placed in the model. Its female V end is at ``start``, its male V
    end at ``end`` (edge, position along that edge); a corner piece turns from start's edge onto
    the next one."""
    start: tuple[int, float]
    end: tuple[int, float]
    outline: tuple[Point, ...]      # cross-section in model XY, counter-clockwise
    screws: tuple[Point, ...]       # screw centers in model XY

    @property
    def corner(self) -> bool:
        return self.start[0] != self.end[0]


@dataclass(frozen=True)
class WallLayout:
    half_x: float                   # centerline rectangle half sizes
    half_y: float
    thickness: float
    edges: tuple[WallEdge, ...]
    pieces: tuple[WallPiece, ...]

    def point(self, edge: int, s: float, n: float = 0.0) -> Point:
        """Model XY of the point ``s`` along ``edge`` from its start corner, ``n`` outward from
        the centerline."""
        return _edge_point(self.half_x, self.half_y, edge, s, n)

    @property
    def screws(self) -> tuple[Point, ...]:
        return tuple(p for piece in self.pieces for p in piece.screws)


def _edge_point(hx: float, hy: float, edge: int, s: float, n: float) -> Point:
    starts = ((-hx, -hy), (hx, -hy), (hx, hy), (-hx, hy))
    (x0, y0), (dx, dy) = starts[edge], EDGE_DIRS[edge]
    ox, oy = dy, -dx                # outward = the right of the walking direction
    return (x0 + s * dx + n * ox, y0 + s * dy + n * oy)


def wall_layout(d: Dimensions) -> WallLayout:
    """Split the wall ring into printable pieces and place the screws (docs/WALL_SECTIONING.md)."""
    t, h = d.wall_thickness, d.wall_thickness / 2
    c = d.joint_end_trim        # each V end is cut back this far along the wall: a 2c gap per joint
    hx, hy = d.cavity_width / 2 + h, d.cavity_height / 2 + h
    lengths = (2 * hx, 2 * hy, 2 * hx, 2 * hy)
    edges = []
    for k, length in enumerate(lengths):
        joints, screws, setback = edge_plan(length, d)
        edges.append(WallEdge(k, length, joints, screws, setback))
    P = lambda k, s, n=0.0: _edge_point(hx, hy, k, s, n)  # noqa: E731
    ring = [(e.index, j) for e in edges for j in e.joints]
    pieces = []
    for i, (ka, sa) in enumerate(ring):
        kb, sb = ring[(i + 1) % len(ring)]
        if ka == kb:
            outline = [P(ka, sa + c - h, h), P(ka, sb - c - h, h), P(ka, sb - c), P(ka, sb - c - h, -h),
                       P(ka, sa + c - h, -h), P(ka, sa + c)]
            screws = [P(ka, s) for s in edges[ka].screws if sa < s < sb]
        else:
            la = lengths[ka]
            outline = [P(ka, sa + c - h, h), P(ka, la + h, h), P(kb, sb - c - h, h), P(kb, sb - c),
                       P(kb, sb - c - h, -h), P(ka, la - h, -h), P(ka, sa + c - h, -h), P(ka, sa + c)]
            screws = [P(ka, s) for s in edges[ka].screws if s > sa] + [P(kb, s) for s in edges[kb].screws if s < sb]
        pieces.append(WallPiece((ka, sa), (kb, sb), tuple(outline), tuple(screws)))
    return WallLayout(hx, hy, t, tuple(edges), tuple(pieces))


def piece_local(piece: WallPiece) -> tuple[tuple[Point, ...], tuple[Point, ...]]:
    """A piece's outline and screws in its own frame: origin at its female joint tip, +x along the
    wall toward the male end, +y inward. Identical pieces give identical local shapes."""
    ka = piece.start[0]
    dx, dy = EDGE_DIRS[ka]
    lx, ly = -dy, dx                                    # inward (left of the walking direction)
    sx = piece.outline[-1]                              # the female notch tip is the last vertex
    loc = lambda p: ((p[0] - sx[0]) * dx + (p[1] - sx[1]) * dy,  # noqa: E731
                     (p[0] - sx[0]) * lx + (p[1] - sx[1]) * ly)
    return tuple(loc(p) for p in piece.outline), tuple(loc(p) for p in piece.screws)


def screw_along_x(wall: WallLayout, p: Point) -> bool:
    """True if the screw at p sits in a wall running along X (bottom or top), False for an end wall."""
    return abs(abs(p[1]) - wall.half_y) < 1e-6


def pocket_hex(cx: float, cy: float, along_x: bool, across_flats: float) -> Polyline:
    """The hex pocket for a coupling nut, counter-clockwise. Clocked so its flats lie parallel to
    the wall faces (two corners point along the wall): the wall then only needs the across-flats
    size plus its webs, the least extra thickness."""
    r = across_flats / math.sqrt(3.0)              # center to corner
    pts = []
    for k in range(6):
        a = math.radians(60 * k)
        ca, sa = r * math.cos(a), r * math.sin(a)
        pts.append((cx + ca, cy + sa, 0.0) if along_x else (cx - sa, cy + ca, 0.0))
    return Polyline(tuple(pts))


@dataclass(frozen=True)
class FastenerStack:
    """Along Z at every screw location (z = 0 midway between the side plates' inside faces): the
    seated coupling nut against the front (-Z) plate, the recessed one far_nut_recess short of the
    rear (+Z) plate, the allthread between them, and how far each screw threads into its nut."""
    near_nut: tuple[float, float]
    far_nut: tuple[float, float]
    allthread: tuple[float, float]
    near_engagement: float          # screw thread in the seated nut
    far_engagement: float           # ... in the recessed nut
    near_rod_engagement: float      # allthread in the seated nut
    far_rod_engagement: float


def fastener_stack(d: Dimensions) -> FastenerStack:
    z2, ln = d.cavity_depth / 2, d.coupling_nut_length
    near, far = (-z2, -z2 + ln), (z2 - d.far_nut_recess - ln, z2 - d.far_nut_recess)
    e1 = d.screw_length - d.polycarbonate_thickness
    # Assembly: the allthread is run into the seated nut until it bottoms on that screw's tip
    # (near gap 0); its other end stops allthread_far_gap short of the rear screw's tip
    rod = (-z2 + e1 + d.allthread_near_gap, z2 - e1 - d.allthread_far_gap)
    return FastenerStack(near, far, rod, e1, e1 - d.far_nut_recess, near[1] - rod[0], rod[1] - far[0])


def corner_radii(d: Dimensions, corner: bool) -> dict[int, float]:
    """Fillets on a piece's outline vertices: a corner piece's outside corner (vertex 1) and inside
    corner (vertex 5); none on straight sections."""
    return {1: d.corner_outer_fillet, 5: d.corner_inner_fillet} if corner else {}


def _filleted(points: tuple[Point, ...] | list[Point], radii: dict[int, float]) -> Polyline:
    return fillet_polygon([(x, y, radii.get(i, 0.0)) for i, (x, y) in enumerate(points)])


def piece_polyline(piece: WallPiece, d: Dimensions) -> Polyline:
    """A piece's cross-section as a polyline (model XY), corner fillets included."""
    return _filleted(piece.outline, corner_radii(d, piece.corner))


def piece_kinds(lay: WallLayout) -> list[tuple[int, list[int]]]:
    """Group identical pieces: [(index of the first piece of a kind, [indices of all of them])],
    straight sections first, then corner pieces, each in ring order."""
    def shape(i: int) -> list[float]:
        outline, screws = piece_local(lay.pieces[i])
        return [len(outline), len(screws)] + [v for p in outline + screws for v in p]

    def same(a: list[float], b: list[float]) -> bool:
        # within a micron (rounding to a fixed number of decimals could split a tie)
        return len(a) == len(b) and a[:2] == b[:2] and all(abs(x - y) < 1e-3 for x, y in zip(a, b))
    kinds: list[tuple[list[float], list[int]]] = []
    order = sorted(range(len(lay.pieces)), key=lambda i: lay.pieces[i].corner)
    for i in order:
        s = shape(i)
        match = next((members for k, members in kinds if same(k, s)), None)
        if match is None:
            kinds.append((s, [i]))
        else:
            match.append(i)
    return [(members[0], members) for _, members in kinds]


def hook_positions(d: Dimensions, wall: WallLayout) -> tuple[float, ...]:
    """L-hook centers along X: the fewest (at least 2) evenly spaced along the wall ring's bottom
    edge that keep them hook_max_spacing apart or less, at the middle of equal shares of that edge
    (not tied to the screw positions); one centered hook if two would crowd the base plate. None
    without a base plate."""
    if not d.base_plate:
        return ()
    span = wall.edges[0].length
    n = max(2, math.ceil(span / d.hook_max_spacing - 1e-9))
    xs = tuple(-span / 2 + (i + 0.5) * span / n for i in range(n))
    return xs if _hooks_fit(xs, d, _straight_half(d)) else (0.0,)


def _straight_half(d: Dimensions) -> float:
    """Half the straight part of the side plate's bottom edge, where the hooks hang."""
    return d.plate_width / 2 - d.plate_corner_radius


def _hooks_fit(hook_xs: tuple[float, ...], d: Dimensions, straight: float) -> bool:
    """Neighbouring base-plate slots keep at least one plate thickness of aluminum between them,
    and every hook neck (with its corner reliefs) stays on the straight part of the side plate's
    bottom edge (``straight`` = half its length)."""
    gap = min(b - a for a, b in zip(hook_xs, hook_xs[1:])) - d.hook_slot_length
    return gap >= d.alu_thickness and max(abs(x) for x in hook_xs) + d.hook_neck_width / 2 + d.min_cnc_router_diameter <= straight


@dataclass(frozen=True)
class Layout:
    """Positions that depend on the pack size (all relative to the cavity center)."""
    wall: WallLayout
    hook_xs: tuple[float, ...]                      # L-hook centers along X (none without a base plate)

    @property
    def bolt_points(self) -> tuple[Point, ...]:
        """Screw centers in the side plate (the same holes go through the wall ring)."""
        return self.wall.screws


def derive_layout(d: Dimensions) -> Layout:
    wall = wall_layout(d)
    return Layout(wall, hook_positions(d, wall))


@dataclass(frozen=True)
class Part:
    """One part. Cut parts: the flat outline, lower-left bounding corner at (0, 0). Printed parts
    (process '3d_print'): the cross-section, extruded ``thickness_mm`` (the print height)."""
    key: str                      # 'side_plate', 'wall_section_1', 'corner_1', 'base_plate'
    part_number: str              # e.g. '20S4P-SP'
    description: str
    material: str                 # e.g. 'Polycarbonate'
    thickness_mm: float
    quantity: int
    process: str                  # 'cnc_router', 'laser' or '3d_print'
    outline: Polyline
    cutouts: tuple[Shape, ...]
    origin: tuple[float, float]   # model-frame position of the flat part's (0, 0) (cut parts)

    @property
    def size(self) -> tuple[float, float]:
        x0, y0, x1, y1 = self.outline.bbox()
        return (x1 - x0, y1 - y0)

    @property
    def volume_mm3(self) -> float:
        """Solid volume (printed parts: cross-section area x height)."""
        holes = sum(c.area() if isinstance(c, Circle) else abs(c.area()) for c in self.cutouts)
        return (abs(self.outline.area()) - holes) * self.thickness_mm


def _title(material: str) -> str:
    return material.title() if material.islower() else material


def _process(material: str) -> str:
    return "cnc_router" if "polycarbonate" in material.lower() else "laser"


def _normalized(outline: Polyline, cutouts: list[Shape]) -> tuple[Polyline, tuple[Shape, ...], tuple[float, float]]:
    x0, y0, _, _ = outline.bbox()
    return (outline.translated(-x0, -y0),
            tuple(c.translated(-x0, -y0) for c in cutouts),
            (x0, y0))


def _slot(cx: float, cy: float, length: float, width: float, d: Dimensions,
          router: bool, vertical: bool = False) -> Polyline:
    """A through-slot; routed parts get dogbone reliefs, laser parts a plain rectangle."""
    if router:
        return slot_with_dogbones(cx, cy, length, width, d.min_cnc_router_diameter, vertical)
    w, h = (width, length) if vertical else (length, width)
    return rectangle(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)


def _with_hook_root_reliefs(outline: Polyline, hook_xs: tuple[float, ...], half_neck: float,
                            y_nose_top: float, r: float) -> Polyline:
    """Add a router-diameter relief at each hook's inside corner (neck meets nose top).

    The circle is centered on the nose top and tangent to the neck's inside edge, so it cuts only
    down into the nose. The neck keeps its full inside face: that face is the stop that bears on the
    end of the base-plate slot, and with a thin base plate it is only alu_thickness tall. (The nose
    loses a little at its root.) In the outline the neck edge runs down to the corner, then a
    semicircle (bulge -1: clockwise, bulging down into the nose) runs along the nose top to one
    diameter away from the neck."""
    corners = {(round(hx - half_neck, 9), round(y_nose_top, 9)) for hx in hook_xs}
    out: list[tuple[float, float, float]] = []
    for x, y, b in outline.vertices:
        if (round(x, 9), round(y, 9)) in corners:
            out += [(x, y, -1.0), (x - 2 * r, y, b)]
        else:
            out.append((x, y, b))
    return Polyline(tuple(out))


def _with_hook_neck_reliefs(outline: Polyline, hook_xs: tuple[float, ...], half_neck: float,
                            y_edge: float, r: float) -> Polyline:
    """Add a router-diameter relief where each hook neck meets the plate's bottom edge: a
    semicircle centered on the bottom edge, tangent to the neck side, cut up into the plate. The
    router then leaves no radius in the corner, so the side plate seats flat on the base plate."""
    left = {(round(hx - half_neck, 9), round(y_edge, 9)) for hx in hook_xs}
    right = {(round(hx + half_neck, 9), round(y_edge, 9)) for hx in hook_xs}
    out: list[tuple[float, float, float]] = []
    for x, y, b in outline.vertices:
        key = (round(x, 9), round(y, 9))
        if key in left:          # the edge runs +x into the neck: arc ends at the neck side
            out += [(x - 2 * r, y, -1.0), (x, y, b)]
        elif key in right:       # coming up the neck side: arc starts at the corner
            out += [(x, y, -1.0), (x + 2 * r, y, b)]
        else:
            out.append((x, y, b))
    return Polyline(tuple(out))


def _wall_parts(d: Dimensions, lay: Layout, pack_code: str, material: str) -> list[Part]:
    """One printed part per kind of wall piece, cross-section in the piece's own frame."""
    out: list[Part] = []
    n_sec = n_cor = 0
    for first, members in piece_kinds(lay.wall):
        piece = lay.wall.pieces[first]
        outline, screws = piece_local(piece)
        edges = sorted({EDGE_NAMES[lay.wall.pieces[i].start[0]] for i in members})
        if piece.corner:
            n_cor += 1
            key, pn = f"corner_{n_cor}", f"{pack_code}-WC{n_cor}"
            legs = (lay.wall.edges[piece.start[0]].length - piece.start[1], piece.end[1])
            desc = f"Printed corner piece, legs {legs[0]:.1f} / {legs[1]:.1f} mm"
        else:
            n_sec += 1
            key, pn = f"wall_section_{n_sec}", f"{pack_code}-WS{n_sec}"
            desc = f"Printed wall section ({' / '.join(edges)}), {piece.end[1] - piece.start[1]:.1f} mm"
        # Hex pockets for the coupling nuts, through the piece; in the piece's frame +x runs along
        # its first leg, so a screw off y = 0 is on a corner piece's second leg (along y)
        o, c, org = _normalized(_filleted(outline, corner_radii(d, piece.corner)),
                                [pocket_hex(x, y, abs(y) < 1e-6, d.pocket_af) for x, y in screws])
        out.append(Part(key, pn, desc, material, d.cavity_depth, len(members), "3d_print", o, c, (0.0, 0.0)))
    return out


def build_parts(cfg: dict[str, Any]) -> list[Part]:
    """All distinct parts: side plate, the printed wall pieces, base plate (if any)."""
    d = derive_dimensions(cfg)
    lay = derive_layout(d)
    enc = cfg["enclosure"]
    pack_code = f"{cfg['pack']['series']}S{cfg['pack']['parallel']}P"
    plate_mat, base_mat = _title(enc["plate_material"]), _title(enc["base_material"])
    plate_router = _process(plate_mat) == "cnc_router"
    base_router = _process(base_mat) == "cnc_router"
    pct, alu = d.polycarbonate_thickness, d.alu_thickness
    parts: list[Part] = []

    # ---- Side plate (x2: front and rear are identical flat parts) --------------------
    # Square corners (plate_corner_radius round), M5 holes on the wall ring's centerline, and the
    # L-hooks along the bottom edge with their router reliefs
    pw2, ph2 = d.plate_width / 2, d.plate_height / 2
    nk, sm, rc = d.hook_neck_width / 2, d.fillet_small, d.plate_corner_radius
    corners: list[tuple[float, float, float]] = [(-pw2, -ph2, rc)]
    for hx in sorted(lay.hook_xs):   # L-hooks along the bottom edge, nose pointing -X
        y_nose_top, y_low = -ph2 - alu, -ph2 - d.hook_drop
        corners += [
            (hx - nk, -ph2, 0.0), (hx - nk, y_nose_top, 0.0),
            (hx - nk - d.hook_nose, y_nose_top, sm), (hx - nk - d.hook_nose, y_low, sm),
            (hx + nk, y_low, sm), (hx + nk, -ph2, 0.0),
        ]
    corners += [(pw2, -ph2, rc), (pw2, ph2, rc), (-pw2, ph2, rc)]
    outline = _with_hook_root_reliefs(fillet_polygon(corners), lay.hook_xs, nk, -ph2 - alu,
                                      d.min_cnc_router_diameter / 2)
    if plate_router:
        outline = _with_hook_neck_reliefs(outline, lay.hook_xs, nk, -ph2, d.min_cnc_router_diameter / 2)
    cuts: list[Shape] = [Circle(bx, by, d.bolt_hole_diameter / 2) for bx, by in lay.bolt_points]
    o, c, org = _normalized(outline, cuts)
    parts.append(Part("side_plate", f"{pack_code}-SP", "Side plate", plate_mat, pct, 2,
                      _process(plate_mat), o, c, org))

    # ---- Printed wall ring ------------------------------------------------------------
    parts += _wall_parts(d, lay, pack_code, enc["printed_walls"]["material"])

    # ---- Base plate (x1) --------------------------------------------------------------
    if not d.base_plate:
        return parts
    slide = d.battery_latch_slide
    bx0 = -(pw2 + d.base_rear_extension + slide)
    bx1 = pw2 + d.base_front_extension - slide
    bz = d.base_plate_z_width / 2
    outline = rounded_rectangle(bx0, -bz, bx1, bz, d.fillet_large)
    cuts = []
    z_slot = d.cavity_depth / 2 + pct / 2
    for hx in lay.hook_xs:
        xa, xb = hx - (d.hook_slot_length - d.hook_slot_offset), hx + d.hook_slot_offset
        for zc in (-z_slot, z_slot):
            cuts.append(_slot((xa + xb) / 2, zc, d.hook_slot_length, d.slot_width, d, base_router))
    o, c, org = _normalized(outline, cuts)
    parts.append(Part("base_plate", f"{pack_code}-BP", "Base plate", base_mat, alu, 1,
                      _process(base_mat), o, c, org))
    return parts


def check_design(cfg: dict[str, Any], parts: list[Part] | None = None) -> list[str]:
    """Manufacturing warnings for a valid config. An empty list means nothing to flag."""
    d = derive_dimensions(cfg)
    parts = parts if parts is not None else build_parts(cfg)
    warnings: list[str] = []

    if d.min_cnc_router_diameter < SCS_MIN_ROUTED_FEATURE_MM:
        warnings.append(f"min_router_diameter_mm ({d.min_cnc_router_diameter}) is below SendCutSend's "
                        f"~{SCS_MIN_ROUTED_FEATURE_MM} mm (0.125 in) smallest routed feature")

    for part in parts:
        if part.process == "3d_print":
            w, h = part.size
            if max(w, h, part.thickness_mm) > d.max_section + 1e-6:
                warnings.append(f"{part.part_number} {part.description}: {max(w, h, part.thickness_mm):.1f} mm "
                                f"is larger than max_section_mm ({d.max_section:g})")
            continue
        if part.process != "cnc_router":
            continue
        limit = SCS_MIN_WEB_FACTOR * part.thickness_mm
        shapes: list[tuple[str, Shape]] = [("edge", part.outline)] + [
            ("hole" if isinstance(c, Circle) else "slot", c) for c in part.cutouts]
        found: list[tuple[float, str]] = []
        for i in range(len(shapes)):
            for j in range(i + 1, len(shapes)):
                (ka, a), (kb, b) = shapes[i], shapes[j]
                if ka == "edge" and kb == "edge":
                    continue
                if bbox_gap(a.bbox(), b.bbox()) >= limit:
                    continue
                gap = min_gap(a, b, cap=limit)
                if gap < limit:
                    found.append((gap, "-to-".join(sorted((ka, kb)))))
        if found:
            found.sort()
            kinds = ", ".join(sorted({k for _, k in found}))
            warnings.append(
                f"{part.part_number} {part.description}: {len(found)} web(s) thinner than "
                f"{limit:.1f} mm (2 x thickness, SendCutSend's routed minimum); thinnest "
                f"{found[0][0]:.2f} mm ({found[0][1]}). Kinds: {kinds}")
    return warnings


def strip_groups(columns: int) -> list[tuple[int, int, int]]:
    """The nickel strips: (end, first column, end column) with end +1 = rear (+Z), -1 = front (-Z).

    Each column is one parallel group; neighbouring columns face opposite ways (column 0 has its
    + end at +Z), so a strip over two adjacent columns joins the + of one to the - of the next.
    At +Z the strips join columns (0, 1), (2, 3), ...; at -Z, (1, 2), (3, 4), .... The pack's
    terminals (column 0's - end at -Z, the last column's free end) get single-column strips."""
    out: list[tuple[int, int, int]] = []
    for end, start in ((1, 0), (-1, 1)):
        if start:
            out.append((end, 0, 1))
        i = start
        while i < columns:
            out.append((end, i, min(i + 2, columns)))
            i += 2
    return out
