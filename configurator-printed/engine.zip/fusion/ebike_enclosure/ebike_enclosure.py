# Author: Gemini CAD Generator v4, parameterized rewrite
# Description: Parametric e-bike battery enclosure, printed-wall design (polycarbonate side
#   plates with M5 holes, a ring of 3D-printed ABS wall pieces, 6061 aluminum base plate, foam
#   liner, cell holders, cells; empty room for the BMS and wiring). At every screw location: a
#   screw through each side plate into a coupling nut, the two nuts in a hex pocket through the
#   wall piece, joined by allthread. Nickel strips shelved.
#
# To run in Fusion 360: Shift+S (Scripts and Add-Ins) -> '+' next to My Scripts ->
# Create a new Python script, paste this in -> Run.
#
# HOW IT WORKS
#   * Every dimension is a Fusion USER PARAMETER (Modify > Change Parameters). Edit a value
#     there and the model regenerates, including Columns and Rows (the cells are built with
#     a rectangular pattern whose counts are bound to those parameters).
#   * Re-running the script keeps any parameter values you already edited, and deletes the
#     previously generated assembly before building a new one.
#   * The wall pieces, screw positions and hook count are chosen when the script runs (same
#     rule as pack.geometry.wall_layout, docs/WALL_SECTIONING.md). If you change Columns or Rows,
#     re-run the script to respace them.
#   * Orientation: X = pack length along the bike (front = +X, rear = -X), Y = height,
#     Z = cell length (the two side plates are the bike's left/right, +/-Z).
#   * Latching: the side-plate hook noses point -X. The base plate and its slots
#     stay fixed; the whole battery is slid -X by Battery_Latch_Slide so the hooks
#     sit latched in the nominal model.

import adsk.core, adsk.fusion, traceback, re, os, math, time

MM = 0.1        # 1 mm in Fusion's internal length unit (cm)
# McMaster-Carr 92137A420: black-oxide alloy steel flanged button head hex-drive screw,
# M5 x 0.8 x 16 mm. Its STEP file goes in fusion/ebike_enclosure/hardware/ (any name starting with the part number).
# Two per screw location, one through each side plate into a coupling nut.
SCREW_PART = '92137A420'
# Config enclosure.base_plate. False builds the enclosure with no aluminum base plate and no
# L-hooks on the side plates (the battery then mounts by its side plates some other way).
BASE_PLATE = True
# Nickel strips in the model. Shelved (False) for now: the sheet metal strips do not build yet
# (see docs/TODO.md), and the printed-wall design leaves them out for now (the web 3D view too).
# True builds them (sheet metal, or plates).
NICKEL_STRIPS = False
# Set in the build-package copy of this script (pack.fusion_script) to the pack it was made for.
# A package script overwrites the design's plain-value parameters with its own values, so it
# always builds its pack; the repo copy (empty name) keeps values you edited in Fusion.
CONFIG_NAME = ''
VALS = {}       # parameter name -> value in mm (unitless for counts)
SKETCHES = []   # every sketch we create, checked for full definition at the end
ISSUES = []     # non-fatal problems (a dimension that failed, etc.)
UNIT_CHECKS = [] # (label, unit name, copies, matrices) of the copied units, checked at the end

# (name, expression, units, comment). Order matters: derived entries use earlier names.
PARAMS = [
    # ---- Pack ----
    ('Columns', '20', '', 'Cells across the pack width'),
    ('Rows', '4', '', 'Cells in each column (parallel count)'),
    ('Cell_Diameter', '21', 'mm', 'Cell diameter'),
    ('Cell_Height', '70', 'mm', 'Cell length'),
    ('Cell_Pitch', '23.35', 'mm', 'Cell-to-cell pitch of the holder (square grid)'),
    ('Holder_Height', '9.4', 'mm', 'Cell holder height (one at each cell end), face to face'),
    ('Holder_Recess', '1', 'mm', 'Cell end to holder outer face; the nickel strip lies in this recess'),
    ('Holder_Bore', '21.5', 'mm', 'Cell holder bore diameter'),
    ('Holder_Tab_Gap', '10', 'mm', 'Retaining tab tips across a cell (the tab islands are Cell_Pitch - this wide)'),
    ('Insulator_ID', '12', 'mm', 'Insulator ring hole on each + end (its OD is drawn as Holder_Bore)'),
    ('Insulator_Thickness', '0.2', 'mm', 'Insulator ring thickness'),
    ('Strip_Width', '32', 'mm', '2P nickel strip width (spans two columns)'),
    ('Strip_Thickness', '0.15', 'mm', 'Nickel strip thickness'),
    ('Strip_Leg', '8.9', 'mm', 'Nickel strip side leg width (the balance tab is one leg)'),
    ('Strip_Bar', '8.9', 'mm', 'Nickel strip cross bar width (between the square holes)'),
    ('Strip_End_Inset', '1', 'mm', 'Strip ends stop this far inside the edge of the end cells'),
    ('Weld_Slot_Length', '6', 'mm', 'Weld slot length (along the strip, over each cell terminal)'),
    ('Weld_Slot_Width', '1.2', 'mm', 'Weld slot width'),
    ('Strip_Bend_Radius', '0.5', 'mm', 'Inside bend radius of the folded strip (sheet metal rule)'),
    ('Strip_K_Factor', '0.44', '', 'Sheet metal K factor for the nickel strip (neutral axis / thickness)'),
    ('Foam_Thickness', '5', 'mm', 'Neoprene foam liner thickness, uncompressed'),
    ('Foam_Compression', '1', 'mm', 'How much the foam is squeezed when the pack is closed'),
    ('Extra_Height', '10', 'mm', 'Room above the cells for the BMS, fuses and wiring'),
    ('Extra_Length', '0', 'mm', 'Room along the pack beyond the cell block, half at each end (wires, connectors)'),
    # ---- Plates / base ----
    ('Polycarbonate_Thickness', '5.6', 'mm', 'SendCutSend 0.220 in polycarbonate (side plates)'),
    ('Side_Plate_Overhang', '5', 'mm', 'Side plate margin outside the printed wall ring'),
    ('Plate_Corner_Radius', '5', 'mm', 'Side plate corner radius'),
    ('Alu_Thickness', '4.75', 'mm', 'SendCutSend 0.187 in (3/16) 6061 aluminum'),
    ('Base_Front_Extension', '20', 'mm', 'Base plate extension past the battery front edge (+X)'),
    ('Base_Rear_Extension', '20', 'mm', 'Base plate extension past the battery rear edge (-X)'),
    ('Side_Extension', '5', 'mm', 'Base plate extension past the outer faces of the side plates (+/-Z)'),
    # ---- Router and cuts ----
    ('Min_CNC_Router_Diameter', '3.2', 'mm', 'Router diameter: the hook corner reliefs'),
    ('Slot_Clearance', '0.25', 'mm', 'Base plate hook slot width minus polycarbonate thickness'),
    ('Cut_Overshoot', '1', 'mm', 'Extra cut depth so cuts pass fully through'),
    # ---- Printed wall ring (docs/WALL_SECTIONING.md) ----
    # Pieces and screw positions are set when the script runs (re-run after resizing).
    ('Bolt_Hole_Diameter', '5.3', 'mm', 'M5 clearance hole (side plates and wall ring)'),
    ('Wall_Web', '3', 'mm', 'Wall material each side of the coupling nut pocket (2 to 8; sets Wall_Thickness)'),
    ('Corner_Inner_Fillet', '3', 'mm', 'Fillet on the inside of each printed corner piece'),
    ('Corner_Outer_Fillet', '3', 'mm', 'Fillet on the outside of each printed corner piece'),
    ('Max_Section', '200', 'mm', 'Largest printed piece in any direction (printer bed 220 x 220)'),
    ('Min_Section', '40', 'mm', 'Shortest straight section; a shorter edge joins its corner pieces in the middle'),
    ('Screw_End_Margin', '12', 'mm', 'Screw to joint (V tip), along the wall centerline'),
    ('Corner_Screw_Setback', '20', 'mm', 'Corner screws: distance from the corner along each leg'),
    ('Max_Screw_Spacing', '100', 'mm', 'Largest screw spacing within a wall section'),
    ('Joint_End_Trim', '0.1', 'mm', 'Each V joint end cut back this far along the wall (print fit: 2x per joint)'),
    # ---- Fasteners at every screw location ----
    ('Screw_Length', '16', 'mm', 'Screw length under the head (McMaster 92137A420, M5 x 16)'),
    ('Thread_Diameter', '5', 'mm', 'M5: allthread and the coupling nuts\' thread (drawn plain)'),
    ('Coupling_Nut_AF', '8', 'mm', 'Coupling nut across flats'),
    ('Coupling_Nut_Length', '15', 'mm', 'Coupling nut length'),
    ('Pocket_Clearance', '0.2', 'mm', 'Hex pocket oversize on each flat'),
    ('Far_Nut_Recess', '3', 'mm', 'The rear (+Z) coupling nut stops this far short of the rear plate'),
    ('Allthread_Near_Gap', '0', 'mm', 'Seated (front) nut: allthread to screw tip (0: run in until it bottoms on the screw)'),
    ('Allthread_Far_Gap', '1.3', 'mm', 'Recessed (rear) nut: allthread end short of the screw tip'),
    ('Hook_Max_Spacing', '125', 'mm', 'Largest spacing between the base plate hooks'),
    # ---- Hooks ----
    # Hooks spaced along the bottom edge, between screws. The package script for a 2-3S pack
    # carries the small hook (config enclosure.small_hook) in these values.
    ('Hook_Neck_Width', '28', 'mm', 'L-hook neck width'),
    ('Hook_Nose', '10', 'mm', 'L-hook nose length: how far the nose latches under the base plate'),
    ('Hook_Drop_Extra', '10', 'mm', 'Hook nose height below the base plate underside (nose strength)'),
    ('Hook_Overlap', '2', 'mm', 'Hook neck overlap into the side plate'),
    ('Hook_Slot_Length', '40', 'mm', 'Base plate hook slot length'),
    ('Hook_Slot_Offset', '15', 'mm', 'Base slot extent on the +X side of the hook center (battery unslid)'),
    ('Hook_Slot_Clearance', '0.25', 'mm', 'Gap between the hook neck and the front (-X) end of its base slot when latched'),
    # ---- Fillets ----
    ('Fillet_Large', '8', 'mm', 'Outside corners of the base plate'),
    ('Fillet_Small', '2', 'mm', 'Outside corners of the hooks'),
    # ---- Derived (edit the expressions if you want different rules) ----
    ('Pocket_AF', 'Coupling_Nut_AF + 2 * Pocket_Clearance', 'mm', 'Hex pocket across flats'),
    ('Wall_Thickness', 'Pocket_AF + 2 * Wall_Web', 'mm', 'Printed ABS wall thickness: the hex pocket + Wall_Web each side'),
    ('Bolt_Edge_Offset', 'Side_Plate_Overhang + Wall_Thickness / 2', 'mm',
     'Screw center to plate edge: the screws sit on the wall ring centerline'),
    ('Slot_Width', 'Polycarbonate_Thickness + Slot_Clearance', 'mm', 'Base plate hook slot width'),
    ('Hook_Drop', 'Alu_Thickness + Hook_Drop_Extra', 'mm', 'Hook drop below the plate bottom edge'),
    ('Strip_Bend_Allowance', '1.5707963 * (Strip_Bend_Radius + Strip_K_Factor * Strip_Thickness)', 'mm',
     'Flat strip length used by one 90 degree bend (sets the flat blank lengths)'),
    ('Foam_Gap', 'Foam_Thickness - Foam_Compression', 'mm', 'Room left for the foam on every side (installed thickness)'),
    ('Core_Depth', 'Cell_Height + 2 * Holder_Recess', 'mm', 'Cells plus holders, holder face to holder face'),
    ('Cavity_Depth', 'Core_Depth + 2 * Foam_Gap', 'mm', 'Inside distance between side plates'),
    ('Allthread_Length', 'Cavity_Depth - 2 * (Screw_Length - Polycarbonate_Thickness) - Allthread_Near_Gap - Allthread_Far_Gap', 'mm',
     'Allthread between the two screws\' tips, less the gap at each end'),
    ('Cell_Core_Width', 'Columns * Cell_Pitch', 'mm', 'Cell block width'),
    ('Cell_Core_Height', 'Rows * Cell_Pitch', 'mm', 'Cell block height'),
    ('Cavity_Width', 'Cell_Core_Width + Extra_Length + 2 * Foam_Gap', 'mm', 'Inside cavity width'),
    ('Cavity_Height', 'Cell_Core_Height + Extra_Height + 2 * Foam_Gap', 'mm', 'Inside cavity height'),
    ('Plate_Width', 'Cavity_Width + 2 * Wall_Thickness + 2 * Side_Plate_Overhang', 'mm', 'Side plate width'),
    ('Plate_Height', 'Cavity_Height + 2 * Wall_Thickness + 2 * Side_Plate_Overhang', 'mm', 'Side plate height'),
    ('Base_Plate_X_Length', 'Plate_Width + Base_Front_Extension + Base_Rear_Extension', 'mm', 'Base plate length (X)'),
    ('Base_Plate_Z_Width', 'Cavity_Depth + 2 * Polycarbonate_Thickness + 2 * Side_Extension', 'mm', 'Base plate width (Z)'),
    ('Battery_Latch_Slide', 'Hook_Slot_Length - Hook_Slot_Offset - Hook_Neck_Width / 2 - Hook_Slot_Clearance', 'mm',
     'How far the battery is slid in -X to latch the hooks'),
]


# ----------------------------------------------------------------------------------
# Expression helpers. Expressions are strings in terms of the user parameters. They are
# handed to Fusion as-is (so dimensions stay driven by parameters) and evaluated here
# (to place the initial geometry). "0" is special-cased so we never emit a unitless 0
# next to a length.
# ----------------------------------------------------------------------------------
def neg(a):
    return '0' if a == '0' else '-(%s)' % a

def half(a):
    return '0' if a == '0' else '(%s)/2' % a

def add(a, b):
    if a == '0':
        return b
    if b == '0':
        return a
    return '(%s) + (%s)' % (a, b)

def sub(a, b):
    if b == '0':
        return a
    if a == '0':
        return neg(b)
    return '(%s) - (%s)' % (a, b)

def ev(expr):
    """Evaluate an expression to millimeters (or a plain number). Lengths written 'N mm' (from
    mm()) evaluate as N."""
    return float(eval(re.sub(r'([0-9.])\s*mm\b', r'\1', expr), {'__builtins__': {}}, VALS))

def vi(expr):
    return adsk.core.ValueInput.createByString(expr)

def pt(xe, ye):
    return adsk.core.Point3D.create(ev(xe) * MM, ev(ye) * MM, 0)

def last_error():
    return traceback.format_exc().strip().splitlines()[-1]


# ----------------------------------------------------------------------------------
# Parameters
# ----------------------------------------------------------------------------------
def setup_parameters(design):
    ups = design.userParameters
    for name, expr, units, comment in PARAMS:
        numeric = bool(re.match(r'^[0-9.]+$', expr))
        existing = ups.itemByName(name)
        if existing is None:
            val = vi('%s %s' % (expr, units)) if (units and numeric) else vi(expr)
            ups.add(name, val, units, comment)
        elif not numeric:
            # Derived parameter: always refresh so formula changes in this script take effect
            if existing.expression != expr:
                existing.expression = expr
        elif CONFIG_NAME or not re.match(r'^[0-9.]+( [a-z]+)?$', existing.expression):
            # Package script (builds exactly its pack), or a plain-value parameter that an older
            # version of this script made a formula
            want = '%s %s' % (expr, units) if units else expr
            if existing.expression != want:
                existing.expression = want
        # otherwise: keep the value you edited
    for name, expr, units, comment in PARAMS:
        p = ups.itemByName(name)
        VALS[name] = p.value * 10.0 if units == 'mm' else p.value


def runtime_param(design, name, expr, units, comment):
    """A parameter the script derives from the layout when it runs (tab spacing and length).
    Rewritten on every run; edit the rule parameters above instead and re-run."""
    ups = design.userParameters
    p = ups.itemByName(name)
    if p is None:
        p = ups.add(name, vi(expr), units, comment + ' (set by the script on each run)')
    elif p.expression != expr:
        p.expression = expr
    VALS[name] = p.value * 10.0 if units == 'mm' else p.value


# ----------------------------------------------------------------------------------
# Layout rules. Plain Python (no Fusion calls), kept identical to pack.geometry's wall_layout,
# edge_plan and hook_positions (docs/WALL_SECTIONING.md); tests/test_fusion_parity.py runs both
# and compares.
# ----------------------------------------------------------------------------------
# The printed wall ring's centerline, walked counter-clockwise in model XY, edge by edge:
# 0 = bottom (+X), 1 = front end (+Y), 2 = top (-X), 3 = rear end (-Y)
EDGE_DIRS = ((1, 0), (0, 1), (-1, 0), (0, -1))
EDGE_STARTS = ((-1, -1), (1, -1), (1, 1), (-1, 1))     # signs of each edge's start corner


def mm(v):
    """A length in mm as an expression ('0' for zero, see the expression helpers)."""
    return '0' if abs(v) < 1e-9 else '%.6f mm' % v


def screw_rules(V):
    """(corner setback, end margin) the layout uses (same as pack.geometry.screw_rules): the
    configured values, raised if needed so a corner screw sits at least Wall_Thickness from the
    corner and every pocket keeps Wall_Web of material to a joint's 45 degree face."""
    reach = max(V['Bolt_Hole_Diameter'] / 2.0, V['Pocket_AF'] / 2.0 / math.cos(math.radians(15)))
    margin = max(V['Screw_End_Margin'], math.sqrt(2.0) * (reach + V['Wall_Web']) + V['Joint_End_Trim'])
    return max(V['Corner_Screw_Setback'], V['Wall_Thickness']), margin


def edge_plan(length, V):
    """(joints, screws, corner setback) along one wall-ring edge of the given centerline length.
    Corner legs are setback + margin long; what is left between them, if at least Min_Section, is
    split into the fewest equal sections that keep every piece within Max_Section (a piece reaches
    Wall_Thickness / 2 past its female joint), each with a screw Screw_End_Margin from both ends
    and more between, at most Max_Screw_Spacing apart. Otherwise the two corner pieces meet in the
    middle of the edge and their screws move in to stay a margin from that joint."""
    s, e = screw_rules(V)
    leg = s + e
    middle = length - 2 * leg
    if middle >= V['Min_Section'] - 1e-9:
        n = max(1, int(math.ceil(middle / (V['Max_Section'] - V['Wall_Thickness'] / 2.0) - 1e-9)))
        sec = middle / n
        joints = [leg + i * sec for i in range(n + 1)]
        screws = [s]
        k = max(1, int(math.ceil((sec - 2 * e) / V['Max_Screw_Spacing'] - 1e-9)))
        for j0 in joints[:-1]:
            screws += [j0 + e + i * (sec - 2 * e) / k for i in range(k + 1)]
        screws.append(length - s)
        return joints, screws, s
    setback = min(s, length / 2.0 - e)
    return [length / 2.0], [setback, length - setback], setback


def wall_layout(V):
    """The wall ring: (hx, hy, edges, ring). hx, hy = centerline half sizes; edges = [(length,
    joints, screws, setback)] for bottom, front end, top, rear end; ring = [(edge, joint)] in
    counter-clockwise order. A piece runs from one joint (its female V end) to the next (male)."""
    t = V['Wall_Thickness']
    hx = V['Cavity_Width'] / 2.0 + t / 2.0
    hy = V['Cavity_Height'] / 2.0 + t / 2.0
    edges = []
    for length in (2 * hx, 2 * hy, 2 * hx, 2 * hy):
        joints, screws, setback = edge_plan(length, V)
        edges.append((length, joints, screws, setback))
    ring = [(k, j) for k, e in enumerate(edges) for j in e[1]]
    return hx, hy, edges, ring


def hook_positions(V, edges, hx):
    """L-hook centers along X (same rule as pack.geometry.hook_positions): the fewest (at least 2)
    evenly spaced along the bottom edge that keep them Hook_Max_Spacing apart, not tied to the
    screw positions; one centered hook if two would crowd the base plate."""
    length = edges[0][0]
    n = max(2, int(math.ceil(length / V['Hook_Max_Spacing'] - 1e-9)))
    xs = [-length / 2.0 + (i + 0.5) * length / n for i in range(n)]
    return xs if hooks_fit(xs, V, straight_half(V)) else [0.0]


def ring_pieces(edges, ring):
    """Each wall piece as (is corner, outline, screws). Outline points are (edge, s, ds, dn[, dc]):
    the point s + ds x Wall_Thickness / 2 + dc x Joint_End_Trim along the edge from its start corner
    and dn x Wall_Thickness / 2 outward from the centerline; screws are (edge, s). Each V end is cut
    back Joint_End_Trim (dc = +1 at the female end, -1 at the male end) for the print fit. A straight section runs from a female V
    notch (its start joint) to a male V point (the next joint); a corner piece turns the corner
    between them through the ring's outer and inner corners. Same outlines as pack.geometry."""
    out = []
    for i, (ka, sa) in enumerate(ring):
        kb, sb = ring[(i + 1) % len(ring)]
        if ka == kb:
            pts = [(ka, sa, -1, 1, 1), (ka, sb, -1, 1, -1), (ka, sb, 0, 0, -1), (ka, sb, -1, -1, -1),
                   (ka, sa, -1, -1, 1), (ka, sa, 0, 0, 1)]
            screws = [(ka, x) for x in edges[ka][2] if sa < x < sb]
        else:
            la = edges[ka][0]
            pts = [(ka, sa, -1, 1, 1), (ka, la, 1, 1), (kb, sb, -1, 1, -1), (kb, sb, 0, 0, -1), (kb, sb, -1, -1, -1),
                   (ka, la, -1, -1), (ka, sa, -1, -1, 1), (ka, sa, 0, 0, 1)]
            screws = [(ka, x) for x in edges[ka][2] if x > sa] + [(kb, x) for x in edges[kb][2] if x < sb]
        out.append((ka != kb, pts, screws))
    return out


def pocket_pts(cx, cy, along_x):
    """Expressions for the hex pocket's corners around (cx, cy), counter-clockwise from the
    corner on +X (along_x) or +Y. Clocked so its flats lie parallel to the wall faces (same as
    pack.geometry.pocket_hex): two corners point along the wall."""
    r = '(Pocket_AF)/1.7320508'         # center to corner = across flats / sqrt 3
    r2 = '(Pocket_AF)/3.4641016'        # half of that
    f2 = half('Pocket_AF')
    def mv(c, sign, e):
        return c if sign == 0 else (add(c, e) if sign > 0 else sub(c, e))
    corners = [((1, r), (0, '0')), ((1, r2), (1, f2)), ((-1, r2), (1, f2)),
               ((-1, r), (0, '0')), ((-1, r2), (-1, f2)), ((1, r2), (-1, f2))]
    out = []
    for (sa, ea), (sb, eb) in corners:
        if along_x:
            out.append((mv(cx, sa, ea), mv(cy, sb, eb)))
        else:                                             # a quarter turn: (a, b) -> (-b, a)
            out.append((mv(cx, -sb, eb), mv(cy, sa, ea)))
    return out


RING_HX = '(Cavity_Width)/2 + (Wall_Thickness)/2'     # wall ring centerline half sizes
RING_HY = '(Cavity_Height)/2 + (Wall_Thickness)/2'


def ring_xy(k, s, ds=0, dn=0, dc=0):
    """Expressions (x, y) for the ring point (edge k, s, ds, dn) of ring_pieces: the edge's start
    corner, plus s (+ ds x Wall_Thickness / 2) along the edge, plus dn x Wall_Thickness / 2 outward."""
    sxs, sys_ = EDGE_STARTS[k]
    x = RING_HX if sxs > 0 else neg(RING_HX)
    y = RING_HY if sys_ > 0 else neg(RING_HY)
    along = mm(s)
    if ds:
        along = add(along, half('Wall_Thickness')) if ds > 0 else sub(along, half('Wall_Thickness'))
    if dc:
        along = add(along, 'Joint_End_Trim') if dc > 0 else sub(along, 'Joint_End_Trim')
    out = half('Wall_Thickness') if dn > 0 else (neg(half('Wall_Thickness')) if dn < 0 else '0')
    dx, dy = EDGE_DIRS[k]
    ox, oy = dy, -dx                                  # outward = right of the walking direction
    for dk, e in ((dx, along), (ox, out)):
        x = add(x, e) if dk > 0 else (sub(x, e) if dk < 0 else x)
    for dk, e in ((dy, along), (oy, out)):
        y = add(y, e) if dk > 0 else (sub(y, e) if dk < 0 else y)
    return x, y


def strip_groups(columns):
    """Nickel strips: (end, first column, end column), end +1 = rear (+Z), -1 = front (-Z). Same
    rule as pack.geometry.strip_groups: +Z joins columns (0, 1), (2, 3), ...; -Z joins (1, 2), ...;
    the pack terminals get single-column strips."""
    out = []
    for end, start in ((1, 0), (-1, 1)):
        if start:
            out.append((end, 0, 1))
        i = start
        while i < columns:
            out.append((end, i, min(i + 2, columns)))
            i += 2
    return out


def straight_half(V):
    """Half the straight part of the side plate's bottom edge, where the hooks hang."""
    return V['Plate_Width'] / 2.0 - V['Plate_Corner_Radius']


def hooks_fit(xs, V, straight):
    """Neighbouring base-plate hook slots keep one plate thickness of aluminum between them, and
    every hook neck stays on the straight part of the side plate's bottom edge (straight = half
    its length)."""
    gap = min(b - a for a, b in zip(xs, xs[1:])) - V['Hook_Slot_Length']
    return gap >= V['Alu_Thickness'] and max(abs(x) for x in xs) + V['Hook_Neck_Width'] / 2.0 + V['Min_CNC_Router_Diameter'] <= straight


# ----------------------------------------------------------------------------------
# Sketch helpers: draw geometry and fully dimension it from the parameters.
# ----------------------------------------------------------------------------------
def new_sketch(comp, plane, name):
    sk = comp.sketches.add(plane)
    sk.name = name
    SKETCHES.append(sk)
    return sk

def dim_lin(sk, a, b, horizontal, expr):
    """Add a distance dimension bound to expr. If Fusion rejects it, retry with the endpoints
    swapped and with the dimension text on the other side; any rejected dimension is deleted."""
    ori = (adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation if horizontal
           else adsk.fusion.DimensionOrientations.VerticalDimensionOrientation)
    err = ''
    for (p1, p2, side) in ((a, b, -1), (b, a, -1), (a, b, 1), (b, a, 1)):
        d = None
        try:
            g1, g2 = p1.geometry, p2.geometry
            if horizontal:
                tp = adsk.core.Point3D.create((g1.x + g2.x) / 2.0, (min(g1.y, g2.y) if side < 0 else max(g1.y, g2.y)) + side * 0.6, 0)
            else:
                tp = adsk.core.Point3D.create((min(g1.x, g2.x) if side < 0 else max(g1.x, g2.x)) + side * 0.6, (g1.y + g2.y) / 2.0, 0)
            d = sk.sketchDimensions.addDistanceDimension(p1, p2, ori, tp)
            d.parameter.expression = expr
            return True
        except:
            err = last_error()
            if d is not None:
                try:
                    d.deleteMe()
                except:
                    pass
    ISSUES.append('%s: dimension "%s" failed: %s' % (sk.name, expr, err))
    return False

def place(sk, point, xe, ye):
    """Locate a sketch point relative to the origin using parameter-driven dimensions."""
    org = sk.originPoint
    for is_x, e in ((True, xe), (False, ye)):
        v = ev(e)
        if abs(v) < 1e-6:
            try:
                if is_x:
                    sk.geometricConstraints.addVerticalPoints(org, point)
                else:
                    sk.geometricConstraints.addHorizontalPoints(org, point)
            except:
                ISSUES.append('%s: alignment constraint failed: %s' % (sk.name, last_error()))
        else:
            dim_lin(sk, org, point, is_x, e if v > 0 else neg(e))

def rect(sk, x0, x1, y0, y1, w=None, h=None):
    """Draw a rectangle and fully define it: width, height, and corner position."""
    lines = sk.sketchCurves.sketchLines.addTwoPointRectangle(pt(x0, y0), pt(x1, y1))
    # The API does not always add horizontal/vertical constraints; add them explicitly
    # (skipped quietly if a line already has one).
    for i in range(lines.count):
        ln = lines.item(i)
        a, b = ln.startSketchPoint.geometry, ln.endSketchPoint.geometry
        try:
            if abs(a.y - b.y) < 1e-9:
                sk.geometricConstraints.addHorizontal(ln)
            else:
                sk.geometricConstraints.addVertical(ln)
        except:
            pass
    pts = []
    for i in range(lines.count):
        ln = lines.item(i)
        pts.append(ln.startSketchPoint)
        pts.append(ln.endSketchPoint)
    bl = min(pts, key=lambda p: p.geometry.x + p.geometry.y)
    br = max(pts, key=lambda p: p.geometry.x - p.geometry.y)
    tl = min(pts, key=lambda p: p.geometry.x - p.geometry.y)
    dim_lin(sk, bl, br, True, w or sub(x1, x0))
    dim_lin(sk, bl, tl, False, h or sub(y1, y0))
    place(sk, bl, x0, y0)
    return lines

def rect_edges(lines):
    hs, vs = [], []
    for i in range(lines.count):
        ln = lines.item(i)
        a, b = ln.startSketchPoint.geometry, ln.endSketchPoint.geometry
        if abs(a.y - b.y) < 1e-9:
            hs.append(ln)
        else:
            vs.append(ln)
    return {
        'bottom': min(hs, key=lambda l: l.startSketchPoint.geometry.y),
        'top': max(hs, key=lambda l: l.startSketchPoint.geometry.y),
        'left': min(vs, key=lambda l: l.startSketchPoint.geometry.x),
        'right': max(vs, key=lambda l: l.startSketchPoint.geometry.x),
    }

def circle(sk, cx, cy, dia, locate=True):
    r = ev(dia) * MM / 2.0
    c = sk.sketchCurves.sketchCircles.addByCenterRadius(pt(cx, cy), r)
    try:
        g = c.centerSketchPoint.geometry
        tp = adsk.core.Point3D.create(g.x + r * 1.6, g.y + r * 1.6, 0)
        d = sk.sketchDimensions.addDiameterDimension(c, tp)
        d.parameter.expression = dia
    except:
        ISSUES.append('%s: diameter dimension "%s" failed: %s' % (sk.name, dia, last_error()))
    if locate:
        place(sk, c.centerSketchPoint, cx, cy)
    return c

def slot(sk, x0, x1, y0, y1, along_x, w, h):
    """Rectangular slot with 4 dogbone circles. Each circle is centered on a long edge and
    tangent to the short end of the slot, so the end stays flat across the full slot width."""
    lines = rect(sk, x0, x1, y0, y1, w, h)
    e = rect_edges(lines)
    dia = 'Min_CNC_Router_Diameter'
    r = half(dia)
    gc = sk.geometricConstraints
    if along_x:     # long edges are top/bottom, short ends are left/right
        ends = (('left', add(x0, r)), ('right', sub(x1, r)))
        sides = (('bottom', y0), ('top', y1))
        combos = [(end, ex, side, sy) for end, ex in ends for side, sy in sides]
    else:           # long edges are left/right, short ends are bottom/top
        ends = (('bottom', add(y0, r)), ('top', sub(y1, r)))
        sides = (('left', x0), ('right', x1))
        combos = [(end, ey, side, sx) for end, ey in ends for side, sx in sides]
    for end, a, side, b in combos:
        cx, cy = (a, b) if along_x else (b, a)
        c = circle(sk, cx, cy, dia, locate=False)
        try:
            gc.addCoincident(c.centerSketchPoint, e[side])   # center sits on the long edge
            gc.addTangent(e[end], c)                         # tangent to the short end
        except:
            ISSUES.append('%s: dogbone constraint failed: %s' % (sk.name, last_error()))

def sketch_axes(sk):
    """How model X / Y / Z map onto this sketch: {axis: (sketch axis 0 or 1, sign)}; axes normal
    to the sketch plane are left out. Uses differences, so occurrence offsets cancel."""
    o = sk.modelToSketchSpace(adsk.core.Point3D.create(0, 0, 0))
    out = {}
    for name, v in (('x', (1, 0, 0)), ('y', (0, 1, 0)), ('z', (0, 0, 1))):
        p = sk.modelToSketchSpace(adsk.core.Point3D.create(*v))
        dx, dy = p.x - o.x, p.y - o.y
        if abs(dx) > 0.5:
            out[name] = (0, 1 if dx > 0 else -1)
        elif abs(dy) > 0.5:
            out[name] = (1, 1 if dy > 0 else -1)
    return out


def model_circle(sk, axes, coords, dia):
    """A dimensioned circle centered at model coordinates {axis: expression} (the two in-plane
    axes of this sketch)."""
    se = ['0', '0']
    for ax, e in coords.items():
        i, s = axes[ax]
        se[i] = e if s > 0 else neg(e)
    return circle(sk, se[0], se[1], dia)


def all_profiles(sk):
    col = adsk.core.ObjectCollection.create()
    for p in sk.profiles:
        col.add(p)
    return col

def offset_plane(comp, base_plane, expr):
    pin = comp.constructionPlanes.createInput()
    pin.setByOffset(base_plane, vi(expr))
    return comp.constructionPlanes.add(pin)


# ----------------------------------------------------------------------------------
def find_edges(body, axis, targets, tol=0.02):
    """Straight edges of body parallel to `axis` ('z' or 'y') whose position in the other
    two coordinates matches one of `targets` (a, b) in mm. Axis z: (x, y); axis y: (x, z)."""
    found = adsk.core.ObjectCollection.create()
    for e in body.edges:
        try:
            if e.geometry.curveType != adsk.core.Curve3DTypes.Line3DCurveType:
                continue
            a, b = e.startVertex.geometry, e.endVertex.geometry
            if axis == 'z':
                if abs(a.x - b.x) > 1e-6 or abs(a.y - b.y) > 1e-6:
                    continue
                pos = (a.x / MM, a.y / MM)
            else:
                if abs(a.x - b.x) > 1e-6 or abs(a.z - b.z) > 1e-6:
                    continue
                pos = (a.x / MM, a.z / MM)
            if any(abs(pos[0] - t[0]) < tol / MM and abs(pos[1] - t[1]) < tol / MM for t in targets):
                found.add(e)
        except:
            pass
    return found

def chamfer_edges(comp, edges, distance_param, what):
    """Equal-distance chamfer on edges, bound to a parameter."""
    if edges.count == 0:
        ISSUES.append('Chamfer (%s): no matching edges found' % what)
        return
    try:
        cf = comp.features.chamferFeatures
        try:
            inp = cf.createInput2()
            inp.chamferEdgeSets.addEqualDistanceChamferEdgeSet(edges, vi(distance_param), False)
        except:     # older Fusion API
            inp = cf.createInput(edges, False)
            inp.setToEqualDistance(vi(distance_param))
        cf.add(inp)
    except:
        ISSUES.append('Chamfer (%s, %s) failed: %s' % (what, distance_param, last_error()))


def fillet_edges(comp, edges, radius_param, what):
    if edges.count == 0:
        ISSUES.append('Fillet (%s): no matching edges found' % what)
        return
    try:
        fi = comp.features.filletFeatures
        inp = fi.createInput()
        inp.addConstantRadiusEdgeSet(edges, vi(radius_param), True)
        fi.add(inp)
    except:
        ISSUES.append('Fillet (%s, %s) failed: %s' % (what, radius_param, last_error()))


# ----------------------------------------------------------------------------------
# Sheet metal helpers (nickel strips)
# ----------------------------------------------------------------------------------
class SheetMetalUnavailable(Exception):
    """This Fusion has no usable sheet metal API (rules, base flange or fold): the strips are
    built as plain plates instead."""


def poly(sk, pts):
    """Closed polygon through (x, y) expression pairs, every vertex dimensioned to the origin
    (no horizontal / vertical constraints, so nothing is over-constrained)."""
    lines = sk.sketchCurves.sketchLines
    first = lines.addByTwoPoints(pt(*pts[0]), pt(*pts[1]))
    verts = [first.startSketchPoint, first.endSketchPoint]
    prev = first
    for p in pts[2:]:
        prev = lines.addByTwoPoints(prev.endSketchPoint, pt(*p))
        verts.append(prev.endSketchPoint)
    lines.addByTwoPoints(prev.endSketchPoint, first.startSketchPoint)
    for sp, (xe, ye) in zip(verts, pts):
        place(sk, sp, xe, ye)


def sketch_line(sk, p0, p1):
    """A dimensioned line between two (x, y) expression pairs."""
    ln = sk.sketchCurves.sketchLines.addByTwoPoints(pt(*p0), pt(*p1))
    place(sk, ln.startSketchPoint, *p0)
    place(sk, ln.endSketchPoint, *p1)
    return ln


def obround(sk, cx, cy, length, width):
    """A slot along sketch Y with round ends (length end to end), fully dimensioned: the bottom
    end's center from the origin, the top center straight above it, and both end radii."""
    r, d = half(width), sub(length, width)
    y0, y1 = sub(cy, half(d)), add(cy, half(d))
    arcs = sk.sketchCurves.sketchArcs
    a0 = arcs.addByCenterStartSweep(pt(cx, y0), pt(sub(cx, r), y0), math.pi)   # bottom end, through its bottom
    a1 = arcs.addByCenterStartSweep(pt(cx, y1), pt(add(cx, r), y1), math.pi)   # top end, through its top
    lines = sk.sketchCurves.sketchLines
    sides = [lines.addByTwoPoints(a0.endSketchPoint, a1.startSketchPoint),
             lines.addByTwoPoints(a1.endSketchPoint, a0.startSketchPoint)]
    gc = sk.geometricConstraints
    for ln in sides:
        for a in (a0, a1):
            try:
                gc.addTangent(a, ln)
            except:
                ISSUES.append('%s: slot tangent constraint failed: %s' % (sk.name, last_error()))
    place(sk, a0.centerSketchPoint, cx, y0)
    try:
        gc.addVerticalPoints(a0.centerSketchPoint, a1.centerSketchPoint)
    except:
        ISSUES.append('%s: slot alignment failed: %s' % (sk.name, last_error()))
    dim_lin(sk, a0.centerSketchPoint, a1.centerSketchPoint, False, d)
    for a in (a0, a1):
        try:
            g = a.centerSketchPoint.geometry
            tp = adsk.core.Point3D.create(g.x + ev(width) * MM, g.y, 0)
            sk.sketchDimensions.addRadialDimension(a, tp).parameter.expression = r
        except:
            ISSUES.append('%s: slot radius "%s" failed: %s' % (sk.name, r, last_error()))


def bbox_mm(body):
    b = body.boundingBox
    return ((b.minPoint.x / MM, b.minPoint.y / MM, b.minPoint.z / MM),
            (b.maxPoint.x / MM, b.maxPoint.y / MM, b.maxPoint.z / MM))


def strip_rule(design, comp):
    """The design's sheet metal rule for the nickel strips: a copy of a metric library rule, set
    to the strip's thickness, bend radius and K factor. Raises SheetMetalUnavailable."""
    name = 'Nickel strip (mm)'
    try:
        rules = design.designSheetMetalRules
    except:
        raise SheetMetalUnavailable('no designSheetMetalRules: %s' % last_error())
    rule = None
    try:
        rule = rules.itemByName(name)
    except:       # a new document has no sheet metal data until a rule is added
        rule = None
    if rule is None:
        errors = []
        try:
            lib = design.librarySheetMetalRules
            src = None
            for i in range(lib.count):
                if '(mm)' in lib.item(i).name:
                    src = lib.item(i)
                    break
            if src is None:
                src = lib.item(0)
        except:
            raise SheetMetalUnavailable('no library sheet metal rules: %s' % last_error())
        try:
            rule = rules.addByCopy(src, name)
        except:
            errors.append('copy: ' + last_error())
        if rule is None:
            # A design with no sheet metal yet rejects the copy (smDataRoot). Making a library rule
            # active on the component sets the sheet metal data up, as the UI does; then copy again,
            # or use the design's own copy of that library rule.
            try:
                comp.activeSheetMetalRule = src
            except:
                errors.append('activate library rule: ' + last_error())
            try:
                rule = rules.addByCopy(src, name)
            except:
                errors.append('copy after activating: ' + last_error())
                try:
                    rule = comp.activeSheetMetalRule     # setting its values below fails if it is read-only
                except:
                    errors.append('read active rule: ' + last_error())
                    rule = None
        if rule is None:
            raise SheetMetalUnavailable('could not make the sheet metal rule: %s' % '; '.join(errors))
    try:
        rule.thickness.expression = '%.4f mm' % VALS['Strip_Thickness']
        rule.bendRadius.expression = '%.4f mm' % VALS['Strip_Bend_Radius']
        rule.kFactor = VALS['Strip_K_Factor']
    except:
        raise SheetMetalUnavailable('could not set the sheet metal rule values: %s' % last_error())
    return rule


def planar_faces(body, axis):
    """Planar faces of body whose normal lies along axis (0 = X, 1 = Y, 2 = Z), with their centroid
    in mm: [(face, (x, y, z), area)]."""
    out = []
    for f in body.faces:
        try:
            g = f.geometry
            if g.surfaceType != adsk.core.SurfaceTypes.PlaneSurfaceType:
                continue
            n = (g.normal.x, g.normal.y, g.normal.z)
            if abs(abs(n[axis]) - 1.0) > 1e-6:
                continue
            c = f.centroid
            out.append((f, (c.x / MM, c.y / MM, c.z / MM), f.area))
        except:
            pass
    return out


def find_hardware_file(part):
    """fusion/ebike_enclosure/hardware/<part>*.step or .stp, or None."""
    folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'hardware')
    if not os.path.isdir(folder):
        return None
    for fn in sorted(os.listdir(folder)):
        base, ext = os.path.splitext(fn)
        if ext.lower() in ('.step', '.stp') and base.upper().startswith(part.upper()):
            return os.path.join(folder, fn)
    return None


def screw_frame(body):
    """Work out an imported screw's axis from its geometry (STEP files come in any orientation).
    `body` is the native body, so everything is in its own component's space (cm).
    Returns (under_head_point, unit vector head->tip, length under the head in mm)."""
    bb = body.boundingBox
    lo = [bb.minPoint.x, bb.minPoint.y, bb.minPoint.z]
    hi = [bb.maxPoint.x, bb.maxPoint.y, bb.maxPoint.z]
    ext = [hi[i] - lo[i] for i in range(3)]
    k = ext.index(max(ext))                       # the screw axis is its longest extent
    others = [i for i in range(3) if i != k]
    ctr = [(lo[i] + hi[i]) / 2.0 for i in range(3)]
    probe_r = 0.4 * min(ext[others[0]], ext[others[1]])   # outside the shank, inside the head/flange
    outside = adsk.fusion.PointContainment.PointOutsidePointContainment

    def solid_at(axial):
        for o in others:
            for sgn in (1, -1):
                p = list(ctr)
                p[k] = axial
                p[o] += sgn * probe_r
                if body.pointContainment(adsk.core.Point3D.create(p[0], p[1], p[2])) != outside:
                    return True
        return False

    n = 400
    step = ext[k] / n
    samples = [solid_at(lo[k] + (i + 0.5) * step) for i in range(n)]
    head_lo = any(samples[:n // 4])
    head_hi = any(samples[-(n // 4):])
    if head_lo == head_hi:
        raise RuntimeError('could not tell the screw head from its tip')
    if head_lo:       # head at the low end: under-head is just past the last solid sample
        last = max(i for i in range(n) if samples[i])
        under = lo[k] + (last + 1) * step
        axis_sign = 1.0
        shank = hi[k] - under
    else:
        first = min(i for i in range(n) if samples[i])
        under = lo[k] + first * step
        axis_sign = -1.0
        shank = under - lo[k]
    p = list(ctr)
    p[k] = under
    a = [0.0, 0.0, 0.0]
    a[k] = axis_sign
    return (adsk.core.Point3D.create(p[0], p[1], p[2]),
            adsk.core.Vector3D.create(a[0], a[1], a[2]), shank / MM)


def place_screws(design, target_comp, step_path, targets):
    """Import the screw STEP once and put an occurrence of it at each target.
    targets: [(x_mm, y_mm, z_mm, inward_z_sign)], the point where the underside of the head sits
    and the direction the shank points (+1 / -1 along Z).
    Returns (component, shank length in mm, number placed). Each stage raises with its own name."""
    stage = 'import'
    try:
        # Import into a component of its own inside target_comp. That occurrence stays hidden at
        # the origin; every bolt point gets a copy of it, so nothing is deleted.
        src = target_comp.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        screw_comp = src.component
        screw_comp.name = 'McMaster_%s' % SCREW_PART
        im = adsk.core.Application.get().importManager
        im.importToTarget(im.createSTEPImportOptions(step_path), screw_comp)

        stage = 'unground'   # imported occurrences can come in grounded, which blocks moving them
        for o in [src] + list(screw_comp.allOccurrences):
            try:
                o.isGroundToParent = False
            except:
                pass

        stage = 'find body'
        best = None   # (volume, body, transform from the body's component into screw_comp)
        for b in screw_comp.bRepBodies:
            if best is None or b.volume > best[0]:
                best = (b.volume, b, None)
        for o in screw_comp.allOccurrences:   # STEP assemblies come in as nested occurrences
            for b in o.component.bRepBodies:
                if best is None or b.volume > best[0]:
                    best = (b.volume, b, o.transform2)
        if best is None:
            raise RuntimeError('the STEP file has no solid bodies')
        _, body, to_screw = best
        # The screw keeps the appearance from its STEP file: no material or appearance is set on it.

        stage = 'find screw axis'
        under_pt, axis, shank_mm = screw_frame(body)
        if to_screw is not None:
            under_pt.transformBy(to_screw)
            axis.transformBy(to_screw)

        stage = 'placement matrices'
        # Any vector not parallel to the axis gives the from-frame's X
        ref = adsk.core.Vector3D.create(1, 0, 0) if abs(axis.x) < 0.9 else adsk.core.Vector3D.create(0, 1, 0)
        xf = axis.crossProduct(ref)
        xf.normalize()
        yf = axis.crossProduct(xf)
        mats = []
        for (x, y, z, inward) in targets:
            zt = adsk.core.Vector3D.create(0, 0, inward)
            xt = adsk.core.Vector3D.create(1, 0, 0)
            yt = zt.crossProduct(xt)
            m = adsk.core.Matrix3D.create()
            m.setToAlignCoordinateSystems(under_pt, xf, yf, axis,
                                          adsk.core.Point3D.create(x * MM, y * MM, z * MM), xt, yt, zt)
            mats.append(m)

        # A copy at every bolt point. Fusion will not move the nested imported occurrence itself,
        # so that one stays hidden at the origin (it holds the screw's geometry for the copies).
        stage = 'copies'
        for m in mats:
            target_comp.occurrences.addExistingComponent(screw_comp, m)
        placed = len(mats)
        src.isLightBulbOn = False
        return screw_comp, shank_mm, placed
    except Exception:
        raise RuntimeError('stage "%s": %s' % (stage, last_error()))


def apply_looks(app, design, groups):
    """Assign physical materials and appearances by searching Fusion's libraries for keywords.
    Returns one summary line per group so you can see what was (or was not) found."""
    mats, apps = [], []
    try:
        for i in range(app.materialLibraries.count):
            lib = app.materialLibraries.item(i)
            for coll, out in ((lib.materials, mats), (lib.appearances, apps)):
                try:
                    for j in range(coll.count):
                        out.append((coll.item(j).name, coll.item(j)))
                except:
                    pass
    except:
        pass

    def find(items, kwsets, exclude=()):
        """First keyword set that matches wins. Keywords match whole words (so 'abs' does not hit
        'Formlabs'), and among several matches the shortest name is used (the plain variant)."""
        for kws in kwsets:
            hits = [(n, o) for n, o in items
                    if all(re.search(r'(?<![a-z0-9])' + re.escape(k) + r'(?![a-z0-9])', n.lower()) for k in kws)
                    and not any(x in n.lower() for x in exclude)]
            if hits:
                return min(hits, key=lambda h: len(h[0]))[1]
        return None

    def tinted(lib_app, name, rgb):
        """A copy of lib_app named name, recoloured to rgb. Returns (appearance, status): status
        says whether the colour took ('tinted', 'kept', or why not)."""
        ap = design.appearances.itemByName(name)
        if ap is None:
            ap = design.appearances.addByCopy(lib_app, name)
        if not rgb:
            return ap, 'kept'
        color = adsk.core.Color.create(rgb[0], rgb[1], rgb[2], 255)
        props = [p for p in ap.appearanceProperties if isinstance(p, adsk.core.ColorProperty)]
        # The main colour first ('Color' in most appearances), then any other plain colour property
        props.sort(key=lambda p: 0 if p.name.lower() in ('color', 'generic color', 'base color') else 1)
        done = 0
        for p in props:
            try:
                if getattr(p, 'connectedTexture', None) is not None:
                    continue          # an image drives this colour; setting the value would not show
                p.value = color
                done += 1
                if p.name.lower() in ('color', 'generic color', 'base color'):
                    break
            except:
                pass
        if not done:
            return ap, 'tint not applied (no plain colour property)'
        v = props[0].value if props else None
        ok = v is not None and (v.red, v.green, v.blue) == tuple(rgb)
        return ap, 'tinted' if ok else 'tint may not have taken'

    # Appearance names containing any of these are skipped (colored / see-through finishes), so a
    # tint that does not take leaves a neutral part rather than a red or white one
    COLORED = ('blue', 'red', 'green', 'gold', 'yellow', 'orange', 'purple', 'pink', 'black', 'white',
               'anodized', 'bronze', 'brown', 'beige', 'cyan', 'magenta')
    SEE_THROUGH = ('clear', 'translucent', 'transparent', 'glass', 'smoke', 'tint')
    NEUTRAL = COLORED + SEE_THROUGH

    #  key, label, material keywords, appearance keywords, tint color, appearance name, excluded words
    spec = [
        ('PC', 'Polycarbonate', [('polycarbonate',)],
         [('plastic', 'matte'), ('plastic', 'opaque'), ('plastic',)], (58, 60, 64),
         'Dark_Grey_Polycarbonate', NEUTRAL),
        ('BASE', 'Base plate', [('aluminum', '6061'), ('aluminum',)],
         [('aluminum', 'brushed'), ('aluminum', 'satin'), ('aluminum',)], None, 'Brushed_Aluminum', COLORED),
        ('WALL', 'Printed walls (ABS)', [('abs',)],
         [('abs',), ('plastic', 'matte'), ('plastic',)], (91, 96, 103), 'Printed_ABS_Wall', NEUTRAL),
        ('ZINC', 'Coupling nuts and allthread', [('steel',)],
         [('zinc',), ('steel', 'satin'), ('steel',)], (185, 189, 194), 'Zinc_Plated_Steel', COLORED),
        ('TRAY', 'BMS tray (ABS)', [('abs',)],
         [('abs',), ('plastic', 'matte'), ('plastic',)], (35, 35, 38), 'ABS_Tray', NEUTRAL),
        ('NICKEL', 'Nickel strips', [('nickel',)],
         [('nickel',), ('steel', 'polished'), ('chrome',)], (200, 199, 190), 'Nickel_Strip', COLORED),
        ('HOLDER', 'Cell holders', [('abs',)],
         [('plastic', 'matte'), ('abs',), ('plastic',)], (20, 21, 23), 'Cell_Holder_Black', NEUTRAL),
        ('FOAM', 'Foam', [],
         [('foam',), ('rubber', 'matte'), ('fabric',), ('rubber',)], (40, 40, 44), 'Neoprene_Foam', NEUTRAL),
        ('CELL', 'Cells', [],
         [('plastic', 'glossy'), ('paint', 'glossy'), ('plastic',)], (25, 95, 200), 'Cell_Wrap_Blue', NEUTRAL),
        ('CAN', 'Cell cans', [('steel',)],
         [('steel', 'polished'), ('nickel',), ('chrome',)], (201, 204, 208), 'Cell_Can_Steel', COLORED),
        ('INSULATOR', 'Insulator rings', [],
         [('paper',), ('fabric',), ('plastic', 'matte')], (61, 122, 70), 'Fish_Paper_Green', NEUTRAL),
    ]
    out = []
    for key, label, mat_kws, app_kws, rgb, ap_name, exclude in spec:
        bodies = groups.get(key, [])
        if not bodies:
            continue
        got_m, got_a = '-', 'not found'
        try:
            m = find(mats, mat_kws) if mat_kws else None
            if m is not None:
                for b in bodies:
                    b.material = m
                got_m = m.name
        except:
            got_m = 'failed'
        try:
            a = find(apps, app_kws, exclude)
            if a is not None:
                ap, status = tinted(a, ap_name, rgb)
                for b in bodies:
                    b.appearance = ap
                got_a = '%s (from %s, %s)' % (ap.name, a.name, status)
        except:
            got_a = 'failed: ' + last_error()
        out.append('%s: appearance=%s, material=%s' % (label, got_a, got_m))
    return out


class Cancelled(Exception):
    pass


# Detail of the cell model, the same values as the CELL_* constants in src/pack/assembly.py (the
# parity test checks). Written as parameters on each run: name: (value, units, comment)
CELL_DETAIL = {
    'Cell_Edge': (0.7, 'mm', 'Rounded (chamfered) can edge'),
    'Cell_Button_Height': (0.5, 'mm', 'Positive button above the wrapped shoulder'),
    'Cell_Button_Ratio': (0.42, '', 'Positive button radius / cell radius'),
    'Cell_Fold_Ratio': (0.80, '', 'The wrap rolls over each end down to this fraction of the radius'),
    'Cell_Groove_From_Top': (4.0, 'mm', 'Crimp groove below the positive shoulder'),
    'Cell_Groove_Depth': (0.4, 'mm', 'Crimp groove depth'),
    'Cell_Groove_Half_Width': (1.0, 'mm', 'Crimp groove half width'),
    'Cell_Skin': (0.1, 'mm', 'End faces sit this far under the wrap fold'),
    'Cell_Button_Edge': (0.4, 'mm', 'Chamfer on the positive button'),
}


def build_cell(comp):
    """One detailed cylindrical cell in comp, centered on its origin, + end at +Z: the shrink wrap
    (crimp groove, rolled-over ends), the bare can bottom, the positive button and the insulator
    ring on the shoulder. Each body is a revolved, fully dimensioned half-section.
    Returns {name: body}."""
    R, h = '(Cell_Diameter/2)', '(Cell_Height/2)'
    top = '(Cell_Height/2 - Cell_Button_Height)'
    zg = '(%s - Cell_Groove_From_Top)' % top
    rb, rf = '(Cell_Button_Ratio * Cell_Diameter/2)', '(Cell_Fold_Ratio * Cell_Diameter/2)'
    e, k, gw = 'Cell_Edge', 'Cell_Skin', 'Cell_Groove_Half_Width'
    sections = [
        ('Cell_Wrap', [('0', add(neg(h), k)), (rf, add(neg(h), k)), (rf, neg(h)), (sub(R, e), neg(h)),
                       (R, add(neg(h), e)), (R, sub(zg, gw)), (sub(R, 'Cell_Groove_Depth'), zg),
                       (R, add(zg, gw)), (R, sub(top, e)), (sub(R, e), top), (rb, top),
                       (rb, sub(top, k)), ('0', sub(top, k))]),
        ('Cell_Can_Bottom', [('0', neg(h)), (rf, neg(h)), (rf, add(neg(h), k)), ('0', add(neg(h), k))]),
        ('Cell_Button', [('0', sub(top, k)), (rb, sub(top, k)), (rb, sub(h, 'Cell_Button_Edge')),
                         (sub(rb, 'Cell_Button_Edge'), h), ('0', h)]),
        ('Insulator_Ring', [('(Insulator_ID/2)', top), ('(Holder_Bore/2)', top),
                            ('(Holder_Bore/2)', add(top, 'Insulator_Thickness')),
                            ('(Insulator_ID/2)', add(top, 'Insulator_Thickness'))]),
    ]
    bodies = {}
    for name, rz in sections:
        sk = new_sketch(comp, comp.xZConstructionPlane, name + '_Section')
        axes = sketch_axes(sk)
        pts = []
        for r, z in rz:
            se = ['0', '0']
            for ax, val in (('x', r), ('z', z)):
                i, sign = axes[ax]
                se[i] = val if sign > 0 else neg(val)
            pts.append(tuple(se))
        poly(sk, pts)
        ri = comp.features.revolveFeatures.createInput(
            sk.profiles.item(0), comp.zConstructionAxis, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        ri.setAngleExtent(False, vi('360 deg'))
        b = comp.features.revolveFeatures.add(ri).bodies.item(0)
        b.name = name
        bodies[name] = b
    return bodies


def build_holder_unit(comp):
    """One single-cell holder in comp, centered on its origin: z = 0 is the cell end, the outer face
    is at +Holder_Recess. A Cell_Pitch square slab with the bore, cut down to the cell end by the
    face channels, and a quarter tab island at each corner standing up to the face (four adjacent
    holders make one square island where four cells meet). Returns the body."""
    slab = 'Holder_Height - Holder_Recess'
    sk = new_sketch(comp, offset_plane(comp, comp.xYConstructionPlane, neg(slab)), 'Holder_Slab')
    p2 = half('Cell_Pitch')
    rect(sk, neg(p2), p2, neg(p2), p2, 'Cell_Pitch', 'Cell_Pitch')
    circle(sk, '0', '0', 'Holder_Bore')
    prof = [p for p in sk.profiles if p.profileLoops.count == 2][0]
    hi = comp.features.extrudeFeatures.createInput(prof, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
    hi.setDistanceExtent(False, vi(slab))
    body = comp.features.extrudeFeatures.add(hi).bodies.item(0)
    body.name = 'Holder'
    try:
        ski = new_sketch(comp, comp.xYConstructionPlane, 'Holder_Tab_Islands')
        g2 = half('Holder_Tab_Gap')
        for sx in (1, -1):
            for sy in (1, -1):
                xa, xb = (g2, p2) if sx > 0 else (neg(p2), neg(g2))
                ya, yb = (g2, p2) if sy > 0 else (neg(p2), neg(g2))
                rect(ski, xa, xb, ya, yb, '(Cell_Pitch - Holder_Tab_Gap)/2', '(Cell_Pitch - Holder_Tab_Gap)/2')
        ii = comp.features.extrudeFeatures.createInput(
            all_profiles(ski), adsk.fusion.FeatureOperations.JoinFeatureOperation)
        ii.setDistanceExtent(False, vi('Holder_Recess'))
        ii.participantBodies = [body]
        comp.features.extrudeFeatures.add(ii)
    except Cancelled:
        raise
    except:
        ISSUES.append('Holder tab islands failed (plain holder left): %s' % last_error())
    return body


def unit_matrix(x_mm, y_mm, z_mm, flip=False, turn=False):
    """Placement of a unit component: flip turns it end for end (180 degrees about X), turn a
    quarter turn about Z."""
    m = adsk.core.Matrix3D.create()
    if flip:
        m.setToRotation(math.pi, adsk.core.Vector3D.create(1, 0, 0), adsk.core.Point3D.create(0, 0, 0))
    elif turn:
        m.setToRotation(math.pi / 2, adsk.core.Vector3D.create(0, 0, 1), adsk.core.Point3D.create(0, 0, 0))
    m.translation = adsk.core.Vector3D.create(x_mm * MM, y_mm * MM, z_mm * MM)
    return m


def build_coupling_nut(comp):
    """One coupling nut in comp, centered on its origin along Z: a hex prism (corners on +/-X, like
    the pockets in a wall along X) with a plain Thread_Diameter bore. Returns the body."""
    sk = new_sketch(comp, offset_plane(comp, comp.xYConstructionPlane, neg(half('Coupling_Nut_Length'))),
                    'Coupling_Nut')
    r, r2, f2 = '(Coupling_Nut_AF)/1.7320508', '(Coupling_Nut_AF)/3.4641016', half('Coupling_Nut_AF')
    poly(sk, [(r, '0'), (r2, f2), (neg(r2), f2), (neg(r), '0'), (neg(r2), neg(f2)), (r2, neg(f2))])
    circle(sk, '0', '0', 'Thread_Diameter')
    prof = [p for p in sk.profiles if p.profileLoops.count == 2][0]
    ei = comp.features.extrudeFeatures.createInput(prof, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
    ei.setDistanceExtent(False, vi('Coupling_Nut_Length'))
    body = comp.features.extrudeFeatures.add(ei).bodies.item(0)
    body.name = 'Coupling_Nut'
    return body


def build_allthread(comp):
    """One piece of allthread in comp, centered on its origin along Z (drawn as a plain rod)."""
    sk = new_sketch(comp, offset_plane(comp, comp.xYConstructionPlane, neg(half('Allthread_Length'))), 'Allthread')
    circle(sk, '0', '0', 'Thread_Diameter')
    ei = comp.features.extrudeFeatures.createInput(
        sk.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
    ei.setDistanceExtent(False, vi('Allthread_Length'))
    body = comp.features.extrudeFeatures.add(ei).bodies.item(0)
    body.name = 'Allthread'
    return body


def place_units(design, comp, source, mats):
    """A copy of source's component at every matrix in comp (the way the screws are placed). The
    source occurrence, where the unit was built at the origin, is hidden. Positions are captured
    so later timeline features do not move them back. Returns the copies."""
    occs = [comp.occurrences.addExistingComponent(source.component, m) for m in mats]
    source.isLightBulbOn = False
    try:
        if design.snapshots.hasPendingSnapshot:
            design.snapshots.add()
    except:
        pass
    return occs


def check_units(occs, mats):
    """How far the copies ended up from where they were placed (mm); 0 when all are in place."""
    worst = 0.0
    for o, m in zip(occs, mats):
        a, b = o.transform2.translation, m.translation
        worst = max(worst, abs(a.x - b.x) / MM, abs(a.y - b.y) / MM, abs(a.z - b.z) / MM)
    return worst


def run(context):
    ui = None
    prog = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        design = app.activeProduct
        if not isinstance(design, adsk.fusion.Design):
            ui.messageBox('Please switch to the Design workspace in Fusion 360 before running this script.')
            return
        try:
            design.designType = adsk.fusion.DesignTypes.ParametricDesignType
        except:
            pass
        rootComp = design.rootComponent
        design.fusionUnitsManager.distanceDisplayUnits = adsk.fusion.DistanceUnits.MillimeterDistanceUnits

        # Progress dialog: shows the current stage, has a Cancel button, and each stage
        # is also written to the Text Commands panel.
        prog = ui.createProgressDialog()
        prog.isCancelButtonShown = True
        prog.show('Generating enclosure', 'Starting...', 0, 6, 0)   # last arg: delay in s before it appears

        def say(msg):
            prog.message = msg
            adsk.doEvents()              # lets Fusion repaint the dialog
            app.log(msg)
            if prog.wasCancelled:
                raise Cancelled()

        timings = []   # (stage, seconds), shown in the result dialog
        t_start = [time.time()]

        def step(msg):
            now = time.time()
            if timings or prog.progressValue:
                timings[-1] = (timings[-1][0], now - t_start[0])
            t_start[0] = now
            timings.append((msg.split('  ', 1)[-1].rstrip('.'), 0.0))
            prog.progressValue += 1
            say(msg)

        step('1/6  Setting up parameters...')
        setup_parameters(design)
        cols = int(round(VALS['Columns']))
        rows = int(round(VALS['Rows']))

        # Remove a previously generated assembly
        for o in list(rootComp.occurrences):
            if o.component.name.startswith(('EBike_Battery_Enclosure', '_screw_import')):   # + leftovers from an older screw import
                o.deleteMe()

        occ = rootComp.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        assy = occ.component
        assy.name = 'EBike_Battery_Enclosure_%dS%dP' % (cols, rows)

        part_occs = {}

        def new_part(name, slide=True):
            m = adsk.core.Matrix3D.create()
            if slide and BASE_PLATE:   # battery parts are slid -X relative to the base plate
                m.translation = adsk.core.Vector3D.create(-VALS['Battery_Latch_Slide'] * MM, 0, 0)
            po = assy.occurrences.addNewComponent(m)
            po.component.name = name
            part_occs[name] = po
            return po.component

        # ---- Layout decided at run time (structural; re-run to respace) ----
        # The printed wall ring is split into pieces and the screws placed by wall_layout (same
        # rule as pack.geometry.wall_layout, docs/WALL_SECTIONING.md). Counts and positions are
        # fixed when the script runs: re-run after changing the pack size. Wall faces and plate
        # sizes stay driven by the parameters.
        PW2, PH2 = half('Plate_Width'), half('Plate_Height')
        CW2, CH2 = half('Cavity_Width'), half('Cavity_Height')
        hx_mm, hy_mm, edges, ring = wall_layout(VALS)
        bolt_pts = [ring_xy(k, x) for k, e in enumerate(edges) for x in e[2]]
        hook_xs = [mm(x) for x in hook_positions(VALS, edges, hx_mm)] if BASE_PLATE else []
        # screws as ((x, y), along X?): the bottom and top edges (0, 2) run along X
        pieces = [(corner, [ring_xy(*pt) for pt in pts], [(ring_xy(*sc), sc[0] % 2 == 0) for sc in screws])
                  for corner, pts, screws in ring_pieces(edges, ring)]
        bolt_along = [k % 2 == 0 for k, e in enumerate(edges) for x in e[2]]

        # ==============================================================================
        # 1. SIDE PLATES (polycarbonate): square corners, M5 holes, L-hooks with reliefs
        # ==============================================================================
        step('2/6  Building side plates...')
        sideComp = new_part('PC_Side_Plates')
        left_plane = offset_plane(sideComp, sideComp.xYConstructionPlane,
                                  '-(Cavity_Depth/2 + Polycarbonate_Thickness)')

        def build_side_plate(plane, name):
            say('2/6  Side plate: ' + name + '...')
            sk = new_sketch(sideComp, plane, name + '_Outline')
            rect(sk, neg(PW2), PW2, neg(PH2), PH2, 'Plate_Width', 'Plate_Height')
            for hx in hook_xs:
                nx0 = sub(hx, half('Hook_Neck_Width'))
                nx1 = add(hx, half('Hook_Neck_Width'))
                y_low = neg(add(PH2, 'Hook_Drop'))
                rect(sk, nx0, nx1, y_low, sub('Hook_Overlap', PH2), 'Hook_Neck_Width', None)
                rect(sk, sub(nx0, 'Hook_Nose'), hx, y_low, neg(add(PH2, 'Alu_Thickness')), None, None)   # nose points -X
            ext_in = sideComp.features.extrudeFeatures.createInput(
                all_profiles(sk), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            ext_in.setDistanceExtent(False, vi('Polycarbonate_Thickness'))
            feat = sideComp.features.extrudeFeatures.add(ext_in)
            bodies = []
            for i in range(feat.bodies.count):
                b = feat.bodies.item(i)
                b.name = name if i == 0 else '%s_%d' % (name, i)
                bodies.append(b)

            # Square plate corners (Plate_Corner_Radius round); small fillets on the hooks' outside corners
            pw2, ph2 = VALS['Plate_Width'] / 2.0, VALS['Plate_Height'] / 2.0
            if VALS['Plate_Corner_Radius'] > 0:
                big = [(sx * pw2, sy * ph2) for sx in (-1, 1) for sy in (-1, 1)]
                fillet_edges(sideComp, find_edges(bodies[0], 'z', big), 'Plate_Corner_Radius', 'side plate corners')
            small = []
            for hxs in hook_xs:
                hxv = ev(hxs)
                yl = -(ph2 + VALS['Hook_Drop'])
                small += [(hxv - VALS['Hook_Neck_Width'] / 2.0 - VALS['Hook_Nose'], yl),
                          (hxv - VALS['Hook_Neck_Width'] / 2.0 - VALS['Hook_Nose'], -(ph2 + VALS['Alu_Thickness'])),
                          (hxv + VALS['Hook_Neck_Width'] / 2.0, yl)]
            if small:
                fillet_edges(sideComp, find_edges(bodies[0], 'z', small), 'Fillet_Small', 'hook corners')

            # Screw holes on the wall ring's centerline, and the hook reliefs
            skc = new_sketch(sideComp, plane, name + '_Holes')
            for (bx, by) in bolt_pts:
                circle(skc, bx, by, 'Bolt_Hole_Diameter')
            # Hook root reliefs: a router-diameter circle centered on the nose top and tangent to the
            # neck's inside edge, so it cuts only down into the nose (its upper half is in the open
            # slot). The neck keeps its full inside face, the stop that bears on the end of the
            # base-plate slot (only Alu_Thickness tall); the nose loses a little at its root.
            for hx in hook_xs:
                circle(skc, sub(sub(hx, half('Hook_Neck_Width')), half('Min_CNC_Router_Diameter')),
                       neg(add(PH2, 'Alu_Thickness')), 'Min_CNC_Router_Diameter')
            # Neck-to-plate reliefs: where each neck meets the plate's bottom edge, a router circle
            # centered on the edge and tangent to the neck side, so the router leaves no radius in
            # the corner and the plate seats flat on the base plate.
            for hx in hook_xs:
                for xe in (sub(sub(hx, half('Hook_Neck_Width')), half('Min_CNC_Router_Diameter')),
                           add(add(hx, half('Hook_Neck_Width')), half('Min_CNC_Router_Diameter'))):
                    circle(skc, xe, neg(PH2), 'Min_CNC_Router_Diameter')

            cut_in = sideComp.features.extrudeFeatures.createInput(
                all_profiles(skc), adsk.fusion.FeatureOperations.CutFeatureOperation)
            cut_in.setDistanceExtent(False, vi('Polycarbonate_Thickness + Cut_Overshoot'))
            cut_in.participantBodies = bodies
            sideComp.features.extrudeFeatures.add(cut_in)
            return bodies

        front_bodies = build_side_plate(left_plane, 'Front_PC_Side_Plate')     # -Z

        # The rear plate is a mirror of the front plate about the mid-plane (Z = 0), so the two
        # stay identical and follow Cavity_Depth automatically.
        say('2/6  Mirroring the rear side plate...')
        try:
            mcol = adsk.core.ObjectCollection.create()
            for b in front_bodies:
                mcol.add(b)
            mf = sideComp.features.mirrorFeatures
            mir = mf.add(mf.createInput(mcol, sideComp.xYConstructionPlane))
            for i in range(mir.bodies.count):
                mir.bodies.item(i).name = 'Rear_PC_Side_Plate' if i == 0 else 'Rear_PC_Side_Plate_%d' % i
        except:
            ISSUES.append('Mirror of the rear side plate failed: %s' % last_error())

        # Fillet size sanity checks (a fillet that is too big makes the rebuild fail)
        if hook_xs and 2.0 * VALS['Fillet_Small'] > VALS['Hook_Drop_Extra']:
            ISSUES.append('Warning: Fillet_Small is large for the hook nose height (%.2f mm)' % VALS['Hook_Drop_Extra'])
        if hook_xs and VALS['Hook_Slot_Length'] < VALS['Hook_Neck_Width'] + VALS['Hook_Nose']:
            ISSUES.append('Warning: Hook_Slot_Length is shorter than neck + nose: the hooks will not drop through')

        # ==============================================================================
        # 2. PRINTED WALL RING (ABS): one body per piece, standing between the side plates
        # ==============================================================================
        step('3/6  Building printed wall pieces...')
        wallComp = new_part('Printed_Walls')
        n_sec = n_cor = 0
        for is_corner, pts, screws in pieces:
            if is_corner:
                n_cor += 1
                name = 'Corner_Piece_%d' % n_cor
            else:
                n_sec += 1
                name = 'Wall_Section_%d' % n_sec
            say('3/6  ' + name + '...')
            try:
                skp = new_sketch(wallComp, wallComp.xYConstructionPlane, name)
                poly(skp, pts)
                for (sx, sy), along_x in screws:     # hex pocket for the coupling nuts, flats along the wall
                    poly(skp, pocket_pts(sx, sy, along_x))
                prof = max(skp.profiles, key=lambda p: p.areaProperties().area)   # the piece, not a hole
                wi = wallComp.features.extrudeFeatures.createInput(
                    prof, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
                wi.setSymmetricExtent(vi('Cavity_Depth/2'), False)
                body = wallComp.features.extrudeFeatures.add(wi).bodies.item(0)
                body.name = name
                if is_corner:      # the outside (vertex 1) and inside (vertex 5) of the corner
                    for i, param, where in ((1, 'Corner_Outer_Fillet', 'outside'), (5, 'Corner_Inner_Fillet', 'inside')):
                        if VALS[param] > 0:
                            p = (ev(pts[i][0]), ev(pts[i][1]))
                            fillet_edges(wallComp, find_edges(body, 'z', [p]), param, '%s %s corner' % (name, where))
            except Cancelled:
                raise
            except:
                ISSUES.append('%s failed: %s' % (name, last_error()))

        # ==============================================================================
        # 3. INTERNAL CORE: cells and cell holders (copied units), nickel strips, foam.
        # Each is its own part (the strips and foam pieces one part each, in a group part).
        # ==============================================================================
        step('4/6  Building cells, holders, strips and foam...')
        intComp = None      # only the plate fallback for the nickel strips uses it (see below)
        # Cells sit on the bottom foam, centered along X. The room above them (Extra_Height) and
        # beyond their ends (Extra_Length) is left empty for the BMS, fuses and wiring.
        CCW2 = half('Cell_Core_Width')
        y_cells = add(neg(CH2), 'Foam_Gap')
        y_block_top = add(y_cells, 'Cell_Core_Height')     # top of the cell block

        # Cells and holders: one detailed cell and one single-cell holder, each built once as a
        # component at the origin (that occurrence hidden) and copied to every grid position, in a
        # part of their own so each group shows / hides as one. Columns alternate polarity (column
        # 0 has its + end at +Z): odd columns are turned end for end. The front holders are the
        # rear ones turned around. Positions are fixed when the script runs (re-run to respace).
        x0_mm = ev(add(neg(CCW2), half('Cell_Pitch')))     # first cell center
        y0_mm = ev(add(y_cells, half('Cell_Pitch')))
        h2_mm = VALS['Cell_Height'] / 2.0
        for nm, (val, units, comment) in CELL_DETAIL.items():
            runtime_param(design, nm, '%g %s' % (val, units) if units else '%g' % val, units, comment)
        p_mm = VALS['Cell_Pitch']
        grid = [(x0_mm + c * p_mm, y0_mm + r * p_mm, c) for c in range(cols) for r in range(rows)]
        cellsComp = new_part('Cells')
        cell_src = cellsComp.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        cell_comp = cell_src.component
        cell_comp.name = 'Cell_%gx%g' % (VALS['Cell_Diameter'], VALS['Cell_Height'])
        cell_bodies = build_cell(cell_comp)
        cell_mats = [unit_matrix(x, y, 0, flip=(c % 2 == 1)) for x, y, c in grid]
        cell_occs = place_units(design, cellsComp, cell_src, cell_mats)
        UNIT_CHECKS.append(('Cells', cell_comp.name, cell_occs, cell_mats))

        holdersComp = new_part('Cell_Holders')
        hold_src = holdersComp.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        hold_comp = hold_src.component
        hold_comp.name = 'Holder_Unit_%g' % VALS['Cell_Pitch']
        holder_body = build_holder_unit(hold_comp)
        hold_mats = ([unit_matrix(x, y, h2_mm) for x, y, _ in grid]
                     + [unit_matrix(x, y, -h2_mm, flip=True) for x, y, _ in grid])
        hold_occs = place_units(design, holdersComp, hold_src, hold_mats)
        UNIT_CHECKS.append(('Cell holders', hold_comp.name, hold_occs, hold_mats))

        # Fallback nickel strips, used only when this Fusion cannot make sheet metal (see
        # build_sheet_strips below): plain plates without holes or weld slots. Two columns per strip,
        # alternating ends; the pack terminals get a full 2P strip, half on the end column and half
        # folded around the end of the cell block. Each strip's tab leg carries on over the top of the
        # cell block and folds over the holder's top edge (the BMS balance tab).
        def extrude_all(sk, length_expr, name):
            si = intComp.features.extrudeFeatures.createInput(
                all_profiles(sk), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            si.setDistanceExtent(False, vi(length_expr))
            feat = intComp.features.extrudeFeatures.add(si)
            for i in range(feat.bodies.count):
                feat.bodies.item(i).name = '%s_%d' % (name, i + 1)

        def make_strips(end, name):
            plane_expr = 'Cell_Height/2' if end > 0 else '-(Cell_Height/2 + Strip_Thickness)'
            pl = offset_plane(intComp, intComp.xYConstructionPlane, plane_expr)
            sk = new_sketch(intComp, pl, name + '_Sketch')
            tabs, folds = [], []          # (x0, x1) of each balance tab leg; x of each fold (+1 / -1)
            for e, c0, c1 in strip_groups(cols):
                if e != end:
                    continue
                if c1 - c0 == 2:          # tab on the -X leg
                    xb = add(neg(CCW2), '%d * Cell_Pitch' % (c0 + 1))
                    x0, x1, w = sub(xb, half('Strip_Width')), add(xb, half('Strip_Width')), 'Strip_Width'
                    tabs.append((x0, add(x0, 'Strip_Leg')))
                elif c0 == 0:             # terminal: the half on the end column, its leg on the cell side
                    x0, x1, w = neg(CCW2), add(neg(CCW2), half('Strip_Width')), 'Strip_Width / 2'
                    tabs.append((sub(x1, 'Strip_Leg'), x1))
                    folds.append(-1)
                else:
                    x0, x1, w = sub(CCW2, half('Strip_Width')), CCW2, 'Strip_Width / 2'
                    tabs.append((x0, add(x0, 'Strip_Leg')))
                    folds.append(1)
                rect(sk, x0, x1, y_cells, y_block_top, w, 'Cell_Core_Height')
            extrude_all(sk, 'Strip_Thickness', name)

            # Balance tabs: one leg over the top of the cell block, folded back over the holder's
            # top edge to its inner face (a plate Strip_Thickness thick on the top of the block)
            try:
                tab_len = 'Strip_Thickness + Holder_Height - Holder_Recess'
                tab_plane = ('Cell_Height/2 + Holder_Recess - Holder_Height' if end > 0
                             else '-(Cell_Height/2 + Strip_Thickness)')
                skt = new_sketch(intComp, offset_plane(intComp, intComp.xYConstructionPlane, tab_plane),
                                 name + '_Balance_Tabs')
                for t0, t1 in tabs:
                    rect(skt, t0, t1, y_block_top, add(y_block_top, 'Strip_Thickness'), 'Strip_Leg', 'Strip_Thickness')
                extrude_all(skt, tab_len, name.replace('Strip', 'Tab'))
            except Cancelled:
                raise
            except:
                ISSUES.append('%s: balance tabs failed: %s' % (name, last_error()))

            # Terminal folds: the second half of the terminal strip, bent 90 degrees around the end
            # of the cell block (a plate standing just outside the block end, half a strip wide)
            if folds:
                try:
                    fold_plane = ('Cell_Height/2 + Strip_Thickness - Strip_Width/2' if end > 0
                                  else '-(Cell_Height/2 + Strip_Thickness)')
                    skf = new_sketch(intComp, offset_plane(intComp, intComp.xYConstructionPlane, fold_plane),
                                     name + '_Terminal_Folds')
                    for side in folds:
                        xe = CCW2 if side > 0 else neg(CCW2)
                        fx0, fx1 = (xe, add(xe, 'Strip_Thickness')) if side > 0 else (sub(xe, 'Strip_Thickness'), xe)
                        rect(skf, fx0, fx1, y_cells, y_block_top, 'Strip_Thickness', 'Cell_Core_Height')
                    extrude_all(skf, 'Strip_Width / 2', name.replace('Strip', 'Terminal_Fold'))
                except Cancelled:
                    raise
                except:
                    ISSUES.append('%s: terminal folds failed: %s' % (name, last_error()))

        # ---- Nickel strips as sheet metal parts ----
        # Each strip is a sheet metal part of its own in the Nickel_Strips group (rule 'Nickel strip (mm)':
        # Strip_Thickness, Strip_Bend_Radius, Strip_K_Factor), made the way it is made by hand:
        # the flat blank (a 2P ladder: two legs, a bar over every cell row, square holes between
        # the bars) is a base flange lying on the cell ends, then it is folded:
        #   * balance tab: the tab leg runs on past the top of the cell block and folds 90 degrees
        #     over the holder's top edge, its underside on the block top;
        #   * pack terminals: a full 2P strip centered on the block edge, half on the end column
        #     and half folded 90 degrees around the end of the block.
        # Weld slots (Weld_Slot_Length x Weld_Slot_Width, round ends) are cut over every cell
        # terminal: one slot per strip, patterned over the strip's columns x Rows.
        # Fold direction and stationary side are not documented in the API, so each fold is
        # checked against where the flange must end up and retried the other way if it is wrong
        # (the working combination is reused for the rest).
        def build_sheet_strips():
            if not hasattr(design, 'designSheetMetalRules'):
                raise SheetMetalUnavailable('this Fusion has no sheet metal rule API')
            group = new_part('Nickel_Strips')
            rule_box = []

            def new_strip_comp(name):
                occ = group.occurrences.addNewComponent(adsk.core.Matrix3D.create())
                sc = occ.component
                sc.name = name
                try:
                    if not rule_box:
                        rule_box.append(strip_rule(design, sc))
                    sc.activeSheetMetalRule = rule_box[0]
                except SheetMetalUnavailable:
                    raise
                except:
                    raise SheetMetalUnavailable('could not set the active sheet metal rule: %s' % last_error())
                feats = sc.features
                if not hasattr(feats, 'flangeFeatures') or not hasattr(feats.flangeFeatures, 'createBaseFlangeInput'):
                    raise SheetMetalUnavailable('this Fusion cannot create flanges from the API')
                return sc

            CENTER = getattr(getattr(adsk.fusion, 'FoldBendLinePositionTypes', None),
                             'CenterFoldBendLinePositionType', None)
            folds_ok = CENTER is not None
            if not folds_ok:
                ISSUES.insert(0, 'Nickel strips: this Fusion has no fold API, so the strips stay flat')

            V = lambda e: ev(e)   # noqa: E731
            XL, L = neg(CCW2), 'Cell_Core_Height'
            W, LEG, R, BA = 'Strip_Width', 'Strip_Leg', 'Strip_Bend_Radius', 'Strip_Bend_Allowance'
            lo = '(Cell_Pitch/2 - Cell_Diameter/2 + Strip_End_Inset)'    # strip ends inside the end cells
            gap = '(Cell_Pitch - Strip_Bar)/2'                           # half a square hole
            # Tab leg past the block top, flat: (radius short of the top) + bend + straight flange
            # over the holder (Holder_Height - Holder_Recess - radius long)
            ext = '(%s + Holder_Height - Holder_Recess - 2 * %s)' % (BA, R)
            h2, t, r = V('Cell_Height') / 2.0, VALS['Strip_Thickness'], VALS['Strip_Bend_Radius']
            ba = VALS['Strip_Bend_Allowance']
            y_top = V(y_block_top)                       # top of the cell block
            tab_reach = h2 + VALS['Holder_Recess'] - VALS['Holder_Height']   # |z| where the tab flange ends
            term_reach = h2 - VALS['Strip_Width'] / 2.0 + ba - 2 * r         # |z| of a terminal fold's edge

            planes = {}

            def plane(sc, expr):
                key = (sc.name, expr)
                if key not in planes:
                    planes[key] = offset_plane(sc, sc.xYConstructionPlane, expr)
                return planes[key]

            def blank_points(x0, tab_left):
                X = lambda a: add(x0, a)          # noqa: E731
                Y = lambda b: add(y_cells, b)     # noqa: E731
                tab_top, hi = add(L, ext), sub(L, lo)
                lt, rt = (tab_top, hi) if tab_left else (hi, tab_top)
                WL = sub(W, LEG)
                return [(X('0'), Y(lo)), (X(LEG), Y(lo)), (X(LEG), Y(gap)), (X(WL), Y(gap)), (X(WL), Y(lo)),
                        (X(W), Y(lo)), (X(W), Y(rt)), (X(WL), Y(rt)), (X(WL), Y(sub(L, gap))),
                        (X(LEG), Y(sub(L, gap))), (X(LEG), Y(lt)), (X('0'), Y(lt))]

            def base_flange(sc, prof):
                """createBaseFlangeInput wants a list of profiles in current Fusion; older builds took
                one profile or an ObjectCollection."""
                errs = []
                col = adsk.core.ObjectCollection.create()
                col.add(prof)
                for arg in ([prof], prof, col):
                    try:
                        return sc.features.flangeFeatures.add(sc.features.flangeFeatures.createBaseFlangeInput(arg))
                    except:
                        errs.append(last_error())
                raise SheetMetalUnavailable('base flange failed: %s' % ' / '.join(errs))

            # Which side of the sketch plane the base flange thickens to is found on the first
            # strip of each end: the strip must lie on the cell ends, outward (|z| from h2 to h2 + t)
            base_plane = {}

            def make_blank(sc, name, end, x0, tab_left):
                choices = [base_plane[end]] if end in base_plane else (
                    ['Cell_Height/2', 'Cell_Height/2 + Strip_Thickness'] if end > 0
                    else ['-(Cell_Height/2)', '-(Cell_Height/2 + Strip_Thickness)'])
                z0 = z1 = float('nan')
                for pexpr in choices:
                    sk = new_sketch(sc, plane(sc, pexpr), name + '_Blank')
                    poly(sk, blank_points(x0, tab_left))
                    for j in range(1, rows):
                        yc = add(y_cells, '%d * Cell_Pitch' % j)
                        rect(sk, add(x0, LEG), add(x0, sub(W, LEG)), sub(yc, gap), add(yc, gap),
                             'Strip_Width - 2 * Strip_Leg', 'Cell_Pitch - Strip_Bar')
                    prof = max(sk.profiles, key=lambda p: p.areaProperties().area)
                    feat = base_flange(sc, prof)
                    body = feat.bodies.item(0)
                    body.name = name
                    (_, _, z0), (_, _, z1) = bbox_mm(body)
                    want = (h2, h2 + t) if end > 0 else (-h2 - t, -h2)
                    if abs(z0 - want[0]) < 0.01 and abs(z1 - want[1]) < 0.01:
                        base_plane[end] = pexpr
                        return body, pexpr
                    feat.deleteMe()
                    sk.deleteMe()
                    SKETCHES.remove(sk)
                raise SheetMetalUnavailable('the base flange does not land on the cell ends (z %.2f to %.2f)' % (z0, z1))

            fold_cache = {}

            def fold(sc, name, key, pexpr, segments, stationary, check):
                """Fold strip `name` along the sketch lines `segments` (pairs of (x, y) expressions),
                keeping its `stationary` side put. Tries both bend directions and three choices of
                stationary face until check(bbox) passes; returns True, or leaves it flat."""
                if not folds_ok or not hasattr(sc.features, 'foldFeatures'):
                    return False
                feats = sc.features
                sk = new_sketch(sc, plane(sc, pexpr), name + '_Bend_' + key[0])
                lines = [sketch_line(sk, a, b) for a, b in segments]
                combos = [(sg, f) for f in ('side', 'near', 'far') for sg in (1, -1)]
                if key in fold_cache:
                    combos.remove(fold_cache[key])
                    combos.insert(0, fold_cache[key])
                errs = []
                for sign, fkind in combos:
                    body = sc.bRepBodies.itemByName(name)
                    face = stationary(body, fkind)
                    if face is None:
                        continue
                    try:
                        fi = feats.foldFeatures.createInput(face)
                        for ln in lines:
                            fi.bendLines.add(ln, vi('%d deg' % (90 * sign)), CENTER, False)
                        feat = feats.foldFeatures.add(fi)
                    except:
                        errs.append('%+d/%s: %s' % (sign, fkind, last_error()))
                        continue
                    bad = check(bbox_mm(sc.bRepBodies.itemByName(name)))
                    if bad is None:
                        fold_cache[key] = (sign, fkind)
                        return True
                    errs.append('%+d/%s: %s' % (sign, fkind, bad))
                    try:
                        feat.deleteMe()
                    except:
                        errs.append('could not undo: %s' % last_error())
                        break
                ISSUES.append('%s: %s fold failed, left flat (%s)' % (name, key[0], '; '.join(errs[:4])))
                return False

            def big_face(body, which):
                """'near' / 'far': the strip's large face nearer to / farther from the cell ends."""
                faces = sorted(planar_faces(body, 2), key=lambda f: -f[2])[:2]
                if len(faces) < 2:
                    return None
                faces.sort(key=lambda f: abs(f[1][2]))
                return faces[0 if which == 'near' else 1][0]

            def end_face(body, axis, pick):
                """A small face on the side that must stay put: the end of a leg (axis 1, lowest)
                or the strip's outer side (axis 0, lowest or highest x)."""
                faces = planar_faces(body, axis)
                if not faces:
                    return None
                return (min if pick < 0 else max)(faces, key=lambda f: f[1][axis])[0]

            def near(a, b, tol):
                return abs(a - b) < tol

            def weld_slots(sc, name, end, c0, ncols, body):
                """One slot over the first cell under the strip, patterned over its columns x Rows."""
                mid = 'Cell_Height/2 + Strip_Thickness/2'
                sk = new_sketch(sc, plane(sc, mid if end > 0 else neg(mid)), name + '_Weld_Slots')
                cx, cy = add(XL, '(%d + 0.5) * Cell_Pitch' % c0), add(y_cells, half('Cell_Pitch'))
                try:
                    obround(sk, cx, cy, 'Weld_Slot_Length', 'Weld_Slot_Width')
                except Cancelled:
                    raise
                except:
                    ISSUES.append('%s: round-ended weld slot failed, rectangle used: %s' % (name, last_error()))
                    rect(sk, sub(cx, half('Weld_Slot_Width')), add(cx, half('Weld_Slot_Width')),
                         sub(cy, half('Weld_Slot_Length')), add(cy, half('Weld_Slot_Length')),
                         'Weld_Slot_Width', 'Weld_Slot_Length')
                feats = sc.features
                ci = feats.extrudeFeatures.createInput(sk.profiles.item(0),
                                                       adsk.fusion.FeatureOperations.CutFeatureOperation)
                ci.setSymmetricExtent(vi('Strip_Thickness'), False)
                ci.participantBodies = [body]
                cut = feats.extrudeFeatures.add(ci)
                if ncols * rows > 1:
                    fc = adsk.core.ObjectCollection.create()
                    fc.add(cut)
                    pin = feats.rectangularPatternFeatures.createInput(
                        fc, sc.xConstructionAxis, vi('%d' % ncols), vi('Cell_Pitch'),
                        adsk.fusion.PatternDistanceType.SpacingPatternDistanceType)
                    pin.setDirectionTwo(sc.yConstructionAxis, vi('Rows'), vi('Cell_Pitch'))
                    feats.rectangularPatternFeatures.add(pin)

            count = {1: 0, -1: 0}
            for end, c0, c1 in strip_groups(cols):
                label = 'Rear' if end > 0 else 'Front'
                count[end] += 1
                name = 'Nickel_Strip_%s_%d' % (label, count[end])
                say('4/6  Nickel strip %s...' % name)
                sc = new_strip_comp(name)
                if c1 - c0 == 2:
                    x0, tab_left, term = add(XL, '(%d * Cell_Pitch - Strip_Width/2)' % (c0 + 1)), True, 0
                elif c0 == 0:
                    x0, tab_left, term = sub(XL, half(W)), False, -1
                else:
                    x0, tab_left, term = add(XL, sub('Cell_Core_Width', half(W))), True, 1
                body, pexpr = make_blank(sc, name, end, x0, tab_left)
                (bx0, by0, bz0), (bx1, by1, bz1) = bbox_mm(body)
                z_face = end * (h2 + t)          # outer face of the strip, must not move

                # Weld slots first, on the flat blank
                try:
                    weld_slots(sc, name, end, c0, c1 - c0, body)
                except Cancelled:
                    raise
                except:
                    ISSUES.append('%s: weld slots failed: %s' % (name, last_error()))

                # Balance tab: bend line across the tab leg, centered in the bend zone, which starts
                # one bend radius below the block top
                tx0 = x0 if tab_left else add(x0, sub(W, LEG))
                yl = add(y_block_top, '%s/2 - %s' % (BA, R))

                def tab_check(bb, by0=by0, end=end, z_face=z_face):
                    (_, y0, z0), (_, y1, z1) = bb
                    zin, zout = (z0, z1) if end > 0 else (-z1, -z0)
                    if not near(y0, by0, 0.05) or not near(zout, abs(z_face), 0.02):
                        return 'the strip itself moved'
                    if not near(y1, y_top + t, 0.05):
                        return 'tab top at %.2f, want %.2f' % (y1, y_top + t)
                    if not near(zin, tab_reach, 0.25):
                        return 'tab reaches |z| %.2f, want %.2f' % (zin, tab_reach)
                    return None

                tab_done = fold(sc, name, ('tab', end), pexpr, [((tx0, yl), (add(tx0, LEG), yl))],
                                lambda b, k: end_face(b, 1, -1) if k == 'side' else big_face(b, k), tab_check)

                # Pack terminal: fold the outer half around the end of the block. Bend line along Y
                # through the bars (one segment per bar, so it never crosses a hole), centered in
                # the bend zone, which starts one bend radius in from the block edge.
                if term:
                    xe = XL if term < 0 else CCW2
                    xl = (add(xe, '%s - %s/2' % (R, BA)) if term < 0 else sub(xe, '%s - %s/2' % (R, BA)))
                    segs = []
                    for j in range(rows):
                        yb = add(y_cells, '%d * Cell_Pitch' % j)
                        segs.append(((xl, add(yb, gap)), (xl, add(yb, sub('Cell_Pitch', gap)))))
                    x_edge = V(xe) + term * t     # outer face of the folded half
                    x_keep = bx1 if term < 0 else bx0
                    reach = min(term_reach, tab_reach if tab_done else h2)   # deepest |z| after the fold

                    def term_check(bb, term=term, end=end, z_face=z_face, x_keep=x_keep, x_edge=x_edge, reach=reach):
                        (x0_, _, z0), (x1_, _, z1) = bb
                        zin, zout = (z0, z1) if end > 0 else (-z1, -z0)
                        if not near(x1_ if term < 0 else x0_, x_keep, 0.05) or not near(zout, abs(z_face), 0.02):
                            return 'the strip itself moved'
                        if not near(x0_ if term < 0 else x1_, x_edge, 0.05):
                            return 'fold face at x %.2f, want %.2f' % (x0_ if term < 0 else x1_, x_edge)
                        if not near(zin, reach, 0.25):
                            return 'fold reaches |z| %.2f, want %.2f' % (zin, reach)
                        return None

                    fold(sc, name, ('terminal', end, term), pexpr, segs,
                         lambda b, k, term=term: end_face(b, 0, -term) if k == 'side' else big_face(b, k), term_check)
            return group

        stripComp = None
        strips_note = 'built'
        try:
            if not NICKEL_STRIPS:
                strips_note = 'left out (NICKEL_STRIPS = False)'
            else:
                stripComp = build_sheet_strips()
        except Cancelled:
            raise
        except SheetMetalUnavailable as exc:
            ISSUES.insert(0, 'Nickel strips built as plates (no sheet metal): %s' % exc)
            if 'Nickel_Strips' in part_occs:
                try:
                    part_occs.pop('Nickel_Strips').deleteMe()
                    SKETCHES[:] = [s for s in SKETCHES if s.isValid]     # the strips' sketches went with it
                except:
                    ISSUES.append('Could not remove the half-built sheet metal strips: %s' % last_error())
            try:
                intComp = new_part('Nickel_Strips')
                make_strips(-1, 'Nickel_Strip_Front')
                make_strips(1, 'Nickel_Strip_Rear')
            except Cancelled:
                raise
            except:
                ISSUES.append('Nickel strips failed: %s' % last_error())
        except:
            ISSUES.insert(0, 'Nickel strips (sheet metal) failed: %s' % last_error())

        # Foam liner: six pieces, each its own part in the Foam group, drawn at the full uncompressed
        # thickness (they overlap the cell block and holders by Foam_Compression, the squeeze).
        # Bottom and top run the full cavity width; the end pieces sit between them; the side pads
        # cover the inside faces of the side plates, over the holder faces.
        foamComp = new_part('Foam')
        FT = 'Foam_Thickness'
        CD = 'Cavity_Depth'
        foam_pieces = [   # name, x0, x1, y0, y1, width expr, height expr, plane z, depth expr
            ('Foam_Bottom', neg(CW2), CW2, neg(CH2), add(neg(CH2), FT), 'Cavity_Width', FT, 'Core_Depth', True),
            ('Foam_Top', neg(CW2), CW2, sub(CH2, FT), CH2, 'Cavity_Width', FT, 'Core_Depth', True),
            ('Foam_End_Left', neg(CW2), add(neg(CW2), FT), add(neg(CH2), FT), sub(CH2, FT),
             FT, 'Cavity_Height - 2 * Foam_Thickness', 'Core_Depth', True),
            ('Foam_End_Right', sub(CW2, FT), CW2, add(neg(CH2), FT), sub(CH2, FT),
             FT, 'Cavity_Height - 2 * Foam_Thickness', 'Core_Depth', True),
            ('Foam_Side_Front', neg(CW2), CW2, neg(CH2), CH2, 'Cavity_Width', 'Cavity_Height', '-(%s/2)' % CD, False),
            ('Foam_Side_Rear', neg(CW2), CW2, neg(CH2), CH2, 'Cavity_Width', 'Cavity_Height', '%s/2 - %s' % (CD, FT), False),
        ]
        foam_bodies = []
        for name, x0, x1, y0, y1, wx, hy, zexpr, symmetric in foam_pieces:
            try:
                fc = foamComp.occurrences.addNewComponent(adsk.core.Matrix3D.create()).component
                fc.name = name
                pl = fc.xYConstructionPlane if symmetric else offset_plane(fc, fc.xYConstructionPlane, zexpr)
                sk = new_sketch(fc, pl, name)
                rect(sk, x0, x1, y0, y1, wx, hy)
                fe = fc.features.extrudeFeatures.createInput(
                    sk.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
                if symmetric:
                    fe.setSymmetricExtent(vi('%s/2' % zexpr), False)
                else:
                    fe.setDistanceExtent(False, vi(FT))
                b = fc.features.extrudeFeatures.add(fe).bodies.item(0)
                b.name = 'Neoprene_' + name
                foam_bodies.append(b)
            except Cancelled:
                raise
            except:
                ISSUES.append('%s failed: %s' % (name, last_error()))

        # ==============================================================================
        # 4. ALUMINUM BASE PLATE
        # ==============================================================================
        baseComp = None
        if not BASE_PLATE:
            step('5/6  No base plate (BASE_PLATE = False)')
        else:
            step('5/6  Building aluminum base plate...')
            baseComp = new_part('Alu_6061_Base_Plate', slide=False)
            base_plane = offset_plane(baseComp, baseComp.xYConstructionPlane,
                                      '-(Cavity_Depth/2 + Polycarbonate_Thickness + Side_Extension)')
            sk_base = new_sketch(baseComp, base_plane, 'Base_Profile')
            # Extensions are measured from the battery's slid (latched) position
            bx0 = neg(add(add(PW2, 'Base_Rear_Extension'), 'Battery_Latch_Slide'))
            bx1 = sub(add(PW2, 'Base_Front_Extension'), 'Battery_Latch_Slide')
            rect(sk_base, bx0, bx1, neg(add(PH2, 'Alu_Thickness')), neg(PH2), 'Base_Plate_X_Length', 'Alu_Thickness')
            b_in = baseComp.features.extrudeFeatures.createInput(
                sk_base.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            b_in.setDistanceExtent(False, vi('Base_Plate_Z_Width'))
            base_body = baseComp.features.extrudeFeatures.add(b_in).bodies.item(0)
            bx0v = -(VALS['Plate_Width'] / 2.0 + VALS['Base_Rear_Extension'] + VALS['Battery_Latch_Slide'])
            bx1v = VALS['Plate_Width'] / 2.0 + VALS['Base_Front_Extension'] - VALS['Battery_Latch_Slide']
            bz = VALS['Base_Plate_Z_Width'] / 2.0
            fillet_edges(baseComp, find_edges(base_body, 'y', [(x, z) for x in (bx0v, bx1v) for z in (-bz, bz)]),
                         'Fillet_Large', 'base plate corners')
            base_body.name = 'Aluminum_6061_Base_Plate'

            # Hook slots: sketched on the XZ plane. Find how sketch axes map to model X / Z.
            sk_bcut = new_sketch(baseComp, baseComp.xZConstructionPlane, 'Base_Hook_Slots')
            m = sk_bcut.modelToSketchSpace(adsk.core.Point3D.create(1, 0, 1))
            fx = 1 if m.x > 0 else -1
            fy = 1 if m.y > 0 else -1

            def to_sketch(f, a, b):
                return (a, b) if f > 0 else (neg(b), neg(a))

            z_ctr = add(half('Cavity_Depth'), half('Polycarbonate_Thickness'))
            for hx in hook_xs:
                # Slots stay fixed in the base plate's own frame (nominal hook positions). The
                # battery is slid -X by Battery_Latch_Slide, which puts each hook neck
                # against the front (-X) end of its slot with the nose under solid plate.
                xa = sub(hx, sub('Hook_Slot_Length', 'Hook_Slot_Offset'))
                xb = add(hx, 'Hook_Slot_Offset')
                for zc in (z_ctr, neg(z_ctr)):
                    za, zb = sub(zc, half('Slot_Width')), add(zc, half('Slot_Width'))
                    sx0, sx1 = to_sketch(fx, xa, xb)
                    sy0, sy1 = to_sketch(fy, za, zb)
                    rect(sk_bcut, sx0, sx1, sy0, sy1, 'Hook_Slot_Length', 'Slot_Width')
            bc_in = baseComp.features.extrudeFeatures.createInput(
                all_profiles(sk_bcut), adsk.fusion.FeatureOperations.CutFeatureOperation)
            bc_in.setAllExtent(adsk.fusion.ExtentDirections.SymmetricExtentDirection)
            bc_in.participantBodies = [base_body]
            baseComp.features.extrudeFeatures.add(bc_in)

        # ==============================================================================
        # 5. FASTENERS at every screw location: a coupling nut seated on the front (-Z) plate and
        # one Far_Nut_Recess short of the rear plate, both in the wall piece's hex pocket and
        # joined by allthread; a McMaster screw through each side plate into its nut. Positions are
        # fixed when the script runs (re-run after resizing).
        # ==============================================================================
        step('6/6  Placing fasteners...')
        hw_bodies = []
        fast_note = 'not placed'
        try:
            hwComp = new_part('Fasteners')
            cd2 = VALS['Cavity_Depth'] / 2.0
            ln = VALS['Coupling_Nut_Length']
            locs = [(ev(bx), ev(by), along) for (bx, by), along in zip(bolt_pts, bolt_along)]
            nut_src = hwComp.occurrences.addNewComponent(adsk.core.Matrix3D.create())
            nut_src.component.name = 'Coupling_Nut_M5'
            hw_bodies.append(build_coupling_nut(nut_src.component))
            nut_mats = [unit_matrix(x, y, z, turn=not along) for z in (-cd2 + ln / 2.0, cd2 - VALS['Far_Nut_Recess'] - ln / 2.0)
                        for x, y, along in locs]
            nut_occs = place_units(design, hwComp, nut_src, nut_mats)
            UNIT_CHECKS.append(('Coupling nuts', nut_src.component.name, nut_occs, nut_mats))
            rod_src = hwComp.occurrences.addNewComponent(adsk.core.Matrix3D.create())
            rod_src.component.name = 'Allthread_M5x%g' % round(VALS['Allthread_Length'], 1)
            hw_bodies.append(build_allthread(rod_src.component))
            rod_z = (VALS['Allthread_Near_Gap'] - VALS['Allthread_Far_Gap']) / 2.0   # bottomed on the front screw
            rod_mats = [unit_matrix(x, y, rod_z) for x, y, _ in locs]
            rod_occs = place_units(design, hwComp, rod_src, rod_mats)
            UNIT_CHECKS.append(('Allthread', rod_src.component.name, rod_occs, rod_mats))
            e1 = VALS['Screw_Length'] - VALS['Polycarbonate_Thickness']
            fast_note = ('%d locations; screws thread %.1f mm into the front nut, %.1f mm into the rear; '
                         'allthread %.1f mm' % (len(locs), e1, e1 - VALS['Far_Nut_Recess'], VALS['Allthread_Length']))
        except Cancelled:
            raise
        except:
            ISSUES.insert(0, 'Coupling nuts / allthread failed: %s' % last_error())
        say('6/6  Placing screws...')
        step_path = find_hardware_file(SCREW_PART)
        if step_path is None:
            ISSUES.insert(0, 'Screws skipped: put the McMaster %s STEP file in fusion/ebike_enclosure/hardware/' % SCREW_PART)
        else:
            try:
                scComp = new_part('Hardware_Screws_%s' % SCREW_PART)
                z_face = VALS['Cavity_Depth'] / 2.0 + VALS['Polycarbonate_Thickness']
                targets = [(ev(px), ev(py), side * z_face, -side) for (px, py) in bolt_pts for side in (-1, 1)]
                screw_comp, shank, placed = place_screws(design, scComp, step_path, targets)
                if placed != len(targets):
                    ISSUES.insert(0, 'Screws: placed %d of %d' % (placed, len(targets)))
                if abs(shank - VALS['Screw_Length']) > 0.5:
                    ISSUES.append('Warning: the screw STEP is %.1f mm under the head, Screw_Length is %.1f mm'
                                  % (shank, VALS['Screw_Length']))
            except Cancelled:
                raise
            except:
                ISSUES.insert(0, 'Screws failed: %s' % last_error())

        # ==============================================================================
        # 6. GROUND THE BASE PLATE (OR THE SIDE PLATES), THEN MATERIALS AND APPEARANCES
        # ==============================================================================
        say('Grounding and applying materials...')
        anchor = 'Alu_6061_Base_Plate' if BASE_PLATE else 'PC_Side_Plates'
        try:
            part_occs[anchor].isGroundToParent = True
            for nm, po in part_occs.items():
                if nm != anchor:
                    po.isGroundToParent = False
        except:
            ISSUES.append('Grounding %s failed: %s' % (anchor, last_error()))
        # Bind the whole assembly into one rigid group, so the parts (and the screws nested in
        # their components) move as one and stay put relative to the grounded anchor
        rigid_note = 'not created'
        try:
            group_occs = adsk.core.ObjectCollection.create()
            for o in assy.occurrences:
                group_occs.add(o)
            rg = assy.rigidGroups.add(group_occs, True)
            rg.name = 'Pack_Rigid'
            rigid_note = '%d parts and their children' % group_occs.count
        except:
            ISSUES.append('Rigid group failed: %s' % last_error())
        look_lines = apply_looks(app, design, {
            'PC': list(sideComp.bRepBodies),
            'WALL': list(wallComp.bRepBodies),
            'ZINC': hw_bodies,
            'BASE': list(baseComp.bRepBodies) if baseComp else [],
            'NICKEL': ((list(intComp.bRepBodies) if intComp else [])
                       + ([b for o in stripComp.occurrences for b in o.component.bRepBodies] if stripComp else [])),
            'HOLDER': [holder_body],
            'FOAM': foam_bodies,
            'CELL': [cell_bodies['Cell_Wrap']],
            'CAN': [cell_bodies['Cell_Can_Bottom'], cell_bodies['Cell_Button']],
            'INSULATOR': [cell_bodies['Insulator_Ring']],
        })

        # Remember where the generated timeline ends, so export_design.py can tell features
        # added by hand afterwards from the ones this script made.
        try:
            design.attributes.add('ebike_enclosure', 'generated_timeline_end', str(design.timeline.count))
        except:
            ISSUES.append('Could not record the timeline marker: %s' % last_error())

        app.activeViewport.fit()
        prog.hide()
        prog = None

        # ---- Report ----
        under = []
        for s in SKETCHES:
            if not s.isFullyConstrained:
                n_loose = sum(1 for i in range(s.sketchCurves.count)
                              if not s.sketchCurves.item(i).isFullyConstrained)
                under.append('%s (%d of %d curves loose; %d dims, %d constraints)' % (
                    s.name, n_loose, s.sketchCurves.count, s.sketchDimensions.count, s.geometricConstraints.count))
        for issue in ISSUES:
            app.log(issue)
        if timings:
            timings[-1] = (timings[-1][0], time.time() - t_start[0])
        msg = '%dS%dP enclosure generated%s.\n' % (cols, rows, '' if BASE_PLATE else ' (no base plate)')
        try:
            here = os.path.abspath(__file__)
        except NameError:
            here = '?'
        msg += 'Script: %s\n' % here
        msg += ('Package script for %s (parameters set to that pack).\n' % CONFIG_NAME if CONFIG_NAME
                else 'Repo script: parameters already in this design were kept.\n')
        msg += 'Time: %.0f s (%s)\n\n' % (sum(t for _, t in timings),
                                          ', '.join('%s %.0f s' % (n, t) for n, t in timings))
        msg += 'Fully defined sketches: %d of %d.\n' % (len(SKETCHES) - len(under), len(SKETCHES))
        msg += 'Rigid group Pack_Rigid: %s.\n' % rigid_note
        msg += 'Nickel strips: %s.\n' % strips_note
        msg += 'Fasteners: %s.\n' % fast_note
        for label, unit, occs, mats in UNIT_CHECKS:
            try:
                off = check_units(occs, mats)
                where = 'all in place' if off < 0.01 else 'MOVED, up to %.1f mm off' % off
            except:
                where = 'position check failed: %s' % last_error()
            msg += '%s: %d copies of %s, %s.\n' % (label, len(occs), unit, where)
        if under:
            msg += 'Not fully defined:\n  ' + '\n  '.join(under[:8]) + ('\n  ...' if len(under) > 8 else '') + '\n'
        if ISSUES:
            msg += '\n%d dimension/constraint problems, first few:\n' % len(ISSUES)
            msg += '\n'.join(ISSUES[:5]) + '\n'
        if look_lines:
            msg += '\nMaterials:\n  ' + '\n  '.join(look_lines) + '\n'
        msg += '\nEdit values in Modify > Change Parameters.'
        ui.messageBox(msg)

    except Cancelled:
        if prog:
            prog.hide()
        if ui:
            ui.messageBox('Cancelled. The assembly is only partly built; re-run the script to rebuild it.')
    except:
        if prog:
            prog.hide()
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))
